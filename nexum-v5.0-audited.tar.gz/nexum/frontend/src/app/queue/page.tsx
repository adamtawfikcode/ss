'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Layers,
  Plus,
  RefreshCw,
  Zap,
  Database,
  GitBranch,
  Film,
  Radio,
  MessageSquare,
  Users,
  Tag,
  Bookmark,
  ListVideo,
  AudioLines,
  Loader2,
  Check,
} from 'lucide-react';
import InputBar from '@/components/InputBar';
import QueuePanel from '@/components/QueuePanel';
import {
  enqueueUrl,
  getDemoStats,
  createDemoNode,
  resetDemo,
} from '@/lib/api';
import type { DemoStats } from '@/lib/types';

const NODE_TYPE_CONFIG = [
  { type: 'Video', icon: Film, color: '#d4a843', desc: 'YouTube video with metadata' },
  { type: 'Channel', icon: Radio, color: '#ef4444', desc: 'Content creator channel' },
  { type: 'Comment', icon: MessageSquare, color: '#6b7280', desc: 'Video comment with sentiment' },
  { type: 'CommentAuthor', icon: Users, color: '#3b82f6', desc: 'Comment author profile' },
  { type: 'Entity', icon: Tag, color: '#10b981', desc: 'Named entity (person, tech, org)' },
  { type: 'Topic', icon: Bookmark, color: '#8b5cf6', desc: 'Discussion topic cluster' },
  { type: 'Playlist', icon: ListVideo, color: '#f59e0b', desc: 'Video playlist' },
  { type: 'Segment', icon: AudioLines, color: '#06b6d4', desc: 'Transcript segment' },
];

export default function QueuePage() {
  const [demoStats, setDemoStats] = useState<DemoStats | null>(null);
  const [creatingType, setCreatingType] = useState<string | null>(null);
  const [lastCreated, setLastCreated] = useState<{ type: string; label: string } | null>(null);
  const [isResetting, setIsResetting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const fetchDemoStats = useCallback(async () => {
    try {
      const stats = await getDemoStats();
      setDemoStats(stats);
    } catch (err) {
      console.error('Failed to fetch demo stats:', err);
    }
  }, []);

  useEffect(() => {
    fetchDemoStats();
  }, [fetchDemoStats]);

  const handleEnqueue = async (url: string, priority: 'normal' | 'immediate', jobType?: string) => {
    setSubmitError(null);
    try {
      await enqueueUrl(url, priority, jobType);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Failed to enqueue');
      throw err;
    }
  };

  const handleCreateNode = async (nodeType: string) => {
    setCreatingType(nodeType);
    try {
      const result = await createDemoNode(nodeType);
      setLastCreated({ type: nodeType, label: result.label });
      await fetchDemoStats();
      setTimeout(() => setLastCreated(null), 3000);
    } catch (err) {
      console.error('Failed to create node:', err);
    } finally {
      setCreatingType(null);
    }
  };

  const handleReset = async () => {
    setIsResetting(true);
    try {
      await resetDemo();
      await fetchDemoStats();
    } catch (err) {
      console.error('Failed to reset:', err);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl text-nexum-text">Processing Queue</h1>
        <p className="mt-1 text-sm text-nexum-muted">
          Add videos, channels, and playlists to the processing pipeline. Toggle priority mode to interrupt and fast-track.
        </p>
      </div>

      {/* Input Bar */}
      <div className="mb-8">
        <InputBar onSubmit={handleEnqueue} />
        {submitError && (
          <p className="mt-2 text-xs text-nexum-danger">{submitError}</p>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Queue Panel — left side */}
        <div className="lg:col-span-3">
          <QueuePanel />
        </div>

        {/* Demo Mode Panel — right side */}
        <div className="lg:col-span-2 space-y-6">
          {/* Demo Stats */}
          <section className="rounded-xl border border-nexum-border/30 bg-nexum-surface/30 p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-display text-nexum-text flex items-center gap-2">
                <Database size={14} className="text-nexum-accent" />
                Demo Network
              </h2>
              <button
                onClick={handleReset}
                disabled={isResetting}
                className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[10px]
                  text-nexum-muted hover:text-nexum-text hover:bg-nexum-border/20
                  transition-colors disabled:opacity-50"
              >
                <RefreshCw size={10} className={isResetting ? 'animate-spin' : ''} />
                Regenerate
              </button>
            </div>

            {demoStats ? (
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(demoStats.node_counts).map(([type, count]) => {
                  const config = NODE_TYPE_CONFIG.find(c => c.type === type);
                  return (
                    <div key={type} className="flex items-center gap-2 rounded-md bg-nexum-bg/40 px-2.5 py-1.5">
                      <span
                        className="h-2 w-2 rounded-full shrink-0"
                        style={{ backgroundColor: config?.color || '#6b7280' }}
                      />
                      <span className="text-xs text-nexum-muted truncate">{type}</span>
                      <span className="ml-auto text-xs font-mono text-nexum-text">{count.toLocaleString()}</span>
                    </div>
                  );
                })}
                <div className="col-span-2 flex items-center justify-between rounded-md bg-nexum-accent/5 border border-nexum-accent/10 px-2.5 py-1.5 mt-1">
                  <span className="flex items-center gap-1.5 text-xs text-nexum-accent">
                    <GitBranch size={11} />
                    Total Edges
                  </span>
                  <span className="text-xs font-mono text-nexum-accent">{demoStats.total_edges.toLocaleString()}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center py-4 text-nexum-muted text-xs">
                <Loader2 size={14} className="animate-spin mr-2" />
                Loading...
              </div>
            )}
          </section>

          {/* Create Nodes */}
          <section className="rounded-xl border border-nexum-border/30 bg-nexum-surface/30 p-4">
            <h2 className="text-sm font-display text-nexum-text flex items-center gap-2 mb-3">
              <Plus size={14} className="text-nexum-success" />
              Create Demo Nodes
            </h2>

            {lastCreated && (
              <div className="mb-3 flex items-center gap-2 rounded-md bg-nexum-success/10 border border-nexum-success/20 px-3 py-1.5 text-xs text-nexum-success animate-fade-in">
                <Check size={12} />
                Created {lastCreated.type}: &ldquo;{lastCreated.label}&rdquo;
              </div>
            )}

            <div className="grid grid-cols-2 gap-1.5">
              {NODE_TYPE_CONFIG.map(({ type, icon: Icon, color, desc }) => (
                <button
                  key={type}
                  onClick={() => handleCreateNode(type)}
                  disabled={creatingType === type}
                  className="
                    group flex items-center gap-2 rounded-lg border border-nexum-border/20
                    bg-nexum-bg/30 px-2.5 py-2 text-left
                    hover:border-nexum-border/40 hover:bg-nexum-surface/40
                    transition-all duration-150 disabled:opacity-50
                  "
                >
                  <span
                    className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md transition-colors"
                    style={{ backgroundColor: `${color}12`, color }}
                  >
                    {creatingType === type ? (
                      <Loader2 size={12} className="animate-spin" />
                    ) : (
                      <Icon size={12} />
                    )}
                  </span>
                  <div className="min-w-0">
                    <span className="text-xs text-nexum-text block">{type}</span>
                    <span className="text-[9px] text-nexum-muted/60 truncate block">{desc}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Edge Distribution */}
          {demoStats && demoStats.edge_type_distribution && (
            <section className="rounded-xl border border-nexum-border/30 bg-nexum-surface/30 p-4">
              <h2 className="text-sm font-display text-nexum-text flex items-center gap-2 mb-3">
                <GitBranch size={14} className="text-nexum-info" />
                Edge Types
              </h2>
              <div className="space-y-1">
                {Object.entries(demoStats.edge_type_distribution)
                  .sort((a, b) => b[1] - a[1])
                  .slice(0, 12)
                  .map(([type, count]) => {
                    const max = Math.max(...Object.values(demoStats.edge_type_distribution));
                    const pct = max > 0 ? (count / max) * 100 : 0;
                    return (
                      <div key={type} className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-nexum-muted w-36 truncate">{type}</span>
                        <div className="flex-1 h-1.5 rounded-full bg-nexum-border/20 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-nexum-info/40 transition-all duration-300"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-[10px] font-mono text-nexum-muted w-8 text-right">{count}</span>
                      </div>
                    );
                  })}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
