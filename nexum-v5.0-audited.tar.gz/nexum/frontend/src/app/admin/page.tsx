'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  BarChart3,
  Database,
  Film,
  Layers,
  Activity,
  ThumbsUp,
  RefreshCw,
  Save,
  AlertCircle,
  CheckCircle,
  MessageSquare,
  Users,
  Network,
  Hash,
} from 'lucide-react';
import {
  getAdminStats,
  getWeights,
  updateWeights,
  getVectorStats,
  triggerReindex,
  getEvaluationMetrics,
  getCommentStats,
  getGraphStats,
} from '@/lib/api';
import type { AdminStats, FusionWeights, VectorStats, EvaluationMetric, CommentStats, GraphStats } from '@/lib/types';

export default function AdminPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [weights, setWeights] = useState<FusionWeights | null>(null);
  const [vectorStats, setVectorStats] = useState<VectorStats | null>(null);
  const [metrics, setMetrics] = useState<EvaluationMetric[]>([]);
  const [commentStats, setCommentStats] = useState<CommentStats | null>(null);
  const [graphStats, setGraphStats] = useState<GraphStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [reindexing, setReindexing] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [s, w, v, m, cs, gs] = await Promise.all([
        getAdminStats().catch(() => null),
        getWeights().catch(() => null),
        getVectorStats().catch(() => null),
        getEvaluationMetrics(20).catch(() => []),
        getCommentStats().catch(() => null),
        getGraphStats().catch(() => null),
      ]);
      if (s) setStats(s);
      if (w) setWeights(w);
      if (v) setVectorStats(v);
      setMetrics(m);
      if (cs) setCommentStats(cs);
      if (gs) setGraphStats(gs);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSaveWeights = async () => {
    if (!weights) return;
    setSaving(true);
    try {
      const updated = await updateWeights(weights);
      const fresh = await getWeights().catch(() => null);
      if (fresh) setWeights(fresh);
      showToast('success', 'Fusion weights updated');
    } catch {
      showToast('error', 'Failed to update weights');
    } finally {
      setSaving(false);
    }
  };

  const handleReindex = async () => {
    setReindexing(true);
    try {
      const res = await triggerReindex();
      showToast('success', `Queued ${res.count} videos for re-indexing`);
    } catch {
      showToast('error', 'Failed to trigger re-index');
    } finally {
      setReindexing(false);
    }
  };

  const updateWeight = (key: keyof FusionWeights, value: number) => {
    if (weights) setWeights({ ...weights, [key]: value });
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl px-6 py-12">
        <div className="h-8 w-64 rounded-lg shimmer mb-8" />
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-24 rounded-xl shimmer" />
          ))}
        </div>
        <div className="h-64 rounded-xl shimmer" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-8 pb-16">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-20 right-6 z-50 flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-body shadow-xl animate-slide-up ${
            toast.type === 'success'
              ? 'bg-nexum-success/15 text-nexum-success border border-nexum-success/30'
              : 'bg-nexum-danger/15 text-nexum-danger border border-nexum-danger/30'
          }`}
        >
          {toast.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {toast.message}
        </div>
      )}

      {/* Header */}
      <Link
        href="/"
        className="mb-6 inline-flex items-center gap-1.5 text-sm text-nexum-muted hover:text-nexum-accent transition-colors"
      >
        <ArrowLeft size={14} /> Back to search
      </Link>

      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl text-nexum-text">Admin Dashboard</h1>
          <p className="mt-1 text-sm text-nexum-muted">System metrics, fusion weights, and operations.</p>
        </div>
        <button
          onClick={fetchAll}
          className="flex items-center gap-1.5 rounded-lg border border-nexum-border px-3 py-1.5 text-xs text-nexum-muted hover:text-nexum-text hover:border-nexum-accent/40 transition-colors"
        >
          <RefreshCw size={12} />
          Refresh
        </button>
      </div>

      {/* Stats cards */}
      {stats && (
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4 animate-fade-in">
          <StatCard icon={Film} label="Videos" value={stats.total_videos} sub={`${stats.indexed_videos} indexed · ${stats.queued_videos} queued · ${stats.failed_videos} failed`} />
          <StatCard icon={Layers} label="Segments" value={stats.total_segments} />
          <StatCard icon={Database} label="Frames" value={stats.total_frames} />
          <StatCard
            icon={ThumbsUp}
            label="Upvote Ratio"
            value={`${(stats.upvote_ratio * 100).toFixed(1)}%`}
            sub={`${stats.total_feedback} total feedback`}
            accent
          />
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Vector Store stats */}
        {vectorStats && (
          <div className="rounded-2xl border border-nexum-border/50 bg-nexum-surface/70 p-5 animate-slide-up">
            <h3 className="mb-4 flex items-center gap-2 font-body font-semibold text-nexum-text">
              <BarChart3 size={16} className="text-nexum-accent" />
              Vector Store
            </h3>
            <div className="space-y-3">
              <VectorRow label="Text Vectors" count={vectorStats['text_collection']?.points_count ?? 0} size={vectorStats['text_collection']?.vectors_count ?? 0} />
              <VectorRow label="Visual Vectors" count={vectorStats['visual_collection']?.points_count ?? 0} size={vectorStats['visual_collection']?.vectors_count ?? 0} />
            </div>
          </div>
        )}

        {/* Fusion weights */}
        {weights && (
          <div className="rounded-2xl border border-nexum-border/50 bg-nexum-surface/70 p-5 animate-slide-up">
            <h3 className="mb-4 flex items-center gap-2 font-body font-semibold text-nexum-text">
              <Activity size={16} className="text-nexum-accent" />
              Fusion Weights
            </h3>
            <div className="space-y-3">
              {(Object.entries(weights) as [keyof FusionWeights, number][]).map(([key, val]) => (
                <div key={key} className="flex items-center gap-3">
                  <span className="w-28 text-right text-xs font-mono text-nexum-muted">
                    {key.replace(/_/g, ' ')}
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={0.5}
                    step={0.01}
                    value={val}
                    onChange={(e) => updateWeight(key, Number(e.target.value))}
                    className="flex-1 accent-nexum-accent h-1"
                  />
                  <span className="w-10 text-right text-xs font-mono text-nexum-text">
                    {val.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
            <button
              onClick={handleSaveWeights}
              disabled={saving}
              className="mt-4 flex items-center gap-1.5 rounded-lg bg-nexum-accent/15 px-4 py-2 text-xs font-medium text-nexum-accent hover:bg-nexum-accent/25 transition-colors disabled:opacity-50"
            >
              <Save size={12} />
              {saving ? 'Saving...' : 'Save Weights'}
            </button>
          </div>
        )}

        {/* Operations */}
        <div className="rounded-2xl border border-nexum-border/50 bg-nexum-surface/70 p-5 animate-slide-up">
          <h3 className="mb-4 flex items-center gap-2 font-body font-semibold text-nexum-text">
            <RefreshCw size={16} className="text-nexum-accent" />
            Operations
          </h3>
          <button
            onClick={handleReindex}
            disabled={reindexing}
            className="flex items-center gap-1.5 rounded-lg border border-nexum-warn/30 bg-nexum-warn/10 px-4 py-2.5 text-sm text-nexum-warn hover:bg-nexum-warn/20 transition-colors disabled:opacity-50"
          >
            <RefreshCw size={14} className={reindexing ? 'animate-spin' : ''} />
            {reindexing ? 'Queuing...' : 'Re-index All Videos'}
          </button>
          <p className="mt-2 text-xs text-nexum-muted">
            Re-runs the full ML pipeline on all indexed videos. Use after model updates.
          </p>
        </div>

        {/* Recent evaluation metrics */}
        {metrics.length > 0 && (
          <div className="rounded-2xl border border-nexum-border/50 bg-nexum-surface/70 p-5 animate-slide-up">
            <h3 className="mb-4 flex items-center gap-2 font-body font-semibold text-nexum-text">
              <BarChart3 size={16} className="text-nexum-accent" />
              Recent Metrics
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {metrics.map((m) => (
                <div key={m.id} className="flex items-center justify-between text-xs">
                  <span className="font-mono text-nexum-muted">{m.metric_name}</span>
                  <span className="font-mono text-nexum-text">{m.metric_value.toFixed(4)}</span>
                  <span className="text-[10px] text-nexum-muted/60">
                    {new Date(m.measured_at).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: typeof Film;
  label: string;
  value: number | string;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-xl border border-nexum-border/40 bg-nexum-surface/60 p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon size={14} className={accent ? 'text-nexum-accent' : 'text-nexum-muted'} />
        <span className="text-[11px] font-mono uppercase tracking-wider text-nexum-muted">{label}</span>
      </div>
      <span
        className={`text-2xl font-mono font-bold ${accent ? 'text-nexum-accent' : 'text-nexum-text'}`}
      >
        {typeof value === 'number' ? value.toLocaleString() : value}
      </span>
      {sub && <p className="mt-1 text-[11px] text-nexum-muted/70">{sub}</p>}
    </div>
  );
}

function VectorRow({ label, count, size }: { label: string; count: number; size: number }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-nexum-bg/40 px-3 py-2">
      <span className="text-sm text-nexum-text">{label}</span>
      <div className="flex items-center gap-4 text-xs font-mono text-nexum-muted">
        <span>{count.toLocaleString()} pts</span>
        <span>{size.toLocaleString()} vecs</span>
      </div>
    </div>
  );
}
