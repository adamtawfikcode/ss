'use client';

import { useCallback, useEffect, useState } from 'react';
import {
  getCalibrationStatus,
  triggerCalibrationFit,
  testCalibration,
  getAlignment,
  getChangePoints,
} from '@/lib/api';
import type {
  CalibrationStatus,
  CalibratedScore,
  AlignmentSummary,
  ChangePointResult,
} from '@/lib/types';
import {
  getConfidenceBand,
  ALIGNMENT_COLORS,
  TRANSITION_ICONS,
} from '@/lib/types';

export default function IntelligencePage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-10 space-y-12">
      <header>
        <h1 className="font-display text-3xl text-nexum-text">
          Intelligence Dashboard
        </h1>
        <p className="mt-2 text-sm text-nexum-muted">
          Confidence calibration, audio-transcript alignment, and acoustic change point analysis.
        </p>
      </header>

      <CalibrationPanel />
      <AlignmentPanel />
      <ChangePointPanel />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Calibration Panel
// ═══════════════════════════════════════════════════════════════════════

function CalibrationPanel() {
  const [status, setStatus] = useState<CalibrationStatus | null>(null);
  const [testResult, setTestResult] = useState<CalibratedScore | null>(null);
  const [testTarget, setTestTarget] = useState('audio.pitch_shift');
  const [testScore, setTestScore] = useState(0.65);
  const [fitting, setFitting] = useState(false);

  useEffect(() => {
    getCalibrationStatus().then(setStatus).catch(() => {});
  }, []);

  const handleFit = async () => {
    setFitting(true);
    try {
      await triggerCalibrationFit();
      const updated = await getCalibrationStatus();
      setStatus(updated);
    } catch {}
    setFitting(false);
  };

  const handleTest = async () => {
    try {
      const result = await testCalibration(testTarget, testScore);
      setTestResult(result);
    } catch {}
  };

  const targets = status?.targets ? Object.entries(status.targets) : [];

  return (
    <section className="rounded-2xl border border-nexum-border bg-nexum-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-xl text-nexum-text">Confidence Calibration</h2>
          <p className="text-xs text-nexum-muted mt-1">
            Version: {status?.version ?? '—'} · {targets.length} targets
          </p>
        </div>
        <button
          onClick={handleFit}
          disabled={fitting}
          className="rounded-lg bg-nexum-accent/20 px-4 py-2 text-sm text-nexum-accent hover:bg-nexum-accent/30 transition disabled:opacity-50"
        >
          {fitting ? 'Fitting…' : 'Fit All'}
        </button>
      </div>

      {/* Target grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
        {targets.map(([name, info]) => (
          <div
            key={name}
            className={`rounded-lg border p-3 text-center ${
              info.is_fitted
                ? 'border-nexum-success/40 bg-nexum-success/5'
                : 'border-nexum-border bg-nexum-bg/50'
            }`}
          >
            <div className="text-xs font-mono text-nexum-muted truncate">{name}</div>
            <div className={`mt-1 text-sm font-semibold ${info.is_fitted ? 'text-nexum-success' : 'text-nexum-muted'}`}>
              {info.is_fitted ? '✓ Fitted' : '○ Unfitted'}
            </div>
            <div className="text-[10px] text-nexum-muted mt-0.5">
              {info.method} · {info.sample_count} samples
            </div>
          </div>
        ))}
      </div>

      {/* Test calibration */}
      <div className="flex items-end gap-4 border-t border-nexum-border pt-4">
        <div>
          <label className="text-xs text-nexum-muted">Target</label>
          <select
            value={testTarget}
            onChange={(e) => setTestTarget(e.target.value)}
            className="mt-1 block w-48 rounded-lg border border-nexum-border bg-nexum-bg px-3 py-1.5 text-sm text-nexum-text"
          >
            {targets.map(([name]) => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs text-nexum-muted">Raw Score</label>
          <input
            type="number"
            min={0}
            max={1}
            step={0.05}
            value={testScore}
            onChange={(e) => setTestScore(Number(e.target.value))}
            className="mt-1 block w-24 rounded-lg border border-nexum-border bg-nexum-bg px-3 py-1.5 text-sm text-nexum-text"
          />
        </div>
        <button
          onClick={handleTest}
          className="rounded-lg bg-nexum-accent/10 px-4 py-1.5 text-sm text-nexum-accent hover:bg-nexum-accent/20 transition"
        >
          Test
        </button>
        {testResult && (
          <div className="flex items-center gap-3 ml-4">
            <span className="text-sm text-nexum-muted">→</span>
            <span
              className="inline-block rounded-full px-3 py-0.5 text-sm font-semibold"
              style={{
                backgroundColor: testResult.band_color + '22',
                color: testResult.band_color,
                borderWidth: 1,
                borderColor: testResult.band_color + '44',
              }}
            >
              {testResult.band_label}: {(testResult.calibrated_probability * 100).toFixed(1)}%
            </span>
          </div>
        )}
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Alignment Panel
// ═══════════════════════════════════════════════════════════════════════

function AlignmentPanel() {
  const [videoId, setVideoId] = useState('');
  const [alignment, setAlignment] = useState<AlignmentSummary | null>(null);
  const [error, setError] = useState('');

  const handleLoad = async () => {
    if (!videoId.trim()) return;
    setError('');
    try {
      const data = await getAlignment(videoId.trim());
      setAlignment(data);
    } catch (e: any) {
      setError(e.message ?? 'Failed to load');
      setAlignment(null);
    }
  };

  return (
    <section className="rounded-2xl border border-nexum-border bg-nexum-card p-6">
      <h2 className="font-display text-xl text-nexum-text mb-4">Audio-Transcript Alignment</h2>

      <div className="flex gap-3 mb-6">
        <input
          value={videoId}
          onChange={(e) => setVideoId(e.target.value)}
          placeholder="Enter video ID…"
          className="flex-1 rounded-lg border border-nexum-border bg-nexum-bg px-4 py-2 text-sm text-nexum-text"
          onKeyDown={(e) => e.key === 'Enter' && handleLoad()}
        />
        <button
          onClick={handleLoad}
          className="rounded-lg bg-nexum-accent/10 px-4 py-2 text-sm text-nexum-accent hover:bg-nexum-accent/20 transition"
        >
          Analyze
        </button>
      </div>

      {error && <p className="text-sm text-red-400 mb-4">{error}</p>}

      {alignment && (
        <>
          {/* Summary bar */}
          <div className="flex items-center gap-6 mb-6 p-4 rounded-lg bg-nexum-bg/50 border border-nexum-border">
            <div className="text-center">
              <div className="text-2xl font-display text-nexum-text">
                {(alignment.overall_score * 100).toFixed(0)}%
              </div>
              <div className="text-xs text-nexum-muted">Overall</div>
            </div>
            <div
              className="rounded-full px-3 py-1 text-sm font-semibold"
              style={{
                color: ALIGNMENT_COLORS[alignment.overall_quality] ?? '#94a3b8',
                backgroundColor: (ALIGNMENT_COLORS[alignment.overall_quality] ?? '#94a3b8') + '22',
              }}
            >
              {alignment.overall_quality.toUpperCase()}
            </div>
            <div className="text-sm text-nexum-muted">
              {alignment.total_warnings} warning{alignment.total_warnings !== 1 ? 's' : ''}
            </div>
            {alignment.mismatch_regions.length > 0 && (
              <div className="text-sm text-red-400">
                {alignment.mismatch_regions.length} mismatch region{alignment.mismatch_regions.length !== 1 ? 's' : ''}
              </div>
            )}
          </div>

          {/* Segment timeline */}
          <div className="space-y-1.5">
            {alignment.segments.map((seg, i) => {
              const color = ALIGNMENT_COLORS[seg.quality_level] ?? '#94a3b8';
              return (
                <div key={i} className="flex items-center gap-3 text-xs">
                  <span className="w-20 text-right font-mono text-nexum-muted">
                    {formatTime(seg.start_time)}
                  </span>
                  <div className="flex-1 h-4 rounded-full bg-nexum-bg overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${seg.alignment_score * 100}%`,
                        backgroundColor: color,
                        opacity: 0.8,
                      }}
                    />
                  </div>
                  <span className="w-12 font-mono" style={{ color }}>
                    {(seg.alignment_score * 100).toFixed(0)}%
                  </span>
                  {seg.warnings.length > 0 && (
                    <span className="text-yellow-500" title={seg.warnings.join(', ')}>⚠</span>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Change Point Panel
// ═══════════════════════════════════════════════════════════════════════

function ChangePointPanel() {
  const [videoId, setVideoId] = useState('');
  const [result, setResult] = useState<ChangePointResult | null>(null);
  const [minMag, setMinMag] = useState(0.3);
  const [error, setError] = useState('');

  const handleLoad = async () => {
    if (!videoId.trim()) return;
    setError('');
    try {
      const data = await getChangePoints(videoId.trim(), minMag);
      setResult(data);
    } catch (e: any) {
      setError(e.message ?? 'Failed to load');
      setResult(null);
    }
  };

  return (
    <section className="rounded-2xl border border-nexum-border bg-nexum-card p-6">
      <h2 className="font-display text-xl text-nexum-text mb-4">Acoustic Change Points</h2>

      <div className="flex gap-3 mb-6">
        <input
          value={videoId}
          onChange={(e) => setVideoId(e.target.value)}
          placeholder="Enter video ID…"
          className="flex-1 rounded-lg border border-nexum-border bg-nexum-bg px-4 py-2 text-sm text-nexum-text"
          onKeyDown={(e) => e.key === 'Enter' && handleLoad()}
        />
        <div className="flex items-center gap-2">
          <label className="text-xs text-nexum-muted whitespace-nowrap">Min magnitude</label>
          <input
            type="number"
            min={0}
            max={1}
            step={0.1}
            value={minMag}
            onChange={(e) => setMinMag(Number(e.target.value))}
            className="w-16 rounded-lg border border-nexum-border bg-nexum-bg px-2 py-2 text-sm text-nexum-text"
          />
        </div>
        <button
          onClick={handleLoad}
          className="rounded-lg bg-nexum-accent/10 px-4 py-2 text-sm text-nexum-accent hover:bg-nexum-accent/20 transition"
        >
          Detect
        </button>
      </div>

      {error && <p className="text-sm text-red-400 mb-4">{error}</p>}

      {result && (
        <>
          {/* Summary */}
          <div className="flex items-center gap-6 mb-6 p-4 rounded-lg bg-nexum-bg/50 border border-nexum-border">
            <div className="text-center">
              <div className="text-2xl font-display text-nexum-text">{result.total_change_points}</div>
              <div className="text-xs text-nexum-muted">Change Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-display text-nexum-text">{result.num_scenes}</div>
              <div className="text-xs text-nexum-muted">Scenes</div>
            </div>
            <div className="flex gap-2">
              {result.dominant_transitions.map((t) => (
                <span key={t} className="rounded-full bg-nexum-accent/10 px-3 py-1 text-xs text-nexum-accent">
                  {TRANSITION_ICONS[t] ?? '•'} {t.replace(/_/g, ' ')}
                </span>
              ))}
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-2">
            {result.change_points.map((cp, i) => (
              <div
                key={i}
                className="flex items-center gap-4 rounded-lg border border-nexum-border/50 bg-nexum-bg/30 px-4 py-2.5"
              >
                <span className="text-lg">
                  {TRANSITION_ICONS[cp.transition_type] ?? '•'}
                </span>
                <span className="w-20 font-mono text-sm text-nexum-text">
                  {formatTime(cp.timestamp)}
                </span>
                {/* Magnitude bar */}
                <div className="w-24 h-2 rounded-full bg-nexum-border overflow-hidden">
                  <div
                    className="h-full rounded-full bg-nexum-accent"
                    style={{ width: `${cp.magnitude * 100}%` }}
                  />
                </div>
                <span className="text-xs font-mono text-nexum-muted w-10">
                  {(cp.magnitude * 100).toFixed(0)}%
                </span>
                <span className="text-sm text-nexum-text flex-1">
                  {cp.from_state && cp.to_state
                    ? `${cp.from_state} → ${cp.to_state}`
                    : cp.transition_type.replace(/_/g, ' ')}
                </span>
                {cp.detail && (
                  <span className="text-xs text-nexum-muted truncate max-w-[200px]">
                    {cp.detail}
                  </span>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

// ── Helpers ──────────────────────────────────────────────

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}
