import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'Nexum v4 — Calibrated Acoustic Intelligence',
  description: 'Multimodal calibrated intelligence engine — 14-modality search, confidence calibration, alignment analysis.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen noise-bg gradient-mesh">
        <nav className="sticky top-0 z-50 border-b border-nexum-border/60 bg-nexum-bg/80 backdrop-blur-xl">
          <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-6">
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="relative h-8 w-8">
                <div className="absolute inset-0 rounded-lg bg-nexum-accent/20 group-hover:bg-nexum-accent/30 transition-colors" />
                <svg viewBox="0 0 32 32" className="relative h-8 w-8" fill="none">
                  <path
                    d="M8 6l8 5v10l-8 5V6z"
                    fill="#d4a843"
                    opacity="0.9"
                  />
                  <path
                    d="M16 11l8-5v20l-8-5V11z"
                    fill="#d4a843"
                    opacity="0.5"
                  />
                </svg>
              </div>
              <span className="font-display text-xl tracking-wide text-nexum-text">
                Nexum
              </span>
            </Link>

            <div className="flex items-center gap-6">
              <Link
                href="/"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Search
              </Link>
              <Link
                href="/graph-live"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Graph
              </Link>
              <Link
                href="/queue"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Queue
              </Link>
              <Link
                href="/signals"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Signals
              </Link>
              <Link
                href="/intelligence"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Intelligence
              </Link>
              <Link
                href="/admin"
                className="text-sm font-body text-nexum-muted hover:text-nexum-text transition-colors"
              >
                Admin
              </Link>
              <div className="h-4 w-px bg-nexum-border" />
              <div className="flex items-center gap-1.5 text-xs font-mono text-nexum-muted">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-nexum-success animate-pulse" />
                Online
              </div>
            </div>
          </div>
        </nav>

        <main className="relative z-10 min-h-[calc(100vh-3.5rem-4rem)]">{children}</main>

        <footer className="relative z-10 border-t border-nexum-border/40 bg-nexum-bg/60 backdrop-blur-sm">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
            <div className="flex items-center gap-1.5 text-xs text-nexum-muted">
              <span className="font-display text-nexum-text/60">Nexum</span>
              <span className="text-nexum-border">·</span>
              <span>v4.3</span>
            </div>
            <div className="flex items-center gap-5 text-xs text-nexum-muted">
              <Link href="/privacy" className="hover:text-nexum-text transition-colors">
                Privacy Policy
              </Link>
              <a href="mailto:contact@nexum.app" className="hover:text-nexum-text transition-colors">
                Contact
              </a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
