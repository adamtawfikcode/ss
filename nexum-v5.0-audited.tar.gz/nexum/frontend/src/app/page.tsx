'use client';

import { useState, useCallback } from 'react';
import { Film, Sparkles, Layers, Brain, ScanText } from 'lucide-react';
import SearchBar from '@/components/SearchBar';
import FilterPanel from '@/components/FilterPanel';
import ResultCard from '@/components/ResultCard';
import SearchStats from '@/components/SearchStats';
import { search } from '@/lib/api';
import type { SearchResponse, SearchFilters } from '@/lib/types';

export default function HomePage() {
  const [response, setResponse] = useState<SearchResponse | null>(null);
  const [filters, setFilters] = useState<SearchFilters>({ sort_by: 'relevance', modality: 'all' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastQuery, setLastQuery] = useState('');

  const handleSearch = useCallback(
    async (query: string) => {
      setIsLoading(true);
      setError(null);
      setLastQuery(query);
      try {
        const res = await search(query, filters);
        setResponse(res);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Search failed');
      } finally {
        setIsLoading(false);
      }
    },
    [filters]
  );

  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
    if (lastQuery) {
      handleSearch(lastQuery);
    }
  };

  return (
    <div className="min-h-[calc(100vh-3.5rem)]">
      {/* Hero / Search area */}
      <section className="relative px-6 pt-16 pb-8">
        {/* Decorative lines */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute left-1/4 top-0 h-40 w-px bg-gradient-to-b from-transparent via-nexum-accent/10 to-transparent" />
          <div className="absolute right-1/3 top-0 h-56 w-px bg-gradient-to-b from-transparent via-nexum-info/10 to-transparent" />
        </div>

        {!response && !isLoading && (
          <div className="mx-auto max-w-2xl text-center mb-10 animate-fade-in">
            <h1 className="font-display text-4xl sm:text-5xl text-nexum-text leading-tight">
              Find the exact
              <span className="italic text-nexum-accent"> moment</span>
            </h1>
            <p className="mt-3 text-base text-nexum-muted font-body leading-relaxed">
              Search inside videos using natural language. Nexum understands transcripts,
              on-screen text, and visual content to pinpoint the frame you&apos;re looking for.
            </p>

            {/* Feature badges */}
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {[
                { icon: Brain, label: 'Semantic Search' },
                { icon: ScanText, label: 'OCR Detection' },
                { icon: Layers, label: 'Visual Understanding' },
                { icon: Film, label: 'Temporal Fusion' },
              ].map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="flex items-center gap-1.5 rounded-full border border-nexum-border/40 bg-nexum-surface/40 px-3 py-1 text-xs text-nexum-muted"
                >
                  <Icon size={12} className="text-nexum-accent/60" />
                  {label}
                </div>
              ))}
            </div>
          </div>
        )}

        <SearchBar
          onSearch={handleSearch}
          isLoading={isLoading}
          queryAnalysis={response?.query_analysis}
        />

        {(response || isLoading) && (
          <div className="mt-4 flex justify-center">
            <FilterPanel filters={filters} onChange={handleFiltersChange} />
          </div>
        )}
      </section>

      {/* Error */}
      {error && (
        <div className="mx-auto max-w-3xl px-6">
          <div className="rounded-xl border border-nexum-danger/30 bg-nexum-danger/10 px-4 py-3 text-sm text-nexum-danger animate-fade-in">
            {error}
          </div>
        </div>
      )}

      {/* Loading skeleton */}
      {isLoading && (
        <div className="mx-auto max-w-4xl space-y-4 px-6 pt-4">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-48 rounded-2xl border border-nexum-border/30 shimmer"
            />
          ))}
        </div>
      )}

      {/* Results */}
      {response && !isLoading && (
        <section className="mx-auto max-w-4xl px-6 pb-16">
          <div className="mb-4">
            <SearchStats
              total={response.total}
              searchTimeMs={response.search_time_ms}
              showing={response.results.length}
            />
          </div>

          {response.results.length > 0 ? (
            <div className="space-y-4">
              {response.results.map((result, i) => (
                <ResultCard
                  key={`${result.video_id}-${result.timestamp}`}
                  result={result}
                  index={i}
                  query={lastQuery}
                />
              ))}
            </div>
          ) : (
            <div className="mt-12 text-center animate-fade-in">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-nexum-border/40 bg-nexum-surface/50">
                <Sparkles size={24} className="text-nexum-muted" />
              </div>
              <h3 className="font-display text-xl text-nexum-text">No moments found</h3>
              <p className="mt-1 text-sm text-nexum-muted">
                Try rephrasing your query or adjusting the filters.
              </p>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
