'use client';

import { useEffect, useState } from 'react';
import { getSignalStats, getRecrawlStats, getStaleVideos, getRecrawlHistory } from '@/lib/api';
import { SIGNAL_CATEGORIES } from '@/lib/types';

const SIGNAL_LABELS: Record<string, { icon: string; category: string; desc: string }> = {
  recrawl_events:        { icon: '🔄', category: 'recrawl',            desc: 'Video re-crawl events with field diffs' },
  cursor_heatmaps:       { icon: '🖱', category: 'temporal_visual',    desc: 'Mouse pointer movement tracking in screen recordings' },
  text_edit_events:      { icon: '⌨',  category: 'temporal_visual',    desc: 'Text typed then deleted/corrected in coding tutorials' },
  face_camera_ratios:    { icon: '👤', category: 'temporal_visual',    desc: 'Face-to-camera presence ratio over time' },
  background_changes:    { icon: '🏠', category: 'temporal_visual',    desc: 'Studio/background changes between uploads' },
  breathing_patterns:    { icon: '💨', category: 'audio_micro',        desc: 'Breathing analysis before statements' },
  ambient_bleeds:        { icon: '🔊', category: 'audio_micro',        desc: 'Keyboard clicks, mouse bleed, room noise' },
  room_fingerprints:     { icon: '🏗', category: 'audio_micro',        desc: 'Room reverb fingerprint clustering' },
  laughter_events:       { icon: '😂', category: 'audio_micro',        desc: 'Laughter authenticity via spectral decay' },
  upload_patterns:       { icon: '📅', category: 'behavioral',         desc: 'Upload time-of-day drift detection' },
  title_edit_history:    { icon: '✏',  category: 'behavioral',         desc: 'Title/thumbnail A/B testing history' },
  thumbnail_analyses:    { icon: '🎨', category: 'behavioral',         desc: 'Thumbnail color palette & clickbait scoring' },
  link_health:           { icon: '🔗', category: 'behavioral',         desc: 'Description link rot rate & health checks' },
  pinned_comment_history:{ icon: '📌', category: 'comment_archaeology',desc: 'Pinned comment changes over time' },
  sentiment_drifts:      { icon: '📈', category: 'comment_archaeology',desc: 'First-hour vs day-30 sentiment shift' },
  deleted_shadows:       { icon: '👻', category: 'comment_archaeology',desc: 'Reply chains responding to deleted comments' },
  broll_reuses:          { icon: '🎬', category: 'cross_video',        desc: 'B-roll/stock footage reuse detection' },
  sponsor_segments:      { icon: '💰', category: 'cross_video',        desc: 'Sponsor segment timing across ecosystem' },
  intro_outro_evolutions:{ icon: '🎵', category: 'cross_video',        desc: 'Intro/outro evolution & subscribe-ask timing' },
  linguistic_profiles:   { icon: '🗣', category: 'linguistic',         desc: 'Code-switching, fillers, hedging, Zipf deviation' },
  commenter_migrations:  { icon: '🚶', category: 'graph_relational',   desc: 'Audience migration between channels' },
  entity_propagations:   { icon: '🌊', category: 'graph_relational',   desc: 'Who said it first? Entity spread tracking' },
  parasocial_indices:    { icon: '💬', category: 'graph_relational',   desc: 'Creator reply reciprocity per commenter' },
  topic_gestations:      { icon: '🥚', category: 'graph_relational',   desc: 'Comments-to-video topic adoption lag' },
};

export default function SignalsPage() {
  const [signalStats, setSignalStats] = useState<Record<string, number>>({});
  const [totalSignals, setTotalSignals] = useState(0);
  const [recrawlStats, setRecrawlStats] = useState<any>(null);
  const [staleVideos, setStaleVideos] = useState<any[]>([]);
  const [recrawlHistory, setRecrawlHistory] = useState<any[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [sig, recrawl, stale, history] = await Promise.all([
          getSignalStats(),
          getRecrawlStats(),
          getStaleVideos(168),
          getRecrawlHistory(),
        ]);
        setSignalStats(sig.signals || {});
        setTotalSignals(sig.total || 0);
        setRecrawlStats(recrawl);
        setStaleVideos(stale.stale_videos?.slice(0, 15) || []);
        setRecrawlHistory(history.events?.slice(0, 10) || []);
      } catch (e) {
        console.error('Failed to load signals:', e);
      }
      setLoading(false);
    }
    load();
  }, []);

  const filteredSignals = activeCategory
    ? Object.entries(SIGNAL_LABELS).filter(([_, v]) => v.category === activeCategory)
    : Object.entries(SIGNAL_LABELS);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-gray-400 text-lg">Loading signal analytics...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">
            Deep Signal Analytics
          </h1>
          <p className="text-gray-400 mt-1">
            {totalSignals.toLocaleString()} signals across 7 categories · 24 signal types · every node timestamped for recrawl
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              !activeCategory
                ? 'bg-white/10 text-white border border-white/20'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
            }`}
          >
            All ({totalSignals.toLocaleString()})
          </button>
          {SIGNAL_CATEGORIES.map(cat => {
            const catCount = Object.entries(SIGNAL_LABELS)
              .filter(([_, v]) => v.category === cat.key)
              .reduce((sum, [k]) => sum + (signalStats[k] || 0), 0);
            return (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(activeCategory === cat.key ? null : cat.key)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  activeCategory === cat.key
                    ? 'bg-white/10 text-white border border-white/20'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                {cat.icon} {cat.label} ({catCount.toLocaleString()})
              </button>
            );
          })}
        </div>

        {/* Signal Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-10">
          {filteredSignals.map(([key, meta]) => (
            <div key={key} className="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-gray-600 transition-colors">
              <div className="flex items-start justify-between">
                <span className="text-xl">{meta.icon}</span>
                <span className="text-lg font-mono font-bold text-white">
                  {(signalStats[key] || 0).toLocaleString()}
                </span>
              </div>
              <h3 className="text-sm font-medium text-gray-200 mt-2">
                {key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
              </h3>
              <p className="text-xs text-gray-500 mt-1">{meta.desc}</p>
            </div>
          ))}
        </div>

        {/* Recrawl Stats + Stale Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Recrawl Stats */}
          {recrawlStats && (
            <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
              <h2 className="text-lg font-semibold text-white mb-4">🔄 Recrawl Activity</h2>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-gray-800 rounded p-3">
                  <div className="text-2xl font-mono font-bold text-blue-400">{recrawlStats.total_recrawls}</div>
                  <div className="text-xs text-gray-500">Total Recrawls</div>
                </div>
                <div className="bg-gray-800 rounded p-3">
                  <div className="text-2xl font-mono font-bold text-amber-400">{recrawlStats.title_changes}</div>
                  <div className="text-xs text-gray-500">Title Changes</div>
                </div>
                <div className="bg-gray-800 rounded p-3">
                  <div className="text-2xl font-mono font-bold text-green-400">{recrawlStats.avg_comments_added}</div>
                  <div className="text-xs text-gray-500">Avg Comments Added</div>
                </div>
                <div className="bg-gray-800 rounded p-3">
                  <div className="text-2xl font-mono font-bold text-red-400">{recrawlStats.description_changes}</div>
                  <div className="text-xs text-gray-500">Desc Changes</div>
                </div>
              </div>
              {recrawlStats.by_trigger && (
                <div className="space-y-1.5">
                  <h3 className="text-xs text-gray-500 uppercase font-medium">By Trigger</h3>
                  {Object.entries(recrawlStats.by_trigger).map(([trigger, count]) => (
                    <div key={trigger} className="flex items-center justify-between text-sm">
                      <span className="text-gray-300">{trigger}</span>
                      <span className="text-gray-500 font-mono">{String(count)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Stale Videos */}
          <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-white mb-4">⏰ Stale Content</h2>
            {staleVideos.length === 0 ? (
              <p className="text-gray-500 text-sm">No stale videos detected</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {staleVideos.map((v, i) => (
                  <div key={i} className="flex items-center justify-between bg-gray-800 rounded p-2.5 text-sm">
                    <div className="truncate flex-1 mr-3">
                      <span className="text-gray-200">{v.title?.slice(0, 45) || v.platform_id}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-xs font-mono ${
                        v.hours_stale > 500 ? 'text-red-400' :
                        v.hours_stale > 200 ? 'text-amber-400' : 'text-green-400'
                      }`}>
                        {v.hours_stale}h
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recent Recrawl Events */}
        {recrawlHistory.length > 0 && (
          <div className="mt-6 bg-gray-900 border border-gray-800 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-white mb-4">📋 Recent Recrawl Events</h2>
            <div className="space-y-2">
              {recrawlHistory.map((e, i) => (
                <div key={i} className="bg-gray-800 rounded p-3 text-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        e.trigger === 'scheduled' ? 'bg-blue-500/20 text-blue-300' :
                        e.trigger === 'drift_detected' ? 'bg-amber-500/20 text-amber-300' :
                        e.trigger === 'manual' ? 'bg-green-500/20 text-green-300' :
                        'bg-purple-500/20 text-purple-300'
                      }`}>
                        {e.trigger}
                      </span>
                      <span className="text-gray-400">
                        {(e.fields_changed || []).join(', ')}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      {e.comments_added > 0 && (
                        <span className="text-green-400">+{e.comments_added} comments</span>
                      )}
                      {e.comments_deleted > 0 && (
                        <span className="text-red-400">-{e.comments_deleted} comments</span>
                      )}
                      {e.duration_ms && <span>{e.duration_ms}ms</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
