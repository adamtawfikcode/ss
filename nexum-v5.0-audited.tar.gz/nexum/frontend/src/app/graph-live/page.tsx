'use client';

import { useCallback, useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import type { GraphNode, GraphSnapshot } from '@/lib/types';
import { getGraphSnapshot, getGraphStats, getDemoSnapshot } from '@/lib/api';
import { useGraphWebSocket } from '@/lib/useGraphWebSocket';
import GraphMetrics from '@/components/graph/GraphMetrics';
import GraphControls from '@/components/graph/GraphControls';

// Lazy-load both engines (needs browser APIs)
const GraphCanvas = dynamic(() => import('@/components/graph/GraphCanvas'), {
  ssr: false,
  loading: () => <EngineLoading label="Cytoscape" />,
});

const GraphCanvas3D = dynamic(() => import('@/components/graph3d/GraphCanvas3D'), {
  ssr: false,
  loading: () => <EngineLoading label="Three.js" />,
});

function EngineLoading({ label }: { label: string }) {
  return (
    <div className="w-full h-full flex items-center justify-center text-nexum-muted font-mono text-sm">
      Loading {label} engine...
    </div>
  );
}

const ALL_TYPES = new Set(['Video', 'CommentAuthor', 'Comment', 'Entity', 'Topic', 'Channel', 'Playlist', 'Segment']);

export default function GraphLivePage() {
  const [filterTypes, setFilterTypes] = useState<Set<string>>(new Set(ALL_TYPES));
  const [selectedNode, setSelectedNode] = useState<{ id: string; type: string } | null>(null);
  const [dbStats, setDbStats] = useState<Record<string, number> | null>(null);
  const [initialLoaded, setInitialLoaded] = useState(false);
  const [demoMode, setDemoMode] = useState(false);
  const [demoStats, setDemoStats] = useState<Record<string, number> | null>(null);
  const [engine3D, setEngine3D] = useState(true);  // default to 3D

  const { nodes, edges, events, connected, paused, eventRate, togglePause, reconnect } =
    useGraphWebSocket({ maxNodes: 1000 });

  useEffect(() => {
    async function loadInitial() {
      try {
        if (demoMode) {
          const demo = await getDemoSnapshot(undefined, 3000);
          setDemoStats(demo.stats);
          setDbStats({
            channels: demo.stats.channels,
            videos: demo.stats.videos,
            comments: demo.stats.comments,
            authors: demo.stats.authors,
            entities: demo.stats.entities,
            topics: demo.stats.topics,
            playlists: demo.stats.playlists,
            edges: demo.stats.edges,
          });
          for (const node of demo.nodes.slice(0, 2000)) {
            nodes.set(node.id, node);
          }
          edges.length = 0;
          for (const edge of demo.edges.slice(0, 5000)) {
            edges.push(edge);
          }
        } else {
          const [snapshot, stats] = await Promise.all([
            getGraphSnapshot(undefined, 500),
            getGraphStats(),
          ]);
          setDbStats(stats as unknown as Record<string, number>);
          if (snapshot.nodes?.length > 0) {
            for (const node of snapshot.nodes) nodes.set(node.id, node);
            edges.length = 0;
            for (const edge of snapshot.edges) edges.push(edge);
          }
        }
      } catch (err) {
        console.warn('Graph snapshot load failed:', err);
      }
      setInitialLoaded(true);
    }
    loadInitial();
  }, [demoMode]);

  const handleNodeClick = useCallback((nodeId: string, nodeType: string) => {
    setSelectedNode({ id: nodeId, type: nodeType });
  }, []);

  return (
    <div className="relative w-full" style={{ height: 'calc(100vh - 56px)' }}>
      {/* Graph Canvas — 3D or 2D */}
      {engine3D ? (
        <GraphCanvas3D
          nodes={nodes}
          edges={edges}
          filterNodeTypes={filterTypes}
          onNodeClick={handleNodeClick}
          maxVisible={3000}
        />
      ) : (
        <GraphCanvas
          nodes={nodes}
          edges={edges}
          filterNodeTypes={filterTypes}
          onNodeClick={handleNodeClick}
          maxVisible={500}
        />
      )}

      {/* Metrics Overlay (top-left) */}
      <GraphMetrics
        nodes={nodes}
        edgeCount={edges.length}
        eventRate={eventRate}
        connected={connected}
        paused={paused}
      />

      {/* Controls (top-right) */}
      <GraphControls
        paused={paused}
        onTogglePause={togglePause}
        onReconnect={reconnect}
        filterNodeTypes={filterTypes}
        onFilterChange={setFilterTypes}
      />

      {/* Mode Toggles (top-center) */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1">
        {/* Engine toggle */}
        <button
          onClick={() => setEngine3D(false)}
          className={`rounded-l-lg px-3 py-1.5 text-xs font-mono transition-all border ${
            !engine3D
              ? 'bg-blue-500/20 text-blue-400 border-blue-500/40'
              : 'bg-nexum-surface/60 text-nexum-muted border-nexum-border/40 hover:text-nexum-text'
          }`}
        >
          2D
        </button>
        <button
          onClick={() => setEngine3D(true)}
          className={`px-3 py-1.5 text-xs font-mono transition-all border-y ${
            engine3D
              ? 'bg-[#d4a843]/20 text-[#d4a843] border-[#d4a843]/40'
              : 'bg-nexum-surface/60 text-nexum-muted border-nexum-border/40 hover:text-nexum-text'
          }`}
        >
          3D
        </button>

        <div className="w-px h-5 bg-nexum-border/40 mx-1" />

        {/* Data source toggle */}
        <button
          onClick={() => setDemoMode(false)}
          className={`px-3 py-1.5 text-xs font-mono transition-all border ${
            !demoMode
              ? 'bg-nexum-accent/20 text-nexum-accent border-nexum-accent/40'
              : 'bg-nexum-surface/60 text-nexum-muted border-nexum-border/40 hover:text-nexum-text'
          }`}
        >
          Live
        </button>
        <button
          onClick={() => setDemoMode(true)}
          className={`rounded-r-lg px-3 py-1.5 text-xs font-mono transition-all border ${
            demoMode
              ? 'bg-nexum-success/20 text-nexum-success border-nexum-success/40'
              : 'bg-nexum-surface/60 text-nexum-muted border-nexum-border/40 hover:text-nexum-text'
          }`}
        >
          Demo {demoStats ? `(${Object.values(demoStats).reduce((a, b) => a + b, 0).toLocaleString()})` : ''}
        </button>
      </div>

      {/* DB Stats Bar (bottom) */}
      {dbStats && (
        <div className="absolute bottom-0 left-0 right-0 bg-nexum-bg/80 backdrop-blur-sm border-t border-nexum-border/40 px-6 py-2 flex items-center gap-6 z-20">
          <span className="text-xs font-mono text-nexum-muted">
            {demoMode ? '✦ Demo:' : 'Graph DB:'}
          </span>
          {Object.entries(dbStats).map(([key, val]) => (
            <span key={key} className="text-xs font-mono">
              <span className="text-nexum-muted">{key.replace('_count', '').replace('_', ' ')}: </span>
              <span className="text-nexum-text tabular-nums">{(val as number).toLocaleString()}</span>
            </span>
          ))}
        </div>
      )}

      {/* Selected Node Panel */}
      {selectedNode && (
        <div className="absolute bottom-12 right-4 bg-nexum-bg/95 backdrop-blur-md border border-nexum-border/60 rounded-lg p-4 max-w-sm z-20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-nexum-accent">{selectedNode.type}</span>
            <button onClick={() => setSelectedNode(null)} className="text-nexum-muted hover:text-nexum-text text-xs">✕</button>
          </div>
          <p className="text-sm font-mono text-nexum-text break-all">{selectedNode.id}</p>
          {nodes.get(selectedNode.id)?.data && (
            <pre className="mt-2 text-[10px] font-mono text-nexum-muted overflow-auto max-h-32">
              {JSON.stringify(nodes.get(selectedNode.id)!.data, null, 2)}
            </pre>
          )}
        </div>
      )}

      {/* Event Feed */}
      <div className="absolute bottom-12 left-4 bg-nexum-bg/80 backdrop-blur-sm border border-nexum-border/40 rounded-lg p-2 max-w-xs max-h-32 overflow-hidden z-10">
        <span className="text-[10px] font-mono text-nexum-muted block mb-1">
          Event Feed ({events.length})
        </span>
        <div className="space-y-0.5 overflow-y-auto max-h-24">
          {events.slice(-8).reverse().map((e, i) => (
            <div key={`${e.timestamp}-${i}`} className="text-[10px] font-mono text-nexum-muted/70 truncate">
              <span className="text-nexum-accent/60">{e.event_type}</span>
              {e.node_id && <span> {e.node_id.slice(0, 8)}…</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
