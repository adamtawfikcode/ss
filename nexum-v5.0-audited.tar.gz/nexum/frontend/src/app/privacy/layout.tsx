import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Privacy Policy — Nexum',
  description:
    'Nexum Privacy Policy. Learn how we collect, use, and protect information in connection with our multimodal search and analysis services.',
  robots: 'index, follow',
};

export default function PrivacyLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
