'use client';

import Link from 'next/link';

const EFFECTIVE_DATE = 'February 11, 2026';

export default function PrivacyPolicyPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      {/* ── Header ───────────────────────────────────────────────── */}
      <header className="mb-12">
        <p className="text-xs font-mono uppercase tracking-widest text-nexum-accent mb-3">
          Legal
        </p>
        <h1 className="font-display text-4xl text-nexum-text leading-tight">
          Privacy Policy
        </h1>
        <div className="mt-4 flex items-center gap-4 text-sm text-nexum-muted">
          <span>Effective: {EFFECTIVE_DATE}</span>
          <span className="text-nexum-border">·</span>
          <span>Last Updated: {EFFECTIVE_DATE}</span>
        </div>
        <div className="mt-6 h-px bg-gradient-to-r from-nexum-accent/40 via-nexum-border/40 to-transparent" />
      </header>

      {/* ── Table of Contents ────────────────────────────────────── */}
      <nav className="mb-12 rounded-xl border border-nexum-border/50 bg-nexum-surface/60 p-6">
        <p className="text-xs font-mono uppercase tracking-wider text-nexum-muted mb-3">Contents</p>
        <ol className="columns-2 gap-8 text-sm leading-relaxed">
          {[
            'Introduction',
            'Information We Collect',
            'Public vs. Private Data',
            'How Information Is Used',
            'Data Retention',
            'Data Deletion & User Rights',
            'Cookies & Analytics',
            'Third-Party Services',
            'Security',
            'Children\u2019s Privacy',
            'Changes to This Policy',
            'Contact Information',
          ].map((title, i) => (
            <li key={i} className="py-0.5">
              <a
                href={`#section-${i + 1}`}
                className="text-nexum-muted hover:text-nexum-accent transition-colors"
              >
                <span className="font-mono text-nexum-accent/60 mr-1.5">{i + 1}.</span>
                {title}
              </a>
            </li>
          ))}
        </ol>
      </nav>

      {/* ── Policy Body ──────────────────────────────────────────── */}
      <article className="policy-body space-y-10 text-[15px] leading-relaxed text-nexum-text/90">

        {/* 1 */}
        <Section id="section-1" number={1} title="Introduction">
          <P>
            This Privacy Policy describes how the Nexum platform (&ldquo;Nexum,&rdquo; &ldquo;we,&rdquo; &ldquo;our,&rdquo; or &ldquo;us&rdquo;) collects, uses, stores, and protects information in connection with its multimodal search and analysis services. Nexum is a research and analytical tool that indexes publicly available media content from third-party platforms to enable intelligent search, discovery, and insight generation.
          </P>
          <P>
            By accessing or using Nexum, you acknowledge that you have read, understood, and agree to the practices described in this Privacy Policy. If you do not agree with this policy, you should not use Nexum.
          </P>
          <P>
            This policy applies to all users of the Nexum platform, including its web interface, application programming interfaces (APIs), and any associated services.
          </P>
        </Section>

        {/* 2 */}
        <Section id="section-2" number={2} title="Information We Collect">

          <H3>2.1 Publicly Available Content</H3>
          <P>
            Nexum indexes and analyzes content that is publicly accessible on third-party platforms, including but not limited to video-sharing sites, social media platforms, and public broadcast archives. The categories of publicly available data we process include:
          </P>
          <UL>
            <Li>Video metadata (titles, descriptions, publication dates, view counts, channel information)</Li>
            <Li>Publicly visible user comments and engagement data</Li>
            <Li>Visual content from video frames (scene descriptions, on-screen text, detected objects)</Li>
            <Li>Audio content (transcribed speech, detected sound events, musical attributes)</Li>
            <Li>Publicly available channel and creator profile information</Li>
          </UL>

          <H3>2.2 Derived Analytical Data</H3>
          <P>
            Through automated analysis, Nexum generates derivative data products that do not exist on the original platforms. These include:
          </P>
          <UL>
            <Li>Machine-generated transcripts of spoken content</Li>
            <Li>Text and visual embeddings (mathematical representations used for similarity search)</Li>
            <Li>Scene classification tags, object detection labels, and on-screen text extractions</Li>
            <Li>Audio analysis outputs such as sound event classifications, musical attribute estimations, and acoustic quality scores</Li>
            <Li>Confidence and quality scores associated with all analytical outputs</Li>
            <Li>Relationship graphs connecting content, topics, entities, and public commenters</Li>
            <Li>Sentiment analysis and topical classification of public comments</Li>
          </UL>

          <H3>2.3 User-Provided Information</H3>
          <P>When you interact with Nexum directly, we may collect:</P>
          <UL>
            <Li>Search queries and filter preferences</Li>
            <Li>Feedback signals (such as relevance ratings on search results)</Li>
            <Li>Account registration information, if applicable (email address, display name)</Li>
            <Li>Communications you send to us (support requests, feature suggestions)</Li>
          </UL>

          <H3>2.4 Automatically Collected Technical Data</H3>
          <P>When you access Nexum, we may automatically collect standard technical information, including:</P>
          <UL>
            <Li>IP address and approximate geolocation</Li>
            <Li>Browser type, operating system, and device identifiers</Li>
            <Li>Pages visited, features used, and session duration</Li>
            <Li>Referral URLs and search terms that led you to Nexum</Li>
          </UL>
        </Section>

        {/* 3 */}
        <Section id="section-3" number={3} title="Public vs. Private Data Clarification">
          <P>
            <Strong>Nexum indexes publicly available content only.</Strong> We do not access, collect, or process private, unlisted, restricted, or subscriber-only content from any platform. All media content analyzed by Nexum was publicly accessible at the time of indexing.
          </P>
          <P>
            <Strong>Nexum does not host or redistribute original media files.</Strong> We do not store, serve, or redistribute video files, audio recordings, or image files from third-party platforms. All original media remains on its respective source platform, subject to that platform&rsquo;s own terms of service and content policies. Nexum stores only derived analytical data&mdash;such as transcripts, tags, embeddings, and scores&mdash;which are the product of our own automated analysis.
          </P>
          <P>
            When Nexum displays links, thumbnails, or timecoded references, these point directly to the original content on its source platform. Nexum acts as an analytical index and does not serve as an alternative hosting service.
          </P>
          <P>
            Public comments indexed by Nexum reflect content that was voluntarily published by users on third-party platforms. Nexum analyzes and categorizes this content for research and search purposes but does not alter, republish, or decontextualize individual comments.
          </P>
        </Section>

        {/* 4 */}
        <Section id="section-4" number={4} title="How Information Is Used">
          <P>We use the information described above for the following purposes:</P>
          <UL>
            <Li><Strong>Search and Discovery:</Strong> To power multimodal search across text, visual, audio, and contextual signals, enabling users to find specific moments, topics, and patterns within indexed content.</Li>
            <Li><Strong>Analytical Intelligence:</Strong> To generate confidence-calibrated quality assessments, alignment analyses, acoustic characterizations, and other derived insights about indexed media.</Li>
            <Li><Strong>Knowledge Graphs:</Strong> To build relationship maps between content, topics, entities, and public discourse, enabling contextual exploration and pattern recognition.</Li>
            <Li><Strong>Platform Improvement:</Strong> To refine search relevance, calibrate analytical models, and improve the accuracy and utility of Nexum&rsquo;s features based on aggregated usage patterns and user feedback.</Li>
            <Li><Strong>Service Operations:</Strong> To maintain system performance, monitor for abuse, enforce our terms of service, and ensure the stability and security of the platform.</Li>
            <Li><Strong>Communications:</Strong> To respond to user inquiries, provide technical support, and deliver service-related notifications.</Li>
          </UL>
          <Callout>
            Nexum does not sell, rent, lease, or trade personal data to third parties for marketing, advertising, or any commercial purpose unrelated to the operation of the platform.
          </Callout>
        </Section>

        {/* 5 */}
        <Section id="section-5" number={5} title="Data Retention">
          <P>We retain different categories of data for different periods, based on operational necessity and legal requirements:</P>
          <UL>
            <Li><Strong>Indexed Public Content:</Strong> Metadata, derived analytics, and search indices for publicly available content are retained for as long as the source content remains publicly accessible, or until removal is requested by the content owner or platform operator.</Li>
            <Li><Strong>User Account Data:</Strong> Account information is retained for the duration of your account&rsquo;s active status and for a reasonable period thereafter to comply with legal obligations and resolve disputes.</Li>
            <Li><Strong>Search and Feedback Data:</Strong> Search queries and relevance feedback may be retained in aggregated or anonymized form for model calibration and service improvement purposes.</Li>
            <Li><Strong>Technical Logs:</Strong> Server access logs and diagnostic data are retained for up to ninety (90) days and then automatically purged.</Li>
          </UL>
          <P>
            When source content is removed from its original platform or when a valid removal request is processed, Nexum will remove the corresponding derived analytical data within a commercially reasonable timeframe.
          </P>
        </Section>

        {/* 6 */}
        <Section id="section-6" number={6} title="Data Deletion and User Rights">
          <P>We respect the rights of individuals to control information associated with them. Depending on your jurisdiction, you may be entitled to the following rights:</P>
          <UL>
            <Li><Strong>Right of Access:</Strong> You may request confirmation of whether we process data related to you and obtain a copy of such data.</Li>
            <Li><Strong>Right to Correction:</Strong> You may request correction of inaccurate data associated with you.</Li>
            <Li><Strong>Right to Deletion:</Strong> You may request the deletion of data associated with you, subject to legal retention obligations.</Li>
            <Li><Strong>Right to Object:</Strong> You may object to certain processing activities, particularly those based on legitimate interest.</Li>
            <Li><Strong>Right to Data Portability:</Strong> Where applicable, you may request a machine-readable copy of data you have provided to us.</Li>
          </UL>
          <P>
            To exercise any of these rights, please contact us using the information provided in Section 12 of this policy. We will respond to verified requests within thirty (30) days, or within the timeframe required by applicable law.
          </P>
          <P>
            <Strong>Content Creators and Rights Holders:</Strong> If you are the creator or rights holder of content indexed by Nexum and wish to have your content and its associated analytical data removed from our platform, you may submit a removal request. We will process such requests promptly upon verification of ownership.
          </P>
          <P>
            <Strong>Public Comment Authors:</Strong> If you have authored a public comment on a third-party platform that has been indexed by Nexum, you may request its removal from our analytical index. Removal from Nexum does not affect the comment&rsquo;s presence on its original platform.
          </P>
        </Section>

        {/* 7 */}
        <Section id="section-7" number={7} title="Cookies and Analytics">
          <P>Nexum may use cookies and similar technologies for the following purposes:</P>
          <UL>
            <Li><Strong>Essential Cookies:</Strong> Required for basic platform functionality, including session management, authentication, and security protections. These cannot be disabled while using the service.</Li>
            <Li><Strong>Preference Cookies:</Strong> Used to remember your settings, such as search filter preferences, interface configuration, and language selection.</Li>
            <Li><Strong>Analytics:</Strong> We may use first-party analytics to understand aggregate usage patterns, feature adoption, and performance metrics. This data is used solely to improve Nexum and is not shared with third-party advertising networks.</Li>
          </UL>
          <P>
            Nexum does not use third-party advertising cookies or tracking pixels. We do not participate in cross-site behavioral advertising or retargeting programs.
          </P>
          <P>
            You may configure your browser to refuse cookies or alert you when cookies are being sent. Note that some features of Nexum may not function properly if cookies are disabled.
          </P>
        </Section>

        {/* 8 */}
        <Section id="section-8" number={8} title="Third-Party Services">
          <P>Nexum integrates with or relies upon the following categories of third-party services in the course of its operations:</P>
          <UL>
            <Li><Strong>Content Source Platforms:</Strong> Nexum indexes publicly available content from video-sharing and social media platforms. Your interaction with content on those platforms is governed by their respective privacy policies and terms of service.</Li>
            <Li><Strong>Infrastructure Providers:</Strong> We use third-party cloud infrastructure, database, and storage providers to host and operate the Nexum platform. These providers process data on our behalf under contractual obligations to maintain confidentiality and security.</Li>
            <Li><Strong>Open-Source Machine Learning Models:</Strong> Nexum uses open-source models for transcription, visual analysis, text understanding, and audio classification. These models run locally within our infrastructure; your data is not transmitted to external model providers for inference.</Li>
          </UL>

          <H3>8.1 YouTube API Services</H3>
          <P>
            Nexum&rsquo;s use of YouTube content is performed in compliance with the <Strong>YouTube Terms of Service</Strong> (<Anchor href="https://www.youtube.com/t/terms">https://www.youtube.com/t/terms</Anchor>) and the <Strong>Google Privacy Policy</Strong> (<Anchor href="https://policies.google.com/privacy">https://policies.google.com/privacy</Anchor>). By using Nexum to access or interact with content sourced from YouTube, you also agree to be bound by the YouTube Terms of Service.
          </P>
          <P>
            Nexum accesses YouTube data through YouTube API Services. In accordance with the YouTube API Services Terms of Service, we wish to inform you that:
          </P>
          <UL>
            <Li>Nexum&rsquo;s access to YouTube data is subject to the YouTube API Services Terms of Service (<Anchor href="https://developers.google.com/youtube/terms/api-services-terms-of-service">https://developers.google.com/youtube/terms/api-services-terms-of-service</Anchor>).</Li>
            <Li>Google&rsquo;s Privacy Policy applies to YouTube data accessed through its API Services.</Li>
            <Li>You may revoke Nexum&rsquo;s access to your YouTube data, if any, via the Google security settings page at <Anchor href="https://security.google.com/settings/security/permissions">https://security.google.com/settings/security/permissions</Anchor>.</Li>
          </UL>
        </Section>

        {/* 9 */}
        <Section id="section-9" number={9} title="Security">
          <P>We implement and maintain reasonable administrative, technical, and physical safeguards designed to protect the information we process. These measures include:</P>
          <UL>
            <Li>Encryption of data in transit using industry-standard transport layer security (TLS)</Li>
            <Li>Access controls and authentication requirements for administrative systems</Li>
            <Li>Regular security reviews and vulnerability assessments</Li>
            <Li>Network segmentation and monitoring for unauthorized access attempts</Li>
            <Li>Principle of least privilege applied to internal system access</Li>
          </UL>
          <P>
            <Strong>No method of electronic transmission or storage is perfectly secure.</Strong> While we strive to protect the information we process, we cannot guarantee absolute security. We encourage users to take appropriate measures to protect their own account credentials and to report any suspected security concerns to us promptly.
          </P>
          <P>
            In the event of a data breach that affects personal information, we will notify affected users and relevant authorities in accordance with applicable law.
          </P>
        </Section>

        {/* 10 */}
        <Section id="section-10" number={10} title="Children&rsquo;s Privacy">
          <P>
            Nexum is not directed at, designed for, or intended to be used by individuals under the age of sixteen (16). We do not knowingly collect personal information from children under 16.
          </P>
          <P>
            If we become aware that we have inadvertently collected personal information from a child under 16, we will take reasonable steps to delete that information promptly. If you believe that a child under 16 has provided personal information to Nexum, please contact us using the information in Section 12 so that we can take appropriate action.
          </P>
          <P>
            Content indexed by Nexum may include publicly available media featuring or created by minors. Nexum processes this content in the same analytical manner as all other publicly available content. If you are a parent or guardian and believe that your child&rsquo;s content should be removed from our analytical index, please submit a removal request as described in Section 6.
          </P>
        </Section>

        {/* 11 */}
        <Section id="section-11" number={11} title="Changes to This Policy">
          <P>We may update this Privacy Policy from time to time to reflect changes in our practices, technologies, legal requirements, or other factors. When we make material changes, we will:</P>
          <UL>
            <Li>Update the &ldquo;Effective Date&rdquo; and &ldquo;Last Updated&rdquo; dates at the top of this document</Li>
            <Li>Provide a prominent notice on the Nexum platform for at least thirty (30) days following the change</Li>
            <Li>Where required by law, seek your renewed consent before applying changes that materially affect how your personal information is processed</Li>
          </UL>
          <P>
            We encourage you to review this policy periodically. Your continued use of Nexum after the effective date of any revised policy constitutes your acceptance of the updated terms.
          </P>
          <P>Prior versions of this Privacy Policy are available upon request.</P>
        </Section>

        {/* 12 */}
        <Section id="section-12" number={12} title="Contact Information">
          <P>If you have questions, concerns, or requests regarding this Privacy Policy or Nexum&rsquo;s data practices, you may contact us at:</P>
          <div className="my-4 rounded-lg border border-nexum-border/50 bg-nexum-surface/60 p-5 space-y-1.5 text-sm">
            <p className="font-semibold text-nexum-text">Nexum Privacy Team</p>
            <p>Email: <Anchor href="mailto:privacy@nexum.app">privacy@nexum.app</Anchor></p>
            <p>General Inquiries: <Anchor href="mailto:contact@nexum.app">contact@nexum.app</Anchor></p>
            <p>Content Removal Requests: <Anchor href="mailto:removal@nexum.app">removal@nexum.app</Anchor></p>
          </div>
          <P>
            We aim to respond to all privacy-related inquiries within thirty (30) days of receipt. For requests that require extended processing time, we will acknowledge receipt and provide an estimated completion date.
          </P>
          <P>
            If you are dissatisfied with our response to a privacy concern, you may have the right to lodge a complaint with your local data protection authority.
          </P>
        </Section>

      </article>

      {/* ── Footer rule ──────────────────────────────────────────── */}
      <div className="mt-16 pt-6 border-t border-nexum-border/40">
        <p className="text-xs text-nexum-muted italic">
          This Privacy Policy was last updated on {EFFECTIVE_DATE}.
        </p>
        <Link
          href="/"
          className="mt-3 inline-flex items-center gap-1.5 text-sm text-nexum-accent hover:underline"
        >
          &larr; Back to Nexum
        </Link>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Typography Components
// ═══════════════════════════════════════════════════════════════════════

function Section({ id, number, title, children }: { id: string; number: number; title: string; children: React.ReactNode }) {
  return (
    <section id={id}>
      <h2 className="font-display text-2xl text-nexum-text mb-4 scroll-mt-20">
        <span className="font-mono text-nexum-accent/70 mr-2">{number}.</span>
        {title}
      </h2>
      {children}
    </section>
  );
}

function H3({ children }: { children: React.ReactNode }) {
  return <h3 className="font-body text-lg font-semibold text-nexum-text mt-6 mb-2">{children}</h3>;
}

function P({ children }: { children: React.ReactNode }) {
  return <p className="mb-3 text-nexum-text/85 leading-relaxed">{children}</p>;
}

function Strong({ children }: { children: React.ReactNode }) {
  return <strong className="font-semibold text-nexum-text">{children}</strong>;
}

function UL({ children }: { children: React.ReactNode }) {
  return <ul className="mb-4 ml-5 space-y-1.5 list-disc marker:text-nexum-accent/50">{children}</ul>;
}

function Li({ children }: { children: React.ReactNode }) {
  return <li className="text-nexum-text/85 leading-relaxed pl-1">{children}</li>;
}

function Anchor({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-nexum-accent hover:underline break-all"
    >
      {children}
    </a>
  );
}

function Callout({ children }: { children: React.ReactNode }) {
  return (
    <div className="my-4 rounded-lg border-l-4 border-nexum-accent/60 bg-nexum-accent/5 px-5 py-4 text-sm font-semibold text-nexum-text/90">
      {children}
    </div>
  );
}
