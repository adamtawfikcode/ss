'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Clock,
  Eye,
  ExternalLink,
  ScanText,
  ImageIcon,
  MessageSquare,
  Activity,
} from 'lucide-react';
import { getVideo } from '@/lib/api';
import type { Video, Segment, Frame } from '@/lib/types';
import { formatTimestamp, formatDuration, formatViews, videoUrlWithTimestamp, confidenceColor } from '@/lib/utils';

export default function VideoDetailPage() {
  const params = useParams();
  const [video, setVideo] = useState<Video | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'transcript' | 'visual' | 'ocr'>('transcript');
  const [selectedTime, setSelectedTime] = useState<number | null>(null);

  useEffect(() => {
    if (params.id) {
      setLoading(true);
      getVideo(Number(params.id))
        .then(setVideo)
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [params.id]);

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl px-6 py-12">
        <div className="h-8 w-48 rounded-lg shimmer mb-6" />
        <div className="h-64 rounded-2xl shimmer mb-6" />
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 rounded-lg shimmer" />
          ))}
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="mx-auto max-w-5xl px-6 py-16 text-center">
        <h2 className="font-display text-2xl text-nexum-text">Video not found</h2>
        <Link href="/" className="mt-4 inline-flex items-center gap-1.5 text-sm text-nexum-accent hover:underline">
          <ArrowLeft size={14} /> Back to search
        </Link>
      </div>
    );
  }

  const segments = video.segments?.sort((a, b) => a.start_time - b.start_time) || [];
  const frames = video.frames?.sort((a, b) => a.timestamp - b.timestamp) || [];
  const ocrFrames = frames.filter((f) => f.ocr_text);

  // Build timeline heatmap (bucketed by 10s intervals)
  const totalDuration = video.duration_seconds || 1;
  const bucketSize = Math.max(10, Math.ceil(totalDuration / 60));
  const bucketCount = Math.ceil(totalDuration / Math.max(bucketSize, 1));
  const buckets = Array.from({ length: bucketCount }, (_, i) => {
    const start = i * bucketSize;
    const end = start + bucketSize;
    const segCount = segments.filter(
      (s) => s.start_time < end && s.end_time > start
    ).length;
    const frameCount = frames.filter(
      (f) => f.timestamp >= start && f.timestamp < end
    ).length;
    return { start, density: segCount + frameCount };
  });
  const maxDensity = Math.max(1, ...buckets.map((b) => b.density));

  return (
    <div className="mx-auto max-w-5xl px-6 py-8">
      {/* Back + header */}
      <Link
        href="/"
        className="mb-6 inline-flex items-center gap-1.5 text-sm text-nexum-muted hover:text-nexum-accent transition-colors"
      >
        <ArrowLeft size={14} /> Back to search
      </Link>

      <div className="mb-6 animate-fade-in">
        <h1 className="font-display text-2xl sm:text-3xl text-nexum-text leading-snug">
          {video.title}
        </h1>
        <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-nexum-muted">
          <span>{video.channel?.name}</span>
          <span className="text-nexum-border">·</span>
          <span className="flex items-center gap-1"><Clock size={13} /> {formatDuration(video.duration_seconds)}</span>
          <span className="text-nexum-border">·</span>
          <span className="flex items-center gap-1"><Eye size={13} /> {formatViews(video.view_count)}</span>
          <span className="text-nexum-border">·</span>
          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-mono ${
            video.status === 'indexed'
              ? 'bg-nexum-success/15 text-nexum-success'
              : video.status === 'processing'
              ? 'bg-nexum-warn/15 text-nexum-warn'
              : 'bg-nexum-muted/15 text-nexum-muted'
          }`}>
            <Activity size={10} />
            {video.status}
          </span>
          <a
            href={video.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-nexum-accent hover:underline"
          >
            <ExternalLink size={13} /> Watch on YouTube
          </a>
        </div>
      </div>

      {/* Timeline heatmap */}
      <div className="mb-6 animate-slide-up">
        <h3 className="mb-2 text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
          Content Density Timeline
        </h3>
        <div className="flex h-8 gap-px rounded-lg overflow-hidden border border-nexum-border/30">
          {buckets.map((b, i) => {
            const intensity = b.density / maxDensity;
            return (
              <button
                key={i}
                onClick={() => setSelectedTime(b.start)}
                className="heatmap-cell flex-1 transition-all hover:opacity-90"
                style={{
                  backgroundColor: `rgba(212, 168, 67, ${0.05 + intensity * 0.5})`,
                }}
                title={`${formatTimestamp(b.start)} — ${b.density} items`}
              />
            );
          })}
        </div>
        <div className="mt-1 flex justify-between text-[10px] font-mono text-nexum-muted/50">
          <span>0:00</span>
          <span>{formatTimestamp(totalDuration)}</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-4 flex gap-1 rounded-xl border border-nexum-border/40 bg-nexum-surface/50 p-1 w-fit">
        {([
          { key: 'transcript', icon: MessageSquare, label: 'Transcript', count: segments.length },
          { key: 'visual', icon: ImageIcon, label: 'Visual Tags', count: frames.length },
          { key: 'ocr', icon: ScanText, label: 'OCR Text', count: ocrFrames.length },
        ] as const).map(({ key, icon: Icon, label, count }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-body transition-all ${
              activeTab === key
                ? 'bg-nexum-accent/15 text-nexum-accent'
                : 'text-nexum-muted hover:text-nexum-text'
            }`}
          >
            <Icon size={12} />
            {label}
            <span className="font-mono text-[10px] opacity-60">({count})</span>
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="space-y-1 animate-fade-in">
        {activeTab === 'transcript' &&
          segments.map((seg) => (
            <SegmentRow key={seg.id} segment={seg} videoUrl={video.url} isHighlighted={selectedTime !== null && seg.start_time <= selectedTime && seg.end_time > selectedTime} />
          ))}

        {activeTab === 'visual' &&
          frames.map((frame) => (
            <FrameRow key={frame.id} frame={frame} videoUrl={video.url} isHighlighted={selectedTime !== null && Math.abs(frame.timestamp - selectedTime) < 10} />
          ))}

        {activeTab === 'ocr' &&
          ocrFrames.map((frame) => (
            <OcrRow key={frame.id} frame={frame} videoUrl={video.url} isHighlighted={selectedTime !== null && Math.abs(frame.timestamp - selectedTime) < 10} />
          ))}

        {((activeTab === 'transcript' && segments.length === 0) ||
          (activeTab === 'visual' && frames.length === 0) ||
          (activeTab === 'ocr' && ocrFrames.length === 0)) && (
          <div className="py-12 text-center text-sm text-nexum-muted">
            No {activeTab} data available for this video.
          </div>
        )}
      </div>
    </div>
  );
}

function SegmentRow({ segment, videoUrl, isHighlighted }: { segment: Segment; videoUrl: string; isHighlighted: boolean }) {
  return (
    <a
      href={videoUrlWithTimestamp(videoUrl, segment.start_time)}
      target="_blank"
      rel="noopener noreferrer"
      className={`flex items-start gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-nexum-elevated/50 ${
        isHighlighted ? 'bg-nexum-accent/10 border-l-2 border-nexum-accent' : ''
      }`}
    >
      <span className="mt-0.5 w-14 flex-shrink-0 text-right text-xs font-mono text-nexum-accent/70">
        {formatTimestamp(segment.start_time)}
      </span>
      <span className="flex-1 text-sm font-body text-nexum-text/80 leading-relaxed">
        {segment.text}
      </span>
      <span
        className="mt-0.5 h-1.5 w-1.5 flex-shrink-0 rounded-full"
        style={{ backgroundColor: confidenceColor(segment.confidence) }}
      />
    </a>
  );
}

function FrameRow({ frame, videoUrl, isHighlighted }: { frame: Frame; videoUrl: string; isHighlighted: boolean }) {
  const tags = frame.visual_tags ? Object.entries(frame.visual_tags).sort((a, b) => (b[1] as number) - (a[1] as number)) : [];
  return (
    <a
      href={videoUrlWithTimestamp(videoUrl, frame.timestamp)}
      target="_blank"
      rel="noopener noreferrer"
      className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-nexum-elevated/50 ${
        isHighlighted ? 'bg-nexum-accent/10 border-l-2 border-nexum-accent' : ''
      }`}
    >
      <span className="w-14 flex-shrink-0 text-right text-xs font-mono text-nexum-accent/70">
        {formatTimestamp(frame.timestamp)}
      </span>
      <div className="flex flex-1 flex-wrap gap-1">
        {tags.slice(0, 6).map(([label, score]) => (
          <span
            key={label}
            className="rounded-md bg-nexum-accent/10 px-1.5 py-0.5 text-[11px] font-mono text-nexum-accent/70"
            title={`${(Number(score) * 100).toFixed(0)}%`}
          >
            {label}
          </span>
        ))}
      </div>
      {frame.is_scene_change && (
        <span className="rounded-full bg-nexum-info/15 px-2 py-0.5 text-[10px] font-mono text-nexum-info">
          scene cut
        </span>
      )}
    </a>
  );
}

function OcrRow({ frame, videoUrl, isHighlighted }: { frame: Frame; videoUrl: string; isHighlighted: boolean }) {
  return (
    <a
      href={videoUrlWithTimestamp(videoUrl, frame.timestamp)}
      target="_blank"
      rel="noopener noreferrer"
      className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-nexum-elevated/50 ${
        isHighlighted ? 'bg-nexum-accent/10 border-l-2 border-nexum-accent' : ''
      }`}
    >
      <span className="w-14 flex-shrink-0 text-right text-xs font-mono text-nexum-accent/70">
        {formatTimestamp(frame.timestamp)}
      </span>
      <span className="flex-1 text-sm font-mono text-nexum-success/80">
        {frame.ocr_text}
      </span>
      <span
        className="h-1.5 w-1.5 flex-shrink-0 rounded-full"
        style={{ backgroundColor: confidenceColor(frame.ocr_confidence) }}
      />
    </a>
  );
}
