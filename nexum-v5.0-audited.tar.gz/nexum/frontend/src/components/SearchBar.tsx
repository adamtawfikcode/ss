'use client';

import { useState, useRef, useEffect } from 'react';
import { Search, Sparkles, X, Loader2 } from 'lucide-react';
import type { QueryAnalysis } from '@/lib/types';

interface SearchBarProps {
  onSearch: (query: string) => void;
  isLoading?: boolean;
  queryAnalysis?: QueryAnalysis | null;
}

const SUGGESTIONS = [
  'guy struggling playing tetris at score 1296',
  'explanation of fourier transform with animations',
  'react hooks tutorial with code examples',
  'cooking pasta in a busy kitchen',
  'someone debugging a Python error',
  'math equation on whiteboard being solved',
];

export default function SearchBar({ onSearch, isLoading, queryAnalysis }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);
  const [placeholderIdx, setPlaceholderIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIdx((i) => (i + 1) % SUGGESTIONS.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) onSearch(query.trim());
  };

  const handleSuggestion = (s: string) => {
    setQuery(s);
    onSearch(s);
  };

  const analysisTags = queryAnalysis
    ? [
        ...queryAnalysis.objects.map((t) => ({ label: t, type: 'object' as const })),
        ...queryAnalysis.actions.map((t) => ({ label: t, type: 'action' as const })),
        ...queryAnalysis.numbers.map((t) => ({ label: t, type: 'number' as const })),
        ...queryAnalysis.emotion.map((t) => ({ label: t, type: 'emotion' as const })),
        ...queryAnalysis.context.map((t) => ({ label: t, type: 'context' as const })),
      ]
    : [];

  const tagColor: Record<string, string> = {
    object: 'bg-nexum-info/15 text-nexum-info border-nexum-info/30',
    action: 'bg-nexum-accent/15 text-nexum-accent border-nexum-accent/30',
    number: 'bg-nexum-success/15 text-nexum-success border-nexum-success/30',
    emotion: 'bg-nexum-warn/15 text-nexum-warn border-nexum-warn/30',
    context: 'bg-nexum-muted/15 text-nexum-muted border-nexum-muted/30',
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="relative group">
        <div
          className={`
            relative flex items-center rounded-2xl border transition-all duration-300
            bg-nexum-surface/80 backdrop-blur-sm
            ${focused
              ? 'border-nexum-accent/50 shadow-[0_0_24px_-4px_#d4a84320]'
              : 'border-nexum-border hover:border-nexum-border/80'
            }
          `}
        >
          <div className="pl-5 pr-2 text-nexum-muted">
            {isLoading ? (
              <Loader2 size={20} className="animate-spin text-nexum-accent" />
            ) : (
              <Search size={20} />
            )}
          </div>

          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder={SUGGESTIONS[placeholderIdx]}
            className="flex-1 bg-transparent py-4 pr-2 text-base font-body text-nexum-text placeholder:text-nexum-muted/50 focus:outline-none"
            aria-label="Search videos"
          />

          {query && (
            <button
              type="button"
              onClick={() => { setQuery(''); inputRef.current?.focus(); }}
              className="p-1.5 mr-1 rounded-lg text-nexum-muted hover:text-nexum-text hover:bg-nexum-elevated transition-colors"
            >
              <X size={16} />
            </button>
          )}

          <button
            type="submit"
            disabled={!query.trim() || isLoading}
            className={`
              mr-2 flex items-center gap-1.5 rounded-xl px-5 py-2 text-sm font-medium transition-all
              ${query.trim()
                ? 'bg-nexum-accent text-nexum-bg hover:bg-nexum-accent/90 active:scale-95'
                : 'bg-nexum-elevated text-nexum-muted cursor-not-allowed'
              }
            `}
          >
            <Sparkles size={14} />
            Search
          </button>
        </div>
      </form>

      {/* Query decomposition tags */}
      {analysisTags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5 px-2 animate-fade-in">
          <span className="text-[11px] font-mono text-nexum-muted/60 mr-1 mt-0.5">parsed:</span>
          {analysisTags.map((tag, i) => (
            <span
              key={`${tag.type}-${tag.label}-${i}`}
              className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-mono ${tagColor[tag.type]}`}
            >
              <span className="opacity-60">{tag.type}:</span>
              {tag.label}
            </span>
          ))}
        </div>
      )}

      {/* Try these suggestions */}
      {!queryAnalysis && !isLoading && (
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {SUGGESTIONS.slice(0, 3).map((s) => (
            <button
              key={s}
              onClick={() => handleSuggestion(s)}
              className="rounded-lg border border-nexum-border/50 bg-nexum-surface/50 px-3 py-1.5 text-xs font-body text-nexum-muted hover:text-nexum-text hover:border-nexum-accent/30 hover:bg-nexum-elevated/50 transition-all"
            >
              &ldquo;{s}&rdquo;
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
