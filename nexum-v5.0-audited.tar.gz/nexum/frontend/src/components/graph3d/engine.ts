/**
 * Nexum Three.js Graph Engine — Low-End Safe 3D Visualization
 *
 * Architecture:
 *   SceneManager     — Three.js lifecycle, render loop, disposal
 *   NodeRenderer     — InstancedMesh for nodes (thousands at <1 draw call)
 *   EdgeRenderer     — BatchedLineSegments for edges
 *   LabelRenderer    — Sprite atlas for text labels
 *   ForceLayout      — Barnes-Hut force-directed layout
 *   InteractionManager — Raycaster, hover, click, camera
 *   PerformanceMonitor — FPS detection, adaptive quality scaling
 *   LODManager       — Level of detail, frustum culling, clustering
 *
 * Performance targets:
 *   60 FPS mid-range, 30 FPS minimum low-end
 *   <300 MB VRAM
 *   Graceful degradation on integrated GPUs
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// ═══════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════

export interface GraphNode3D {
  id: string;
  label: string;
  nodeType: string;
  x: number;
  y: number;
  z: number;
  size: number;
  color: string;
  data?: Record<string, any>;
}

export interface GraphEdge3D {
  source: string;
  target: string;
  edgeType: string;
  weight: number;
}

export type QualityLevel = 'ultra-low' | 'low' | 'medium' | 'high';

export interface EngineConfig {
  maxVisibleNodes: number;
  maxVisibleEdges: number;
  qualityLevel: QualityLevel;
  enableLabels: boolean;
  enableEdges: boolean;
  enableBloom: boolean;
  enableAnimation: boolean;
  backgroundColor: number;
  forceLayoutIterations: number;
  frustumCulling: boolean;
  adaptiveQuality: boolean;
}

const DEFAULT_CONFIG: EngineConfig = {
  maxVisibleNodes: 3000,
  maxVisibleEdges: 8000,
  qualityLevel: 'medium',
  enableLabels: true,
  enableEdges: true,
  enableBloom: false,
  enableAnimation: true,
  backgroundColor: 0x1a1916,
  forceLayoutIterations: 100,
  frustumCulling: true,
  adaptiveQuality: true,
};

const NODE_COLORS: Record<string, number> = {
  Video:         0xd4a843,
  Channel:       0xef4444,
  Comment:       0x6b7280,
  CommentAuthor: 0x3b82f6,
  Entity:        0x10b981,
  Topic:         0x8b5cf6,
  Playlist:      0xf59e0b,
  Segment:       0x6366f1,
};

const NODE_SIZES: Record<string, number> = {
  Video: 3.0, Channel: 4.0, Comment: 1.0, CommentAuthor: 2.0,
  Entity: 2.5, Topic: 3.0, Playlist: 2.5, Segment: 1.5,
};

// ═══════════════════════════════════════════════════════════════════════
// Performance Monitor
// ═══════════════════════════════════════════════════════════════════════

class PerformanceMonitor {
  private frameTimes: number[] = [];
  private lastTime = 0;
  private _fps = 60;
  private _qualityLevel: QualityLevel;
  private adaptiveEnabled: boolean;
  private downgradeCount = 0;
  private upgradeCount = 0;

  constructor(initial: QualityLevel, adaptive: boolean) {
    this._qualityLevel = initial;
    this.adaptiveEnabled = adaptive;
  }

  get fps(): number { return this._fps; }
  get qualityLevel(): QualityLevel { return this._qualityLevel; }

  tick(now: number): void {
    if (this.lastTime > 0) {
      const delta = now - this.lastTime;
      this.frameTimes.push(delta);
      if (this.frameTimes.length > 60) this.frameTimes.shift();
    }
    this.lastTime = now;

    if (this.frameTimes.length >= 30) {
      const avg = this.frameTimes.length > 0 ? this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length : 16.67;
      this._fps = Math.round(1000 / Math.max(avg, 1));
      if (this.adaptiveEnabled) this._adapt();
    }
  }

  private _adapt(): void {
    const levels: QualityLevel[] = ['ultra-low', 'low', 'medium', 'high'];
    const idx = levels.indexOf(this._qualityLevel);

    if (this._fps < 20 && idx > 0) {
      this.downgradeCount++;
      if (this.downgradeCount >= 3) {
        this._qualityLevel = levels[idx - 1];
        this.downgradeCount = 0;
        this.upgradeCount = 0;
      }
    } else if (this._fps > 55 && idx < levels.length - 1) {
      this.upgradeCount++;
      if (this.upgradeCount >= 10) {
        this._qualityLevel = levels[idx + 1];
        this.upgradeCount = 0;
        this.downgradeCount = 0;
      }
    } else {
      this.downgradeCount = Math.max(0, this.downgradeCount - 1);
      this.upgradeCount = Math.max(0, this.upgradeCount - 1);
    }
  }

  getQualityParams(): { nodeDetail: number; edgeFraction: number; labelDistance: number; maxNodes: number } {
    switch (this._qualityLevel) {
      case 'ultra-low': return { nodeDetail: 3, edgeFraction: 0.3, labelDistance: 50, maxNodes: 500 };
      case 'low':       return { nodeDetail: 6, edgeFraction: 0.5, labelDistance: 100, maxNodes: 1500 };
      case 'medium':    return { nodeDetail: 10, edgeFraction: 0.8, labelDistance: 200, maxNodes: 3000 };
      case 'high':      return { nodeDetail: 16, edgeFraction: 1.0, labelDistance: 400, maxNodes: 5000 };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Force Layout (Barnes-Hut)
// ═══════════════════════════════════════════════════════════════════════

export class ForceLayout {
  private positions: Map<string, THREE.Vector3> = new Map();
  private velocities: Map<string, THREE.Vector3> = new Map();
  private edges: GraphEdge3D[] = [];
  private alpha = 1.0;
  private alphaDecay = 0.02;
  private alphaMin = 0.001;

  setData(nodes: GraphNode3D[], edges: GraphEdge3D[]): void {
    this.edges = edges;
    this.alpha = 1.0;

    for (const node of nodes) {
      if (!this.positions.has(node.id)) {
        this.positions.set(node.id, new THREE.Vector3(
          node.x || (Math.random() - 0.5) * 200,
          node.y || (Math.random() - 0.5) * 200,
          node.z || (Math.random() - 0.5) * 200,
        ));
        this.velocities.set(node.id, new THREE.Vector3());
      }
    }

    // Remove stale nodes
    const ids = new Set(nodes.map(n => n.id));
    for (const key of this.positions.keys()) {
      if (!ids.has(key)) {
        this.positions.delete(key);
        this.velocities.delete(key);
      }
    }
  }

  step(): boolean {
    if (this.alpha < this.alphaMin) return false;

    const repulsionStrength = 500;
    const attractionStrength = 0.01;
    const damping = 0.6;
    const centerGravity = 0.01;

    // Repulsion (simplified O(n²) for <5000 nodes, fast enough)
    const ids = Array.from(this.positions.keys());
    const n = ids.length;

    for (let i = 0; i < n; i++) {
      const pos_i = this.positions.get(ids[i])!;
      const vel_i = this.velocities.get(ids[i])!;

      // Center gravity
      vel_i.x -= pos_i.x * centerGravity * this.alpha;
      vel_i.y -= pos_i.y * centerGravity * this.alpha;
      vel_i.z -= pos_i.z * centerGravity * this.alpha;

      for (let j = i + 1; j < n; j++) {
        const pos_j = this.positions.get(ids[j])!;
        const vel_j = this.velocities.get(ids[j])!;
        const dx = pos_i.x - pos_j.x;
        const dy = pos_i.y - pos_j.y;
        const dz = pos_i.z - pos_j.z;
        const dist2 = dx * dx + dy * dy + dz * dz + 1;
        const force = repulsionStrength * this.alpha / Math.max(dist2, 0.01);
        const fx = dx * force / Math.sqrt(dist2);
        const fy = dy * force / Math.sqrt(dist2);
        const fz = dz * force / Math.sqrt(dist2);
        vel_i.x += fx; vel_i.y += fy; vel_i.z += fz;
        vel_j.x -= fx; vel_j.y -= fy; vel_j.z -= fz;
      }
    }

    // Attraction along edges
    for (const edge of this.edges) {
      const ps = this.positions.get(edge.source);
      const pt = this.positions.get(edge.target);
      if (!ps || !pt) continue;
      const vs = this.velocities.get(edge.source)!;
      const vt = this.velocities.get(edge.target)!;

      const dx = pt.x - ps.x;
      const dy = pt.y - ps.y;
      const dz = pt.z - ps.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz + 1);
      const force = attractionStrength * dist * this.alpha * (edge.weight || 1);
      const safeDist = Math.max(dist, 0.001);
      const fx = dx * force / safeDist;
      const fy = dy * force / safeDist;
      const fz = dz * force / safeDist;
      vs.x += fx; vs.y += fy; vs.z += fz;
      vt.x -= fx; vt.y -= fy; vt.z -= fz;
    }

    // Apply velocities with damping
    for (const id of ids) {
      const pos = this.positions.get(id)!;
      const vel = this.velocities.get(id)!;
      vel.multiplyScalar(damping);
      // Cap velocity
      const speed = vel.length();
      if (speed > 10) vel.multiplyScalar(10 / speed);
      pos.add(vel);
    }

    this.alpha *= (1 - this.alphaDecay);
    return true;
  }

  getPosition(id: string): THREE.Vector3 | undefined {
    return this.positions.get(id);
  }

  reheat(): void {
    this.alpha = 0.5;
  }

  get isActive(): boolean {
    return this.alpha >= this.alphaMin;
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Node Renderer (Instanced Meshes)
// ═══════════════════════════════════════════════════════════════════════

class NodeRenderer {
  private instancedMeshes: Map<string, THREE.InstancedMesh> = new Map();
  private nodeIndexMap: Map<string, { type: string; index: number }> = new Map();
  private dummy = new THREE.Object3D();
  private scene: THREE.Scene;
  private colorObj = new THREE.Color();

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  rebuild(nodes: GraphNode3D[], qualityDetail: number): void {
    this.dispose();
    this.nodeIndexMap.clear();

    // Group nodes by type for instanced rendering
    const groups = new Map<string, GraphNode3D[]>();
    for (const node of nodes) {
      const arr = groups.get(node.nodeType) || [];
      arr.push(node);
      groups.set(node.nodeType, arr);
    }

    const geometry = new THREE.SphereGeometry(1, qualityDetail, qualityDetail);

    for (const [type, typeNodes] of groups) {
      const material = new THREE.MeshLambertMaterial({
        color: NODE_COLORS[type] || 0xcccccc,
      });

      const mesh = new THREE.InstancedMesh(geometry, material, typeNodes.length);
      mesh.frustumCulled = false; // we handle culling manually
      mesh.userData.nodeType = type;

      for (let i = 0; i < typeNodes.length; i++) {
        const node = typeNodes[i];
        this.nodeIndexMap.set(node.id, { type, index: i });

        this.dummy.position.set(node.x, node.y, node.z);
        const s = NODE_SIZES[type] || 2;
        this.dummy.scale.setScalar(s);
        this.dummy.updateMatrix();
        mesh.setMatrixAt(i, this.dummy.matrix);
      }

      mesh.instanceMatrix.needsUpdate = true;
      this.scene.add(mesh);
      this.instancedMeshes.set(type, mesh);
    }
  }

  updatePositions(nodes: GraphNode3D[], layout: ForceLayout): void {
    for (const node of nodes) {
      const info = this.nodeIndexMap.get(node.id);
      if (!info) continue;

      const mesh = this.instancedMeshes.get(info.type);
      if (!mesh) continue;

      const pos = layout.getPosition(node.id);
      if (!pos) continue;

      this.dummy.position.copy(pos);
      const s = NODE_SIZES[node.nodeType] || 2;
      this.dummy.scale.setScalar(s);
      this.dummy.updateMatrix();
      mesh.setMatrixAt(info.index, this.dummy.matrix);
    }

    for (const mesh of this.instancedMeshes.values()) {
      mesh.instanceMatrix.needsUpdate = true;
    }
  }

  highlightNode(nodeId: string, highlight: boolean): void {
    const info = this.nodeIndexMap.get(nodeId);
    if (!info) return;
    const mesh = this.instancedMeshes.get(info.type);
    if (!mesh) return;

    mesh.getMatrixAt(info.index, this.dummy.matrix);
    this.dummy.matrix.decompose(this.dummy.position, this.dummy.quaternion, this.dummy.scale);

    const baseSize = NODE_SIZES[info.type] || 2;
    this.dummy.scale.setScalar(highlight ? baseSize * 1.5 : baseSize);
    this.dummy.updateMatrix();
    mesh.setMatrixAt(info.index, this.dummy.matrix);
    mesh.instanceMatrix.needsUpdate = true;
  }

  getInstancedMeshes(): THREE.InstancedMesh[] {
    return Array.from(this.instancedMeshes.values());
  }

  dispose(): void {
    for (const mesh of this.instancedMeshes.values()) {
      this.scene.remove(mesh);
      mesh.geometry.dispose();
      (mesh.material as THREE.Material).dispose();
    }
    this.instancedMeshes.clear();
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Edge Renderer (Batched Lines)
// ═══════════════════════════════════════════════════════════════════════

class EdgeRenderer {
  private lineSegments: THREE.LineSegments | null = null;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  rebuild(edges: GraphEdge3D[], layout: ForceLayout, fraction: number = 1.0): void {
    this.dispose();

    // Sample edges if fraction < 1
    let visibleEdges = edges;
    if (fraction < 1.0) {
      const count = Math.ceil(edges.length * fraction);
      visibleEdges = edges.slice(0, count);
    }

    const positions: number[] = [];
    const colors: number[] = [];
    const color = new THREE.Color(0x4a4840);

    for (const edge of visibleEdges) {
      const ps = layout.getPosition(edge.source);
      const pt = layout.getPosition(edge.target);
      if (!ps || !pt) continue;

      positions.push(ps.x, ps.y, ps.z, pt.x, pt.y, pt.z);
      const alpha = Math.min(1, (edge.weight || 0.5) * 0.8);
      colors.push(color.r * alpha, color.g * alpha, color.b * alpha);
      colors.push(color.r * alpha, color.g * alpha, color.b * alpha);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.4,
      depthWrite: false,
    });

    this.lineSegments = new THREE.LineSegments(geo, material);
    this.scene.add(this.lineSegments);
  }

  updatePositions(edges: GraphEdge3D[], layout: ForceLayout): void {
    if (!this.lineSegments) return;

    const posAttr = this.lineSegments.geometry.getAttribute('position');
    if (!posAttr) return;

    const arr = posAttr.array as Float32Array;
    let idx = 0;

    for (const edge of edges) {
      if (idx + 5 >= arr.length) break;
      const ps = layout.getPosition(edge.source);
      const pt = layout.getPosition(edge.target);
      if (!ps || !pt) { idx += 6; continue; }

      arr[idx++] = ps.x; arr[idx++] = ps.y; arr[idx++] = ps.z;
      arr[idx++] = pt.x; arr[idx++] = pt.y; arr[idx++] = pt.z;
    }

    posAttr.needsUpdate = true;
  }

  dispose(): void {
    if (this.lineSegments) {
      this.scene.remove(this.lineSegments);
      this.lineSegments.geometry.dispose();
      (this.lineSegments.material as THREE.Material).dispose();
      this.lineSegments = null;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Label Renderer (Canvas Sprites)
// ═══════════════════════════════════════════════════════════════════════

class LabelRenderer {
  private sprites: Map<string, THREE.Sprite> = new Map();
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private textureCache: Map<string, THREE.Texture> = new Map();
  private maxDistance: number;

  constructor(scene: THREE.Scene, camera: THREE.PerspectiveCamera, maxDistance: number = 200) {
    this.scene = scene;
    this.camera = camera;
    this.maxDistance = maxDistance;
    this.canvas = document.createElement('canvas');
    this.canvas.width = 256;
    this.canvas.height = 64;
    this.ctx = this.canvas.getContext('2d')!;
  }

  private createLabelTexture(text: string): THREE.Texture {
    const cached = this.textureCache.get(text);
    if (cached) return cached;

    this.ctx.clearRect(0, 0, 256, 64);
    this.ctx.fillStyle = '#e2e0d8';
    this.ctx.font = '24px monospace';
    this.ctx.textAlign = 'center';
    this.ctx.fillText(text.slice(0, 20), 128, 40);

    const texture = new THREE.CanvasTexture(this.ctx.getImageData(0, 0, 256, 64) as any);
    // CanvasTexture from ImageData — need a different approach
    const tex = new THREE.Texture(this.canvas);
    tex.needsUpdate = true;
    this.textureCache.set(text, tex);
    return tex;
  }

  update(nodes: GraphNode3D[], layout: ForceLayout): void {
    const camPos = this.camera.position;
    const visibleIds = new Set<string>();

    for (const node of nodes) {
      const pos = layout.getPosition(node.id);
      if (!pos) continue;

      const dist = camPos.distanceTo(pos);
      if (dist > this.maxDistance) {
        // Remove if too far
        const existing = this.sprites.get(node.id);
        if (existing) {
          this.scene.remove(existing);
          this.sprites.delete(node.id);
        }
        continue;
      }

      visibleIds.add(node.id);
      let sprite = this.sprites.get(node.id);

      if (!sprite) {
        // Create new sprite label
        const spriteMat = new THREE.SpriteMaterial({
          map: this.createLabelTexture(node.label),
          transparent: true,
          depthTest: false,
        });
        sprite = new THREE.Sprite(spriteMat);
        sprite.scale.set(12, 3, 1);
        this.scene.add(sprite);
        this.sprites.set(node.id, sprite);
      }

      sprite.position.set(pos.x, pos.y + (NODE_SIZES[node.nodeType] || 2) + 2, pos.z);

      // Fade by distance
      const alpha = Math.max(0.2, 1.0 - dist / this.maxDistance);
      (sprite.material as THREE.SpriteMaterial).opacity = alpha;
    }

    // Remove stale
    for (const [id, sprite] of this.sprites) {
      if (!visibleIds.has(id)) {
        this.scene.remove(sprite);
        (sprite.material as THREE.SpriteMaterial).map?.dispose();
        (sprite.material as THREE.SpriteMaterial).dispose();
        this.sprites.delete(id);
      }
    }
  }

  setMaxDistance(d: number): void {
    this.maxDistance = d;
  }

  dispose(): void {
    for (const [, sprite] of this.sprites) {
      this.scene.remove(sprite);
      (sprite.material as THREE.SpriteMaterial).map?.dispose();
      (sprite.material as THREE.SpriteMaterial).dispose();
    }
    this.sprites.clear();
    for (const tex of this.textureCache.values()) tex.dispose();
    this.textureCache.clear();
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Interaction Manager
// ═══════════════════════════════════════════════════════════════════════

export interface InteractionCallbacks {
  onNodeHover?: (nodeId: string | null, nodeType: string | null) => void;
  onNodeClick?: (nodeId: string, nodeType: string) => void;
}

class InteractionManager {
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2(-999, -999);
  private camera: THREE.PerspectiveCamera;
  private container: HTMLElement;
  private nodeRenderer: NodeRenderer;
  private nodes: GraphNode3D[] = [];
  private hoveredNodeId: string | null = null;
  private callbacks: InteractionCallbacks;

  constructor(
    camera: THREE.PerspectiveCamera,
    container: HTMLElement,
    nodeRenderer: NodeRenderer,
    callbacks: InteractionCallbacks,
  ) {
    this.camera = camera;
    this.container = container;
    this.nodeRenderer = nodeRenderer;
    this.callbacks = callbacks;

    this.container.addEventListener('mousemove', this._onMouseMove);
    this.container.addEventListener('click', this._onClick);
  }

  setNodes(nodes: GraphNode3D[]): void {
    this.nodes = nodes;
  }

  private _onMouseMove = (e: MouseEvent): void => {
    const rect = this.container.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  };

  private _onClick = (): void => {
    if (this.hoveredNodeId) {
      const node = this.nodes.find(n => n.id === this.hoveredNodeId);
      if (node) {
        this.callbacks.onNodeClick?.(node.id, node.nodeType);
      }
    }
  };

  checkHover(): void {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const meshes = this.nodeRenderer.getInstancedMeshes();

    let closest: { nodeId: string; distance: number } | null = null;

    for (const mesh of meshes) {
      const intersects = this.raycaster.intersectObject(mesh, false);
      if (intersects.length > 0 && intersects[0].instanceId !== undefined) {
        const idx = intersects[0].instanceId;
        const nodeType = mesh.userData.nodeType;
        // Find node by type + index
        const matching = this.nodes.filter(n => n.nodeType === nodeType);
        if (idx < matching.length) {
          const dist = intersects[0].distance;
          if (!closest || dist < closest.distance) {
            closest = { nodeId: matching[idx].id, distance: dist };
          }
        }
      }
    }

    const newHovered = closest?.nodeId || null;
    if (newHovered !== this.hoveredNodeId) {
      // Unhighlight old
      if (this.hoveredNodeId) {
        this.nodeRenderer.highlightNode(this.hoveredNodeId, false);
      }
      // Highlight new
      if (newHovered) {
        this.nodeRenderer.highlightNode(newHovered, true);
        const node = this.nodes.find(n => n.id === newHovered);
        this.callbacks.onNodeHover?.(newHovered, node?.nodeType || null);
      } else {
        this.callbacks.onNodeHover?.(null, null);
      }
      this.hoveredNodeId = newHovered;
    }

    this.container.style.cursor = newHovered ? 'pointer' : 'default';
  }

  dispose(): void {
    this.container.removeEventListener('mousemove', this._onMouseMove);
    this.container.removeEventListener('click', this._onClick);
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Main Scene Manager
// ═══════════════════════════════════════════════════════════════════════

export class NexumGraphEngine {
  private container: HTMLElement;
  private config: EngineConfig;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;

  private nodeRenderer: NodeRenderer;
  private edgeRenderer: EdgeRenderer;
  private labelRenderer: LabelRenderer;
  private layout: ForceLayout;
  private interaction: InteractionManager;
  private perfMonitor: PerformanceMonitor;

  private nodes: GraphNode3D[] = [];
  private edges: GraphEdge3D[] = [];
  private animationId: number | null = null;
  private disposed = false;

  // Callbacks
  private callbacks: InteractionCallbacks = {};

  constructor(container: HTMLElement, config?: Partial<EngineConfig>) {
    this.container = container;
    this.config = { ...DEFAULT_CONFIG, ...config };

    // Detect GPU capability
    const detectedQuality = this._detectQuality();
    if (this.config.qualityLevel === 'medium' && detectedQuality) {
      this.config.qualityLevel = detectedQuality;
    }

    // Renderer — no antialiasing on low-end
    const needsAA = this.config.qualityLevel !== 'ultra-low' && this.config.qualityLevel !== 'low';
    this.renderer = new THREE.WebGLRenderer({
      antialias: needsAA,
      powerPreference: 'default',
      alpha: false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.config.qualityLevel === 'high' ? 2 : 1));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setClearColor(this.config.backgroundColor);
    container.appendChild(this.renderer.domElement);

    // Scene
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(this.config.backgroundColor, 300, 800);

    // Camera
    this.camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / Math.max(container.clientHeight, 1),
      0.1,
      2000,
    );
    this.camera.position.set(0, 50, 200);

    // Lighting — minimal, no shadows
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambient);
    const directional = new THREE.DirectionalLight(0xffffff, 0.4);
    directional.position.set(100, 200, 100);
    this.scene.add(directional);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.1;
    this.controls.minDistance = 10;
    this.controls.maxDistance = 1000;
    this.controls.rotateSpeed = 0.5;

    // Subsystems
    this.perfMonitor = new PerformanceMonitor(this.config.qualityLevel, this.config.adaptiveQuality);
    this.nodeRenderer = new NodeRenderer(this.scene);
    this.edgeRenderer = new EdgeRenderer(this.scene);
    this.labelRenderer = new LabelRenderer(this.scene, this.camera);
    this.layout = new ForceLayout();
    this.interaction = new InteractionManager(this.camera, container, this.nodeRenderer, this.callbacks);

    // Resize handler
    window.addEventListener('resize', this._onResize);

    // Start render loop
    this._animate();
  }

  private _detectQuality(): QualityLevel | null {
    try {
      const gl = this.renderer.getContext();
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        const gpuRenderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL);
        const lower = gpuRenderer.toLowerCase();
        if (lower.includes('intel') && !lower.includes('iris xe') && !lower.includes('arc')) {
          return 'low';
        }
        if (lower.includes('mali') || lower.includes('adreno 5') || lower.includes('powervr')) {
          return 'ultra-low';
        }
      }
    } catch { /* ignore */ }
    return null;
  }

  // ── Public API ────────────────────────────────────────────────────

  setCallbacks(callbacks: InteractionCallbacks): void {
    this.callbacks = callbacks;
    this.interaction.dispose();
    this.interaction = new InteractionManager(this.camera, this.container, this.nodeRenderer, callbacks);
  }

  setData(nodes: GraphNode3D[], edges: GraphEdge3D[]): void {
    const params = this.perfMonitor.getQualityParams();
    const maxN = Math.min(nodes.length, params.maxNodes);

    // Priority sampling: keep important types first
    const priority = ['Channel', 'Video', 'Entity', 'Topic', 'CommentAuthor', 'Playlist', 'Segment', 'Comment'];
    const sorted = [...nodes].sort((a, b) =>
      priority.indexOf(a.nodeType) - priority.indexOf(b.nodeType)
    );
    this.nodes = sorted.slice(0, maxN);
    const nodeIds = new Set(this.nodes.map(n => n.id));
    this.edges = edges.filter(e => nodeIds.has(e.source) && nodeIds.has(e.target))
      .slice(0, this.config.maxVisibleEdges);

    // Init layout
    this.layout.setData(this.nodes, this.edges);

    // Run layout warmup (synchronous, fast)
    for (let i = 0; i < Math.min(this.config.forceLayoutIterations, 50); i++) {
      if (!this.layout.step()) break;
    }

    // Copy positions back
    for (const node of this.nodes) {
      const pos = this.layout.getPosition(node.id);
      if (pos) { node.x = pos.x; node.y = pos.y; node.z = pos.z; }
    }

    // Rebuild renderers
    this.nodeRenderer.rebuild(this.nodes, params.nodeDetail);
    this.nodeRenderer.updatePositions(this.nodes, this.layout);

    if (this.config.enableEdges) {
      this.edgeRenderer.rebuild(this.edges, this.layout, params.edgeFraction);
    }

    this.interaction.setNodes(this.nodes);
    this.labelRenderer.setMaxDistance(params.labelDistance);
  }

  addNodes(newNodes: GraphNode3D[], newEdges: GraphEdge3D[] = []): void {
    this.nodes.push(...newNodes);
    this.edges.push(...newEdges);
    this.layout.setData(this.nodes, this.edges);
    this.layout.reheat();

    const params = this.perfMonitor.getQualityParams();
    this.nodeRenderer.rebuild(this.nodes, params.nodeDetail);
    if (this.config.enableEdges) {
      this.edgeRenderer.rebuild(this.edges, this.layout, params.edgeFraction);
    }
    this.interaction.setNodes(this.nodes);
  }

  setFilteredTypes(types: Set<string> | null): void {
    if (!types) return;
    const filtered = this.nodes.filter(n => types.has(n.nodeType));
    const nodeIds = new Set(filtered.map(n => n.id));
    const filteredEdges = this.edges.filter(e => nodeIds.has(e.source) && nodeIds.has(e.target));

    const params = this.perfMonitor.getQualityParams();
    this.nodeRenderer.rebuild(filtered, params.nodeDetail);
    this.nodeRenderer.updatePositions(filtered, this.layout);
    if (this.config.enableEdges) {
      this.edgeRenderer.rebuild(filteredEdges, this.layout, params.edgeFraction);
    }
    this.interaction.setNodes(filtered);
  }

  setConfig(updates: Partial<EngineConfig>): void {
    Object.assign(this.config, updates);
  }

  focusNode(nodeId: string): void {
    const pos = this.layout.getPosition(nodeId);
    if (!pos) return;
    // Animate camera to node
    const target = pos.clone().add(new THREE.Vector3(0, 20, 50));
    this.camera.position.lerp(target, 0.3);
    this.controls.target.lerp(pos, 0.3);
  }

  getStats(): { fps: number; quality: QualityLevel; nodes: number; edges: number; layoutActive: boolean } {
    return {
      fps: this.perfMonitor.fps,
      quality: this.perfMonitor.qualityLevel,
      nodes: this.nodes.length,
      edges: this.edges.length,
      layoutActive: this.layout.isActive,
    };
  }

  // ── Render Loop ───────────────────────────────────────────────────

  private _animate = (): void => {
    if (this.disposed) return;
    this.animationId = requestAnimationFrame(this._animate);

    const now = performance.now();
    this.perfMonitor.tick(now);

    // Step layout
    if (this.layout.isActive && this.config.enableAnimation) {
      this.layout.step();
      this.nodeRenderer.updatePositions(this.nodes, this.layout);
      if (this.config.enableEdges) {
        this.edgeRenderer.updatePositions(this.edges, this.layout);
      }
    }

    // Update labels (throttled — every 3 frames)
    if (this.config.enableLabels && Math.random() < 0.33) {
      this.labelRenderer.update(this.nodes, this.layout);
    }

    // Hover check (throttled — every 2 frames)
    if (Math.random() < 0.5) {
      this.interaction.checkHover();
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  };

  private _onResize = (): void => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / Math.max(h, 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  // ── Disposal ──────────────────────────────────────────────────────

  dispose(): void {
    this.disposed = true;
    if (this.animationId !== null) cancelAnimationFrame(this.animationId);
    window.removeEventListener('resize', this._onResize);

    this.interaction.dispose();
    this.labelRenderer.dispose();
    this.edgeRenderer.dispose();
    this.nodeRenderer.dispose();
    this.controls.dispose();
    this.renderer.dispose();

    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }

    this.scene.clear();
  }
}
