'use client';

/**
 * GraphCanvas3D — React wrapper for NexumGraphEngine.
 *
 * Features:
 *   - Auto-initializes Three.js on mount
 *   - Bridges GraphNode/GraphEdge from existing types to 3D types
 *   - Stats overlay (FPS, quality, node/edge count)
 *   - Quality controls
 *   - 2D Canvas fallback for WebGL failure
 *   - Filter by node type
 *   - Live node addition from WebSocket
 */

import { useCallback, useEffect, useRef, useState, useMemo } from 'react';
import type { GraphNode, GraphEdge } from '@/lib/types';

// Node appearance config
const NODE_COLORS: Record<string, string> = {
  Video:         '#d4a843',
  Channel:       '#ef4444',
  Comment:       '#6b7280',
  CommentAuthor: '#3b82f6',
  Entity:        '#10b981',
  Topic:         '#8b5cf6',
  Playlist:      '#f59e0b',
  Segment:       '#6366f1',
};

interface GraphCanvas3DProps {
  nodes: Map<string, GraphNode>;
  edges: GraphEdge[];
  filterNodeTypes?: Set<string>;
  onNodeClick?: (nodeId: string, nodeType: string) => void;
  onNodeHover?: (nodeId: string | null) => void;
  maxVisible?: number;
  className?: string;
}

interface EngineStats {
  fps: number;
  quality: string;
  nodes: number;
  edges: number;
  layoutActive: boolean;
}

export default function GraphCanvas3D({
  nodes,
  edges,
  filterNodeTypes,
  onNodeClick,
  onNodeHover,
  maxVisible = 3000,
  className = '',
}: GraphCanvas3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<any>(null);
  const [webGLFailed, setWebGLFailed] = useState(false);
  const [stats, setStats] = useState<EngineStats>({ fps: 0, quality: 'medium', nodes: 0, edges: 0, layoutActive: false });
  const [showStats, setShowStats] = useState(true);
  const statsIntervalRef = useRef<ReturnType<typeof setInterval>>();

  // Convert 2D types to 3D types
  const nodes3D = useMemo(() => {
    const arr: any[] = [];
    let filtered = Array.from(nodes.values());
    if (filterNodeTypes && filterNodeTypes.size > 0) {
      filtered = filtered.filter(n => filterNodeTypes.has(n.node_type));
    }
    for (const n of filtered.slice(0, maxVisible)) {
      arr.push({
        id: n.id,
        label: n.label?.slice(0, 25) || '',
        nodeType: n.node_type,
        x: 0, y: 0, z: 0,
        size: 2,
        color: NODE_COLORS[n.node_type] || '#cccccc',
        data: n.data,
      });
    }
    return arr;
  }, [nodes, filterNodeTypes, maxVisible]);

  const edges3D = useMemo(() => {
    const nodeIds = new Set(nodes3D.map((n: any) => n.id));
    return edges
      .filter(e => nodeIds.has(e.source) && nodeIds.has(e.target))
      .map(e => ({
        source: e.source,
        target: e.target,
        edgeType: e.edge_type,
        weight: e.weight || 1,
      }));
  }, [edges, nodes3D]);

  // Initialize engine
  useEffect(() => {
    if (!containerRef.current || webGLFailed) return;

    let engine: any = null;
    let mounted = true;

    const init = async () => {
      try {
        const { NexumGraphEngine } = await import('./engine');
        if (!mounted || !containerRef.current) return;

        engine = new NexumGraphEngine(containerRef.current, {
          maxVisibleNodes: maxVisible,
          adaptiveQuality: true,
          enableLabels: true,
          enableEdges: true,
        });

        engine.setCallbacks({
          onNodeClick: (id: string, type: string) => onNodeClick?.(id, type),
          onNodeHover: (id: string | null) => onNodeHover?.(id),
        });

        engineRef.current = engine;
      } catch (err) {
        console.error('WebGL init failed, falling back to 2D:', err);
        if (mounted) setWebGLFailed(true);
      }
    };

    init();

    return () => {
      mounted = false;
      if (engine) engine.dispose();
      engineRef.current = null;
    };
  }, [webGLFailed]); // eslint-disable-line react-hooks/exhaustive-deps

  // Push data to engine
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine || nodes3D.length === 0) return;
    engine.setData(nodes3D, edges3D);
  }, [nodes3D, edges3D]);

  // Filter update
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine || !filterNodeTypes) return;
    engine.setFilteredTypes(filterNodeTypes);
  }, [filterNodeTypes]);

  // Stats polling
  useEffect(() => {
    if (!showStats) return;
    statsIntervalRef.current = setInterval(() => {
      const engine = engineRef.current;
      if (engine) setStats(engine.getStats());
    }, 500);
    return () => clearInterval(statsIntervalRef.current);
  }, [showStats]);

  // ── 2D Canvas Fallback ────────────────────────────────────────────

  if (webGLFailed) {
    return <Canvas2DFallback nodes={nodes} edges={edges} filterNodeTypes={filterNodeTypes} onNodeClick={onNodeClick} />;
  }

  return (
    <div className={`relative w-full h-full ${className}`}>
      <div
        ref={containerRef}
        className="w-full h-full bg-[#1a1916] rounded-lg border border-nexum-border/40"
        style={{ minHeight: '500px' }}
      />

      {/* Stats Overlay */}
      {showStats && (
        <div className="absolute top-3 right-3 bg-black/70 text-xs text-white/70 px-3 py-2 rounded font-mono space-y-0.5">
          <div className="flex justify-between gap-4">
            <span>FPS</span>
            <span className={stats.fps < 25 ? 'text-red-400' : stats.fps < 50 ? 'text-yellow-400' : 'text-green-400'}>
              {stats.fps}
            </span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Quality</span>
            <span className="text-[#d4a843]">{stats.quality}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Nodes</span>
            <span>{stats.nodes.toLocaleString()}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Edges</span>
            <span>{stats.edges.toLocaleString()}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Layout</span>
            <span>{stats.layoutActive ? '⟳' : '✓'}</span>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="absolute bottom-3 right-3 flex gap-1.5">
        <button
          onClick={() => setShowStats(!showStats)}
          className="bg-black/60 hover:bg-black/80 text-white/60 text-xs px-2 py-1 rounded"
          title="Toggle stats"
        >
          📊
        </button>
        <button
          onClick={() => {
            const engine = engineRef.current;
            if (engine) engine.setData(nodes3D, edges3D);
          }}
          className="bg-black/60 hover:bg-black/80 text-white/60 text-xs px-2 py-1 rounded"
          title="Re-layout"
        >
          ⟳
        </button>
      </div>

      {/* 3D badge */}
      <div className="absolute top-3 left-3 bg-[#d4a843]/20 text-[#d4a843] text-[10px] px-2 py-0.5 rounded font-mono">
        THREE.JS
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2D Canvas Fallback
// ═══════════════════════════════════════════════════════════════════════

function Canvas2DFallback({
  nodes,
  edges,
  filterNodeTypes,
  onNodeClick,
}: {
  nodes: Map<string, GraphNode>;
  edges: GraphEdge[];
  filterNodeTypes?: Set<string>;
  onNodeClick?: (nodeId: string, nodeType: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.parentElement?.clientWidth || 800;
    const h = canvas.parentElement?.clientHeight || 600;
    canvas.width = w;
    canvas.height = h;

    let visible = Array.from(nodes.values());
    if (filterNodeTypes && filterNodeTypes.size > 0) {
      visible = visible.filter(n => filterNodeTypes.has(n.node_type));
    }
    visible = visible.slice(0, 500);

    // Assign positions in a grid
    const positions = new Map<string, { x: number; y: number }>();
    const cols = Math.ceil(Math.sqrt(visible.length));
    visible.forEach((n, i) => {
      positions.set(n.id, {
        x: (i % cols) * (w / (cols + 1)) + w / (cols + 1),
        y: Math.floor(i / cols) * (h / (cols + 1)) + h / (cols + 1),
      });
    });

    // Draw
    ctx.fillStyle = '#1a1916';
    ctx.fillRect(0, 0, w, h);

    // Edges
    ctx.strokeStyle = 'rgba(74, 72, 64, 0.3)';
    ctx.lineWidth = 0.5;
    const nodeIds = new Set(visible.map(n => n.id));
    for (const e of edges) {
      if (!nodeIds.has(e.source) || !nodeIds.has(e.target)) continue;
      const p1 = positions.get(e.source);
      const p2 = positions.get(e.target);
      if (!p1 || !p2) continue;
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    }

    // Nodes
    for (const n of visible) {
      const pos = positions.get(n.id);
      if (!pos) continue;
      ctx.fillStyle = NODE_COLORS[n.node_type] || '#cccccc';
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Labels for first 50
    ctx.fillStyle = '#e2e0d8';
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    for (const n of visible.slice(0, 50)) {
      const pos = positions.get(n.id);
      if (!pos) continue;
      ctx.fillText(n.label?.slice(0, 15) || '', pos.x, pos.y + 12);
    }
  }, [nodes, edges, filterNodeTypes]);

  return (
    <div className="relative w-full h-full">
      <canvas ref={canvasRef} className="w-full h-full rounded-lg border border-nexum-border/40" />
      <div className="absolute top-3 left-3 bg-red-500/20 text-red-400 text-[10px] px-2 py-0.5 rounded font-mono">
        2D FALLBACK
      </div>
    </div>
  );
}
