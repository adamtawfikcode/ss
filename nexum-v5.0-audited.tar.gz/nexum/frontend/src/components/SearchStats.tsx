'use client';

import { Timer, Hash, Zap } from 'lucide-react';

interface SearchStatsProps {
  total: number;
  searchTimeMs: number;
  showing: number;
}

export default function SearchStats({ total, searchTimeMs, showing }: SearchStatsProps) {
  return (
    <div className="flex items-center gap-4 text-xs font-mono text-nexum-muted animate-fade-in">
      <span className="flex items-center gap-1.5">
        <Hash size={11} className="text-nexum-accent/60" />
        {total} result{total !== 1 ? 's' : ''}
        {showing < total && ` (showing ${showing})`}
      </span>
      <span className="text-nexum-border">·</span>
      <span className="flex items-center gap-1.5">
        <Timer size={11} className="text-nexum-accent/60" />
        {searchTimeMs < 1000 ? `${searchTimeMs}ms` : `${(searchTimeMs / 1000).toFixed(2)}s`}
      </span>
      <span className="text-nexum-border">·</span>
      <span className="flex items-center gap-1.5">
        <Zap size={11} className="text-nexum-accent/60" />
        Multimodal fusion
      </span>
    </div>
  );
}
