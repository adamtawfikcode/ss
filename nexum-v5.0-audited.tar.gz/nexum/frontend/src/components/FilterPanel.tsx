'use client';

import { useState } from 'react';
import { SlidersHorizontal, ChevronDown, RotateCcw } from 'lucide-react';
import type { SearchFilters } from '@/lib/types';

interface FilterPanelProps {
  filters: SearchFilters;
  onChange: (filters: SearchFilters) => void;
}

const MODALITIES = [
  { value: 'all', label: 'All Modalities' },
  { value: 'transcript', label: 'Transcript Only' },
  { value: 'visual', label: 'Visual Only' },
  { value: 'ocr', label: 'On-Screen Text' },
] as const;

const SORT_OPTIONS = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'date', label: 'Date' },
  { value: 'views', label: 'Views' },
] as const;

export default function FilterPanel({ filters, onChange }: FilterPanelProps) {
  const [open, setOpen] = useState(false);

  const update = (patch: Partial<SearchFilters>) => onChange({ ...filters, ...patch });

  const hasActiveFilters =
    filters.modality !== 'all' ||
    filters.min_confidence !== undefined ||
    filters.min_views !== undefined ||
    filters.channel !== undefined ||
    filters.language !== undefined;

  const reset = () =>
    onChange({ sort_by: 'relevance', modality: 'all' });

  return (
    <div className="w-full max-w-3xl mx-auto">
      <button
        onClick={() => setOpen(!open)}
        className={`
          flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-body transition-all
          ${hasActiveFilters
            ? 'border-nexum-accent/40 bg-nexum-accent/10 text-nexum-accent'
            : 'border-nexum-border/50 bg-nexum-surface/50 text-nexum-muted hover:text-nexum-text'
          }
        `}
      >
        <SlidersHorizontal size={13} />
        Filters
        {hasActiveFilters && (
          <span className="ml-0.5 inline-flex h-4 w-4 items-center justify-center rounded-full bg-nexum-accent text-[10px] font-bold text-nexum-bg">
            !
          </span>
        )}
        <ChevronDown
          size={12}
          className={`transition-transform ${open ? 'rotate-180' : ''}`}
        />
      </button>

      {open && (
        <div className="mt-2 animate-slide-up rounded-xl border border-nexum-border/60 bg-nexum-surface/90 backdrop-blur-sm p-4">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {/* Modality */}
            <div>
              <label className="mb-1.5 block text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
                Modality
              </label>
              <select
                value={filters.modality || 'all'}
                onChange={(e) => update({ modality: e.target.value as SearchFilters['modality'] })}
                className="w-full rounded-lg border border-nexum-border bg-nexum-elevated px-3 py-2 text-sm text-nexum-text"
              >
                {MODALITIES.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <label className="mb-1.5 block text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
                Sort By
              </label>
              <select
                value={filters.sort_by || 'relevance'}
                onChange={(e) => update({ sort_by: e.target.value as SearchFilters['sort_by'] })}
                className="w-full rounded-lg border border-nexum-border bg-nexum-elevated px-3 py-2 text-sm text-nexum-text"
              >
                {SORT_OPTIONS.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Min confidence */}
            <div>
              <label className="mb-1.5 block text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
                Min Confidence
              </label>
              <input
                type="number"
                min={0}
                max={1}
                step={0.1}
                value={filters.min_confidence ?? ''}
                onChange={(e) =>
                  update({ min_confidence: e.target.value ? Number(e.target.value) : undefined })
                }
                placeholder="0.0"
                className="w-full rounded-lg border border-nexum-border bg-nexum-elevated px-3 py-2 text-sm text-nexum-text placeholder:text-nexum-muted/40"
              />
            </div>

            {/* Min views */}
            <div>
              <label className="mb-1.5 block text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
                Min Views
              </label>
              <input
                type="number"
                min={0}
                step={1000}
                value={filters.min_views ?? ''}
                onChange={(e) =>
                  update({ min_views: e.target.value ? Number(e.target.value) : undefined })
                }
                placeholder="Any"
                className="w-full rounded-lg border border-nexum-border bg-nexum-elevated px-3 py-2 text-sm text-nexum-text placeholder:text-nexum-muted/40"
              />
            </div>

            {/* Channel */}
            <div>
              <label className="mb-1.5 block text-[11px] font-mono uppercase tracking-wider text-nexum-muted">
                Channel
              </label>
              <input
                type="text"
                value={filters.channel ?? ''}
                onChange={(e) =>
                  update({ channel: e.target.value || undefined })
                }
                placeholder="Any channel"
                className="w-full rounded-lg border border-nexum-border bg-nexum-elevated px-3 py-2 text-sm text-nexum-text placeholder:text-nexum-muted/40"
              />
            </div>
          </div>

          {hasActiveFilters && (
            <button
              onClick={reset}
              className="mt-3 flex items-center gap-1.5 text-xs text-nexum-muted hover:text-nexum-accent transition-colors"
            >
              <RotateCcw size={12} />
              Reset filters
            </button>
          )}
        </div>
      )}
    </div>
  );
}
