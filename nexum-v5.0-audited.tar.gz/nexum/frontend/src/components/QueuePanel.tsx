'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Play,
  Pause,
  Check,
  X,
  AlertTriangle,
  Zap,
  Clock,
  Layers,
  Loader2,
  ExternalLink,
  Trash2,
} from 'lucide-react';
import type { QueueJob, QueueStatus, QueueEvent, JobStatus } from '@/lib/types';
import { JOB_STATUS_COLORS } from '@/lib/types';
import { getQueueStatus, cancelJob } from '@/lib/api';

const STATUS_ICONS: Record<JobStatus, typeof Play> = {
  pending: Clock,
  running: Play,
  paused: Pause,
  completed: Check,
  failed: AlertTriangle,
  cancelled: X,
};

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}m ${s}s`;
}

function JobCard({ job, onCancel }: { job: QueueJob; onCancel?: (id: string) => void }) {
  const Icon = STATUS_ICONS[job.status] || Clock;
  const color = JOB_STATUS_COLORS[job.status] || '#6b7280';
  const isActive = job.status === 'running' || job.status === 'paused';
  const elapsed = job.started_at
    ? ((job.completed_at || Date.now() / 1000) - job.started_at)
    : 0;

  return (
    <div className={`
      relative rounded-lg border px-3 py-2.5 transition-all duration-200
      ${job.status === 'running'
        ? 'border-nexum-info/40 bg-nexum-info/5'
        : job.status === 'paused'
          ? 'border-nexum-warn/40 bg-nexum-warn/5'
          : 'border-nexum-border/30 bg-nexum-surface/40'
      }
    `}>
      {/* Progress bar */}
      {isActive && (
        <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-lg overflow-hidden bg-nexum-border/20">
          <div
            className="h-full transition-all duration-500 ease-out"
            style={{
              width: `${Math.max(job.progress * 100, 2)}%`,
              backgroundColor: color,
            }}
          />
        </div>
      )}

      <div className="flex items-start gap-2.5">
        {/* Status icon */}
        <div
          className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md"
          style={{ backgroundColor: `${color}15`, color }}
        >
          {job.status === 'running' ? (
            <Loader2 size={13} className="animate-spin" />
          ) : (
            <Icon size={13} />
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm text-nexum-text font-medium max-w-[280px]">
              {job.url}
            </span>
            {job.priority === 'immediate' && (
              <Zap size={11} className="text-nexum-warn shrink-0" />
            )}
          </div>

          <div className="mt-0.5 flex items-center gap-3 text-[11px] text-nexum-muted">
            <span className="font-mono uppercase tracking-wider" style={{ color }}>
              {job.status}
            </span>
            <span>{job.job_type}</span>
            {elapsed > 0 && <span>{formatDuration(elapsed)}</span>}
            {job.message && (
              <span className="truncate max-w-[200px]">{job.message}</span>
            )}
          </div>

          {job.interrupted_by && job.status === 'paused' && (
            <p className="mt-1 text-[10px] text-nexum-warn/70 flex items-center gap-1">
              <Pause size={9} />
              Interrupted by priority job {job.interrupted_by.slice(0, 8)}...
            </p>
          )}

          {job.error && (
            <p className="mt-1 text-[10px] text-nexum-danger truncate">{job.error}</p>
          )}
        </div>

        {/* Cancel button */}
        {(job.status === 'pending' || job.status === 'running' || job.status === 'paused') && onCancel && (
          <button
            onClick={() => onCancel(job.id)}
            className="mt-0.5 shrink-0 rounded-md p-1 text-nexum-muted hover:text-nexum-danger hover:bg-nexum-danger/10 transition-colors"
            title="Cancel job"
          >
            <X size={13} />
          </button>
        )}
      </div>
    </div>
  );
}

export default function QueuePanel() {
  const [status, setStatus] = useState<QueueStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  const fetchStatus = useCallback(async () => {
    try {
      const data = await getQueueStatus();
      setStatus(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch queue status');
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    pollRef.current = setInterval(fetchStatus, 2000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [fetchStatus]);

  const handleCancel = async (jobId: string) => {
    try {
      await cancelJob(jobId);
      await fetchStatus();
    } catch (err) {
      console.error('Cancel failed:', err);
    }
  };

  if (!status) {
    return (
      <div className="flex items-center justify-center py-8 text-nexum-muted text-sm">
        <Loader2 size={16} className="animate-spin mr-2" />
        Loading queue...
      </div>
    );
  }

  const hasJobs = status.current_job
    || status.priority_stack.length > 0
    || status.normal_queue.length > 0
    || status.paused_jobs.length > 0;

  return (
    <div className="space-y-4">
      {/* Stats bar */}
      <div className="flex items-center gap-4 text-xs text-nexum-muted">
        <span className="flex items-center gap-1.5">
          <span className={`h-1.5 w-1.5 rounded-full ${status.is_processing ? 'bg-nexum-success animate-pulse' : 'bg-nexum-muted'}`} />
          {status.is_processing ? 'Processing' : 'Idle'}
        </span>
        <span>{status.stats.pending_normal + status.stats.pending_priority} queued</span>
        {status.stats.paused > 0 && (
          <span className="text-nexum-warn">{status.stats.paused} paused</span>
        )}
        <span>{status.stats.completed} completed</span>
        {status.stats.failed > 0 && (
          <span className="text-nexum-danger">{status.stats.failed} failed</span>
        )}
      </div>

      {!hasJobs && status.completed_recent.length === 0 && (
        <div className="rounded-xl border border-nexum-border/20 bg-nexum-surface/20 px-4 py-8 text-center">
          <Layers size={24} className="mx-auto mb-2 text-nexum-muted/40" />
          <p className="text-sm text-nexum-muted">Queue is empty</p>
          <p className="text-xs text-nexum-muted/60 mt-1">Paste a URL above to start processing</p>
        </div>
      )}

      {/* Current job */}
      {status.current_job && (
        <section>
          <h3 className="text-[11px] font-mono uppercase tracking-widest text-nexum-muted mb-1.5">
            Now Processing
          </h3>
          <JobCard job={status.current_job} onCancel={handleCancel} />
        </section>
      )}

      {/* Priority stack */}
      {status.priority_stack.length > 0 && (
        <section>
          <h3 className="text-[11px] font-mono uppercase tracking-widest text-nexum-warn mb-1.5 flex items-center gap-1.5">
            <Zap size={10} />
            Priority Stack ({status.priority_stack.length})
          </h3>
          <div className="space-y-1.5">
            {status.priority_stack.map((job) => (
              <JobCard key={job.id} job={job} onCancel={handleCancel} />
            ))}
          </div>
        </section>
      )}

      {/* Paused jobs */}
      {status.paused_jobs.length > 0 && (
        <section>
          <h3 className="text-[11px] font-mono uppercase tracking-widest text-nexum-warn/70 mb-1.5 flex items-center gap-1.5">
            <Pause size={10} />
            Paused ({status.paused_jobs.length})
          </h3>
          <div className="space-y-1.5">
            {status.paused_jobs.map((job) => (
              <JobCard key={job.id} job={job} onCancel={handleCancel} />
            ))}
          </div>
        </section>
      )}

      {/* Normal queue */}
      {status.normal_queue.length > 0 && (
        <section>
          <h3 className="text-[11px] font-mono uppercase tracking-widest text-nexum-muted mb-1.5">
            Queue ({status.normal_queue.length})
          </h3>
          <div className="space-y-1.5">
            {status.normal_queue.map((job) => (
              <JobCard key={job.id} job={job} onCancel={handleCancel} />
            ))}
          </div>
        </section>
      )}

      {/* Recent completed */}
      {status.completed_recent.length > 0 && (
        <section>
          <h3 className="text-[11px] font-mono uppercase tracking-widest text-nexum-muted mb-1.5">
            Recent ({status.completed_recent.length})
          </h3>
          <div className="space-y-1.5">
            {status.completed_recent.slice(-8).reverse().map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
