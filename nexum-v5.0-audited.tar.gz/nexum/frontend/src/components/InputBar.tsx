'use client';

import { useState, useRef, useCallback, type KeyboardEvent } from 'react';
import {
  Link as LinkIcon,
  Zap,
  Send,
  Loader2,
  ChevronDown,
  Film,
  Radio,
  ListVideo,
} from 'lucide-react';

interface InputBarProps {
  onSubmit: (url: string, priority: 'normal' | 'immediate', jobType?: string) => Promise<void>;
  disabled?: boolean;
}

const TYPE_ICONS: Record<string, typeof Film> = {
  video: Film,
  channel: Radio,
  playlist: ListVideo,
};

export default function InputBar({ onSubmit, disabled }: InputBarProps) {
  const [url, setUrl] = useState('');
  const [priority, setPriority] = useState<'normal' | 'immediate'>('normal');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [detectedType, setDetectedType] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const detectType = useCallback((value: string) => {
    const lower = value.toLowerCase();
    if (lower.includes('playlist') || lower.includes('list=')) return 'playlist';
    if (lower.includes('/@') || lower.includes('/c/') || lower.includes('/channel/') || lower.includes('/user/')) return 'channel';
    if (value.length > 10) return 'video';
    return null;
  }, []);

  const handleUrlChange = (value: string) => {
    setUrl(value);
    setDetectedType(detectType(value));
  };

  const handleSubmit = async () => {
    const trimmed = url.trim();
    if (!trimmed || isSubmitting) return;

    setIsSubmitting(true);
    try {
      await onSubmit(trimmed, priority, detectedType || undefined);
      setUrl('');
      setDetectedType(null);
      inputRef.current?.focus();
    } catch (err) {
      console.error('Submit failed:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const isImmediate = priority === 'immediate';
  const TypeIcon = detectedType ? TYPE_ICONS[detectedType] : LinkIcon;

  return (
    <div className="w-full">
      {/* Main input row */}
      <div className={`
        flex items-center gap-2 rounded-xl border px-3 py-2
        transition-all duration-200
        ${isImmediate
          ? 'border-nexum-warn/50 bg-nexum-warn/5 shadow-[0_0_12px_0_#f5a62320]'
          : 'border-nexum-border/60 bg-nexum-surface/60'
        }
        focus-within:border-nexum-accent/50 focus-within:shadow-[0_0_12px_0_#d4a84320]
      `}>
        {/* Type indicator */}
        <div className={`
          flex h-8 w-8 shrink-0 items-center justify-center rounded-lg
          ${detectedType ? 'bg-nexum-accent/10 text-nexum-accent' : 'bg-nexum-border/20 text-nexum-muted'}
          transition-colors duration-200
        `}>
          <TypeIcon size={16} />
        </div>

        {/* URL input */}
        <input
          ref={inputRef}
          type="text"
          value={url}
          onChange={(e) => handleUrlChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Paste video, channel, or playlist URL..."
          disabled={disabled || isSubmitting}
          className="
            flex-1 bg-transparent text-sm text-nexum-text
            placeholder:text-nexum-muted/50 outline-none
            font-body min-w-0
          "
          spellCheck={false}
        />

        {/* Detected type badge */}
        {detectedType && (
          <span className="
            shrink-0 rounded-md bg-nexum-accent/10 px-2 py-0.5
            text-[10px] font-mono uppercase tracking-wider text-nexum-accent
          ">
            {detectedType}
          </span>
        )}

        {/* Priority toggle */}
        <button
          onClick={() => setPriority(p => p === 'normal' ? 'immediate' : 'normal')}
          title={isImmediate ? 'Priority mode: ON — will interrupt current job' : 'Priority mode: OFF — normal queue order'}
          className={`
            group relative flex h-8 shrink-0 items-center gap-1.5 rounded-lg px-2.5
            text-xs font-medium transition-all duration-200
            ${isImmediate
              ? 'bg-nexum-warn/20 text-nexum-warn hover:bg-nexum-warn/30'
              : 'bg-nexum-border/20 text-nexum-muted hover:bg-nexum-border/40 hover:text-nexum-text'
            }
          `}
        >
          <Zap size={13} className={isImmediate ? 'text-nexum-warn' : ''} />
          <span className="hidden sm:inline">{isImmediate ? 'Priority' : 'Normal'}</span>

          {/* Tooltip */}
          <span className="
            pointer-events-none absolute -top-9 left-1/2 -translate-x-1/2
            whitespace-nowrap rounded-md bg-nexum-elevated border border-nexum-border
            px-2 py-1 text-[10px] text-nexum-muted
            opacity-0 group-hover:opacity-100 transition-opacity
          ">
            {isImmediate ? 'Pauses current job, runs this first' : 'Click for priority mode'}
          </span>
        </button>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!url.trim() || isSubmitting || disabled}
          className={`
            flex h-8 w-8 shrink-0 items-center justify-center rounded-lg
            transition-all duration-200
            ${url.trim()
              ? 'bg-nexum-accent text-nexum-bg hover:bg-nexum-accent/90 shadow-sm'
              : 'bg-nexum-border/20 text-nexum-muted cursor-not-allowed'
            }
          `}
        >
          {isSubmitting ? (
            <Loader2 size={14} className="animate-spin" />
          ) : (
            <Send size={14} />
          )}
        </button>
      </div>

      {/* Priority mode explanation */}
      {isImmediate && (
        <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-nexum-warn/70 pl-1 animate-fade-in">
          <Zap size={10} />
          Priority mode — interrupts the current job, processes this URL immediately, then resumes. Stackable.
        </p>
      )}
    </div>
  );
}
