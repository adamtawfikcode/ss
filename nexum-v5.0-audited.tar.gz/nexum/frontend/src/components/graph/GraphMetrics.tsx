'use client';

import type { GraphNode } from '@/lib/types';

interface GraphMetricsProps {
  nodes: Map<string, GraphNode>;
  edgeCount: number;
  eventRate: number;
  connected: boolean;
  paused: boolean;
}

export default function GraphMetrics({
  nodes,
  edgeCount,
  eventRate,
  connected,
  paused,
}: GraphMetricsProps) {
  // Count by type
  const counts: Record<string, number> = {};
  nodes.forEach((n) => {
    counts[n.node_type] = (counts[n.node_type] || 0) + 1;
  });

  const metrics = [
    { label: 'Videos', value: counts.Video || 0, color: '#d4a843' },
    { label: 'Comments', value: counts.Comment || 0, color: '#6b7280' },
    { label: 'Users', value: counts.CommentAuthor || 0, color: '#3b82f6' },
    { label: 'Entities', value: counts.Entity || 0, color: '#10b981' },
    { label: 'Channels', value: counts.Channel || 0, color: '#ef4444' },
    { label: 'Edges', value: edgeCount, color: '#8b5cf6' },
  ];

  return (
    <div className="absolute top-4 left-4 bg-nexum-bg/90 backdrop-blur-md border border-nexum-border/60 rounded-lg p-3 space-y-2 min-w-[180px] z-20">
      {/* Connection status */}
      <div className="flex items-center gap-2 text-xs font-mono">
        <span
          className={`inline-block h-2 w-2 rounded-full ${
            connected ? 'bg-nexum-success animate-pulse' : 'bg-red-500'
          }`}
        />
        <span className="text-nexum-muted">
          {connected ? (paused ? 'Paused' : 'Live') : 'Disconnected'}
        </span>
        {eventRate > 0 && (
          <span className="ml-auto text-nexum-accent">{eventRate}/s</span>
        )}
      </div>

      {/* Divider */}
      <div className="h-px bg-nexum-border/40" />

      {/* Metric rows */}
      {metrics.map((m) => (
        <div key={m.label} className="flex items-center justify-between text-xs font-mono">
          <span className="flex items-center gap-1.5">
            <span
              className="inline-block h-2 w-2 rounded-sm"
              style={{ backgroundColor: m.color }}
            />
            <span className="text-nexum-muted">{m.label}</span>
          </span>
          <span className="text-nexum-text tabular-nums">{m.value.toLocaleString()}</span>
        </div>
      ))}

      {/* Total */}
      <div className="h-px bg-nexum-border/40" />
      <div className="flex items-center justify-between text-xs font-mono">
        <span className="text-nexum-muted">Total Nodes</span>
        <span className="text-nexum-accent font-semibold">{nodes.size.toLocaleString()}</span>
      </div>
    </div>
  );
}
