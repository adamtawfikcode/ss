'use client';

import { useState } from 'react';

interface GraphControlsProps {
  paused: boolean;
  onTogglePause: () => void;
  onReconnect: () => void;
  filterNodeTypes: Set<string>;
  onFilterChange: (types: Set<string>) => void;
}

const ALL_NODE_TYPES = [
  { key: 'Video', label: 'Videos', icon: '▬', color: '#d4a843' },
  { key: 'CommentAuthor', label: 'Users', icon: '●', color: '#3b82f6' },
  { key: 'Comment', label: 'Comments', icon: '·', color: '#6b7280' },
  { key: 'Entity', label: 'Entities', icon: '⬡', color: '#10b981' },
  { key: 'Topic', label: 'Topics', icon: '⬡', color: '#8b5cf6' },
  { key: 'Channel', label: 'Channels', icon: '◆', color: '#ef4444' },
  { key: 'Playlist', label: 'Playlists', icon: '▤', color: '#f59e0b' },
  { key: 'Segment', label: 'Segments', icon: '○', color: '#06b6d4' },
];

export default function GraphControls({
  paused,
  onTogglePause,
  onReconnect,
  filterNodeTypes,
  onFilterChange,
}: GraphControlsProps) {
  const toggleType = (type: string) => {
    const next = new Set(filterNodeTypes);
    if (next.has(type)) {
      next.delete(type);
    } else {
      next.add(type);
    }
    // If all cleared, show all
    if (next.size === 0) {
      ALL_NODE_TYPES.forEach((t) => next.add(t.key));
    }
    onFilterChange(next);
  };

  const showAll = () => {
    onFilterChange(new Set(ALL_NODE_TYPES.map((t) => t.key)));
  };

  return (
    <div className="absolute top-4 right-4 bg-nexum-bg/90 backdrop-blur-md border border-nexum-border/60 rounded-lg p-3 space-y-3 min-w-[200px] z-20">
      {/* Playback controls */}
      <div className="flex items-center gap-2">
        <button
          onClick={onTogglePause}
          className={`flex-1 px-3 py-1.5 rounded text-xs font-mono transition-colors ${
            paused
              ? 'bg-nexum-accent/20 text-nexum-accent hover:bg-nexum-accent/30'
              : 'bg-nexum-border/30 text-nexum-muted hover:bg-nexum-border/50'
          }`}
        >
          {paused ? '▶ Resume' : '⏸ Pause'}
        </button>
        <button
          onClick={onReconnect}
          className="px-3 py-1.5 rounded text-xs font-mono bg-nexum-border/30 text-nexum-muted hover:bg-nexum-border/50 transition-colors"
          title="Reconnect"
        >
          ↻
        </button>
      </div>

      {/* Node type filters */}
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-nexum-muted">Filter Nodes</span>
          <button
            onClick={showAll}
            className="text-[10px] font-mono text-nexum-accent hover:underline"
          >
            Show All
          </button>
        </div>
        {ALL_NODE_TYPES.map((t) => {
          const active = filterNodeTypes.has(t.key);
          return (
            <button
              key={t.key}
              onClick={() => toggleType(t.key)}
              className={`w-full flex items-center gap-2 px-2 py-1 rounded text-xs font-mono transition-all ${
                active
                  ? 'bg-nexum-border/30 text-nexum-text'
                  : 'bg-transparent text-nexum-muted/50 line-through'
              }`}
            >
              <span style={{ color: t.color }}>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
