'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { GraphNode, GraphEdge } from '@/lib/types';

// Node shape/color config per type
const NODE_STYLES: Record<string, { shape: string; color: string; size: number }> = {
  Video:         { shape: 'rectangle',  color: '#d4a843', size: 40 },
  Comment:       { shape: 'ellipse',    color: '#6b7280', size: 12 },
  CommentAuthor: { shape: 'ellipse',    color: '#3b82f6', size: 24 },
  Entity:        { shape: 'hexagon',    color: '#10b981', size: 28 },
  Topic:         { shape: 'hexagon',    color: '#8b5cf6', size: 32 },
  Channel:       { shape: 'diamond',    color: '#ef4444', size: 36 },
};

interface GraphCanvasProps {
  nodes: Map<string, GraphNode>;
  edges: GraphEdge[];
  filterNodeTypes?: Set<string>;
  onNodeClick?: (nodeId: string, nodeType: string) => void;
  maxVisible?: number;
}

export default function GraphCanvas({
  nodes,
  edges,
  filterNodeTypes,
  onNodeClick,
  maxVisible = 500,
}: GraphCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<any>(null);
  const [loaded, setLoaded] = useState(false);

  // Lazy-load Cytoscape (client-only)
  useEffect(() => {
    let mounted = true;
    import('cytoscape').then((mod) => {
      if (!mounted) return;
      const cytoscape = mod.default;

      if (!containerRef.current) return;

      const cy = cytoscape({
        container: containerRef.current,
        style: [
          {
            selector: 'node',
            style: {
              label: 'data(label)',
              'font-size': '9px',
              'font-family': '"JetBrains Mono", monospace',
              color: '#e2e0d8',
              'text-valign': 'bottom',
              'text-margin-y': 6,
              'text-max-width': '80px',
              'text-wrap': 'ellipsis',
              'background-color': 'data(color)',
              shape: 'data(shape)',
              width: 'data(size)',
              height: 'data(size)',
              'border-width': 1,
              'border-color': '#3a3833',
              'overlay-opacity': 0,
            },
          },
          {
            selector: 'edge',
            style: {
              width: 1,
              'line-color': '#4a4840',
              'target-arrow-color': '#4a4840',
              'target-arrow-shape': 'triangle',
              'arrow-scale': 0.6,
              'curve-style': 'bezier',
              opacity: 0.4,
            },
          },
          {
            selector: 'node:selected',
            style: {
              'border-width': 3,
              'border-color': '#d4a843',
              'overlay-opacity': 0.15,
              'overlay-color': '#d4a843',
            },
          },
          // Pulse animation class for new nodes
          {
            selector: '.pulse',
            style: {
              'border-width': 3,
              'border-color': '#d4a843',
            },
          },
        ],
        layout: { name: 'preset' },
        minZoom: 0.1,
        maxZoom: 5,
        wheelSensitivity: 0.3,
      });

      cy.on('tap', 'node', (evt: any) => {
        const node = evt.target;
        onNodeClick?.(node.id(), node.data('nodeType'));
      });

      cyRef.current = cy;
      setLoaded(true);
    });

    return () => {
      mounted = false;
      cyRef.current?.destroy();
    };
  }, [onNodeClick]);

  // Sync nodes and edges to Cytoscape
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy || !loaded) return;

    // Filter nodes by type
    let visibleNodes = Array.from(nodes.values());
    if (filterNodeTypes && filterNodeTypes.size > 0) {
      visibleNodes = visibleNodes.filter((n) => filterNodeTypes.has(n.node_type));
    }

    // Limit to maxVisible (sample if needed)
    if (visibleNodes.length > maxVisible) {
      // Keep more important node types, sample the rest
      const priority = ['Video', 'Channel', 'Entity', 'Topic', 'CommentAuthor', 'Comment'];
      const sorted = visibleNodes.sort(
        (a, b) => priority.indexOf(a.node_type) - priority.indexOf(b.node_type)
      );
      visibleNodes = sorted.slice(0, maxVisible);
    }

    const nodeIds = new Set(visibleNodes.map((n) => n.id));

    // Add/update nodes
    const existingIds = new Set(cy.nodes().map((n: any) => n.id()));

    for (const node of visibleNodes) {
      const style = NODE_STYLES[node.node_type] || NODE_STYLES.Entity;
      const cyData = {
        id: node.id,
        label: node.label.slice(0, 30),
        color: style.color,
        shape: style.shape,
        size: style.size,
        nodeType: node.node_type,
      };

      if (existingIds.has(node.id)) {
        cy.getElementById(node.id).data(cyData);
      } else {
        // Random position near center with jitter
        const angle = Math.random() * Math.PI * 2;
        const radius = 100 + Math.random() * 300;
        cy.add({
          group: 'nodes',
          data: cyData,
          position: {
            x: cy.width() / 2 + Math.cos(angle) * radius,
            y: cy.height() / 2 + Math.sin(angle) * radius,
          },
          classes: 'pulse',
        });
        // Remove pulse after animation
        setTimeout(() => {
          cy.getElementById(node.id)?.removeClass('pulse');
        }, 2000);
      }
    }

    // Remove stale nodes
    cy.nodes().forEach((n: any) => {
      if (!nodeIds.has(n.id())) {
        cy.remove(n);
      }
    });

    // Add edges (only between visible nodes)
    const existingEdgeIds = new Set(cy.edges().map((e: any) => e.id()));
    for (const edge of edges) {
      if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) continue;
      const edgeId = `${edge.source}-${edge.edge_type}-${edge.target}`;
      if (!existingEdgeIds.has(edgeId)) {
        try {
          cy.add({
            group: 'edges',
            data: {
              id: edgeId,
              source: edge.source,
              target: edge.target,
              edgeType: edge.edge_type,
            },
          });
        } catch {
          /* source/target may not exist yet */
        }
      }
    }

    // Run layout periodically if graph changed
    if (visibleNodes.length > 0 && visibleNodes.length <= 200) {
      cy.layout({
        name: 'cose',
        animate: true,
        animationDuration: 800,
        nodeRepulsion: () => 8000,
        idealEdgeLength: () => 100,
        gravity: 0.25,
        numIter: 100,
        randomize: false,
        fit: false,
      }).run();
    }
  }, [nodes, edges, loaded, filterNodeTypes, maxVisible]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full bg-[#1a1916] rounded-lg border border-nexum-border/40"
      style={{ minHeight: '500px' }}
    />
  );
}
