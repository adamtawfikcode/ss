'use client';

import { useState } from 'react';
import {
  ExternalLink,
  Clock,
  Eye,
  ThumbsUp,
  ThumbsDown,
  ChevronDown,
  Type,
  ImageIcon,
  ScanText,
  MessageSquare,
} from 'lucide-react';
import type { SearchResult } from '@/lib/types';
import { getConfidenceBand } from '@/lib/types';
import { formatTimestamp, formatDuration, formatViews, confidenceColor, confidenceLabel, videoUrlWithTimestamp, truncate } from '@/lib/utils';
import { submitFeedback } from '@/lib/api';

interface ResultCardProps {
  result: SearchResult;
  index: number;
  query: string;
}

export default function ResultCard({ result, index, query }: ResultCardProps) {
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState<'up' | 'down' | null>(null);

  const jumpUrl = videoUrlWithTimestamp(result.video_url, result.timestamp);
  const confColor = confidenceColor(result.confidence);
  const confLabel = confidenceLabel(result.confidence);
  const band = getConfidenceBand(result.confidence_score);

  const handleFeedback = async (type: 'upvote' | 'downvote') => {
    try {
      await submitFeedback({
        video_id: result.video_id,
        query_text: query,
        feedback_type: type,
      });
      setFeedbackSent(type === 'upvote' ? 'up' : 'down');
    } catch {
      // silent fail
    }
  };

  const breakdownBars = [
    { key: 'Transcript', value: result.score_breakdown.text_semantic, icon: MessageSquare, color: '#5b9bd5' },
    { key: 'Visual', value: result.score_breakdown.visual_similarity, icon: ImageIcon, color: '#d4a843' },
    { key: 'OCR', value: result.score_breakdown.ocr_match, icon: ScanText, color: '#3ddc84' },
    { key: 'Keyword', value: result.score_breakdown.keyword_match, icon: Type, color: '#f5a623' },
    { key: 'Temporal', value: result.score_breakdown.temporal_coherence, color: '#a07e2e' },
    { key: 'Emotion', value: result.score_breakdown.emotion_context, color: '#e54d4d' },
  ];

  return (
    <div
      className={`card-hover group rounded-2xl border border-nexum-border/50 bg-nexum-surface/70 backdrop-blur-sm overflow-hidden animate-slide-up stagger-${Math.min(index + 1, 6)}`}
      style={{ opacity: 0 }}
    >
      <div className="flex flex-col sm:flex-row">
        {/* Thumbnail */}
        <div className="relative w-full sm:w-56 flex-shrink-0">
          <div className="aspect-video sm:aspect-auto sm:h-full bg-nexum-elevated relative overflow-hidden">
            {result.thumbnail_url ? (
              <img
                src={result.thumbnail_url}
                alt={result.video_title}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-nexum-muted">
                <ImageIcon size={32} />
              </div>
            )}

            {/* Timestamp badge */}
            <a
              href={jumpUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute bottom-2 right-2 flex items-center gap-1 rounded-lg bg-nexum-bg/90 px-2 py-1 text-xs font-mono text-nexum-accent hover:bg-nexum-accent hover:text-nexum-bg transition-colors"
            >
              <Clock size={11} />
              {formatTimestamp(result.timestamp)}
            </a>

            {/* Confidence pip */}
            <div
              className="absolute top-2 left-2 h-2 w-2 rounded-full"
              style={{ backgroundColor: confColor, boxShadow: `0 0 6px ${confColor}60` }}
              title={`Confidence: ${confLabel}`}
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-1 flex-col p-4">
          {/* Title row */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h3 className="font-body font-semibold text-nexum-text leading-snug line-clamp-2">
                {result.video_title}
              </h3>
              <div className="mt-1 flex items-center gap-3 text-xs text-nexum-muted">
                <span>{result.channel_name}</span>
                <span className="text-nexum-border">·</span>
                <span className="flex items-center gap-1">
                  <Eye size={11} />
                  {formatViews(result.view_count)}
                </span>
                <span className="text-nexum-border">·</span>
                <span>{formatDuration(result.duration_seconds)}</span>
              </div>
            </div>

            {/* Score + Calibrated Band */}
            <div className="flex flex-col items-end flex-shrink-0">
              <span
                className="text-lg font-mono font-bold"
                style={{ color: confColor }}
              >
                {(result.score * 100).toFixed(0)}
              </span>
              <span
                className="mt-0.5 rounded-full px-2 py-0.5 text-[10px] font-semibold"
                style={{
                  color: band.color,
                  backgroundColor: band.color + '18',
                  borderWidth: 1,
                  borderColor: band.color + '30',
                }}
              >
                {band.label}
              </span>
            </div>
          </div>

          {/* Transcript snippet */}
          {result.transcript_snippet && (
            <p className="mt-2.5 rounded-lg bg-nexum-bg/50 px-3 py-2 text-sm text-nexum-text/80 font-body leading-relaxed border-l-2 border-nexum-accent/30">
              &ldquo;{truncate(result.transcript_snippet, 200)}&rdquo;
            </p>
          )}

          {/* Tags row */}
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {result.visual_tags.slice(0, 5).map((tag) => (
              <span
                key={tag}
                className="rounded-md bg-nexum-accent/10 px-2 py-0.5 text-[11px] font-mono text-nexum-accent/80 border border-nexum-accent/15"
              >
                {tag}
              </span>
            ))}
            {result.ocr_text && (
              <span className="rounded-md bg-nexum-success/10 px-2 py-0.5 text-[11px] font-mono text-nexum-success/80 border border-nexum-success/15">
                OCR: {truncate(result.ocr_text, 30)}
              </span>
            )}
          </div>

          {/* Explanation */}
          {result.explanation && (
            <p className="mt-2 text-xs text-nexum-muted italic">
              {result.explanation}
            </p>
          )}

          {/* Actions row */}
          <div className="mt-3 flex items-center justify-between border-t border-nexum-border/30 pt-3">
            <div className="flex items-center gap-2">
              {/* Jump to moment */}
              <a
                href={jumpUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 rounded-lg bg-nexum-accent/15 px-3 py-1.5 text-xs font-medium text-nexum-accent hover:bg-nexum-accent/25 transition-colors"
              >
                <ExternalLink size={12} />
                Jump to Moment
              </a>

              {/* Score breakdown toggle */}
              <button
                onClick={() => setShowBreakdown(!showBreakdown)}
                className="flex items-center gap-1 rounded-lg border border-nexum-border/40 px-2.5 py-1.5 text-[11px] text-nexum-muted hover:text-nexum-text hover:border-nexum-border transition-colors"
              >
                Breakdown
                <ChevronDown
                  size={11}
                  className={`transition-transform ${showBreakdown ? 'rotate-180' : ''}`}
                />
              </button>
            </div>

            {/* Feedback */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => handleFeedback('upvote')}
                disabled={feedbackSent !== null}
                className={`rounded-lg p-1.5 transition-colors ${
                  feedbackSent === 'up'
                    ? 'text-nexum-success bg-nexum-success/10'
                    : 'text-nexum-muted hover:text-nexum-success hover:bg-nexum-success/10'
                }`}
              >
                <ThumbsUp size={14} />
              </button>
              <button
                onClick={() => handleFeedback('downvote')}
                disabled={feedbackSent !== null}
                className={`rounded-lg p-1.5 transition-colors ${
                  feedbackSent === 'down'
                    ? 'text-nexum-danger bg-nexum-danger/10'
                    : 'text-nexum-muted hover:text-nexum-danger hover:bg-nexum-danger/10'
                }`}
              >
                <ThumbsDown size={14} />
              </button>
            </div>
          </div>

          {/* Score breakdown panel */}
          {showBreakdown && (
            <div className="mt-3 animate-slide-up rounded-xl border border-nexum-border/30 bg-nexum-bg/50 p-3">
              <div className="space-y-2">
                {breakdownBars.map(({ key, value, icon: Icon, color }) => (
                  <div key={key} className="flex items-center gap-2.5">
                    <span className="w-16 text-right text-[11px] font-mono text-nexum-muted flex items-center justify-end gap-1">
                      {Icon && <Icon size={10} />}
                      {key}
                    </span>
                    <div className="flex-1 h-1.5 rounded-full bg-nexum-elevated overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(value * 100, 100)}%`,
                          backgroundColor: color,
                          opacity: value > 0 ? 1 : 0.2,
                        }}
                      />
                    </div>
                    <span className="w-8 text-right text-[11px] font-mono text-nexum-muted">
                      {(value * 100).toFixed(0)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
