'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { GraphEvent, GraphNode, GraphEdge } from '@/lib/types';

const WS_BASE = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000/api/v1';

interface UseGraphWSOptions {
  maxNodes?: number;
  autoConnect?: boolean;
  replaySince?: number;
}

interface UseGraphWSReturn {
  nodes: Map<string, GraphNode>;
  edges: GraphEdge[];
  events: GraphEvent[];
  connected: boolean;
  paused: boolean;
  eventRate: number;
  togglePause: () => void;
  reconnect: () => void;
}

export function useGraphWebSocket(opts: UseGraphWSOptions = {}): UseGraphWSReturn {
  const { maxNodes = 1000, autoConnect = true, replaySince } = opts;

  const [nodes, setNodes] = useState<Map<string, GraphNode>>(new Map());
  const [edges, setEdges] = useState<GraphEdge[]>([]);
  const [events, setEvents] = useState<GraphEvent[]>([]);
  const [connected, setConnected] = useState(false);
  const [paused, setPaused] = useState(false);
  const [eventRate, setEventRate] = useState(0);

  const wsRef = useRef<WebSocket | null>(null);
  const pausedRef = useRef(false);
  const eventCountRef = useRef(0);
  const nodesRef = useRef(nodes);
  nodesRef.current = nodes;

  // Event rate tracking
  useEffect(() => {
    const interval = setInterval(() => {
      setEventRate(eventCountRef.current);
      eventCountRef.current = 0;
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const processEvent = useCallback((event: GraphEvent) => {
    if (pausedRef.current) return;
    eventCountRef.current++;

    setEvents((prev) => [...prev.slice(-500), event]);

    // Node events
    if (event.node_id && event.node_type) {
      const nodeTypeMap: Record<string, GraphNode['node_type']> = {
        Video: 'Video',
        Comment: 'Comment',
        CommentAuthor: 'CommentAuthor',
        Entity: 'Entity',
        Topic: 'Topic',
        Channel: 'Channel',
      };

      setNodes((prev) => {
        const next = new Map(prev);
        if (next.size >= maxNodes) {
          // Evict oldest node (FIFO)
          const firstKey = next.keys().next().value;
          if (firstKey) next.delete(firstKey);
        }
        next.set(event.node_id!, {
          id: event.node_id!,
          label: event.data?.title as string || event.data?.display_name as string || event.data?.name as string || event.node_id!.slice(0, 8),
          node_type: nodeTypeMap[event.node_type!] || 'Entity',
          data: event.data || undefined,
        });
        return next;
      });
    }

    // Edge events
    if (event.source_id && event.target_id && event.edge_type) {
      setEdges((prev) => [
        ...prev.slice(-(maxNodes * 2)),
        {
          source: event.source_id!,
          target: event.target_id!,
          edge_type: event.edge_type!,
          weight: 1,
        },
      ]);
    }
  }, [maxNodes]);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const params = new URLSearchParams();
    if (replaySince) params.set('replay_since', String(replaySince));
    const url = `${WS_BASE}/ws/graph${params.toString() ? '?' + params : ''}`;

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => setConnected(true);

    ws.onmessage = (msg) => {
      try {
        const event: GraphEvent = JSON.parse(msg.data);
        if (event.event_type !== 'HEARTBEAT') {
          processEvent(event);
        }
      } catch {
        /* ignore */
      }
    };

    ws.onclose = () => {
      setConnected(false);
      // Auto-reconnect after 3s
      setTimeout(() => {
        if (wsRef.current === ws) connect();
      }, 3000);
    };

    ws.onerror = () => setConnected(false);
  }, [processEvent, replaySince]);

  useEffect(() => {
    if (autoConnect) connect();
    return () => {
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [autoConnect, connect]);

  const togglePause = useCallback(() => {
    setPaused((p) => {
      pausedRef.current = !p;
      return !p;
    });
  }, []);

  const reconnect = useCallback(() => {
    wsRef.current?.close();
    connect();
  }, [connect]);

  return { nodes, edges, events, connected, paused, eventRate, togglePause, reconnect };
}
