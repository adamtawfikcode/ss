import type {
  SearchResponse,
  SearchFilters,
  Video,
  AdminStats,
  FusionWeights,
  FeedbackPayload,
  EvaluationMetric,
  VectorStats,
} from './types';

const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

async function request<T>(path: string, opts?: RequestInit): Promise<T> {
  const url = path.startsWith('http') ? path : `${BASE}${path}`;
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...opts?.headers },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${body}`);
  }
  return res.json();
}

// ── Search ──────────────────────────────────────────────

export async function search(
  query: string,
  filters: SearchFilters = {},
  page = 1,
  pageSize = 20,
): Promise<SearchResponse> {
  return request('/search', {
    method: 'POST',
    body: JSON.stringify({
      query,
      filters: Object.keys(filters).length > 0 ? filters : undefined,
      page,
      page_size: pageSize,
    }),
  });
}

// ── Videos ──────────────────────────────────────────────

export async function getVideos(
  page = 1,
  pageSize = 50,
  status?: string,
): Promise<Video[]> {
  const params = new URLSearchParams({
    page: String(page),
    page_size: String(pageSize),
  });
  if (status) params.set('status', status);
  return request(`/videos?${params}`);
}

export async function getVideo(id: string): Promise<Video> {
  return request(`/videos/${id}`);
}

// ── Feedback ────────────────────────────────────────────

export async function submitFeedback(
  payload: FeedbackPayload,
): Promise<{ id: string; status: string }> {
  return request('/feedback', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function getFeedbackStats(): Promise<Record<string, number>> {
  return request('/feedback/stats');
}

// ── Admin ───────────────────────────────────────────────

export async function getAdminStats(): Promise<AdminStats> {
  return request('/admin/metrics');
}

export async function getWeights(): Promise<FusionWeights> {
  return request('/admin/weights');
}

export async function updateWeights(
  weights: Partial<FusionWeights>,
): Promise<{ status: string; weights: Record<string, number> }> {
  return request('/admin/weights', {
    method: 'PUT',
    body: JSON.stringify(weights),
  });
}

export async function triggerReindex(
  videoIds?: string[],
  modelVersion?: string,
): Promise<{ status: string; count: number }> {
  return request('/admin/reindex', {
    method: 'POST',
    body: JSON.stringify({
      video_ids: videoIds,
      model_version: modelVersion,
    }),
  });
}

export async function getEvaluationMetrics(
  limit = 50,
): Promise<EvaluationMetric[]> {
  return request(`/admin/evaluation?limit=${limit}`);
}

export async function getVectorStats(): Promise<VectorStats> {
  return request('/admin/vector-stats');
}

export async function getModels(): Promise<
  Array<{
    id: string;
    name: string;
    version: string;
    model_type: string;
    is_active: boolean;
    created_at: string;
  }>
> {
  return request('/admin/models');
}

// ── SWR fetcher ─────────────────────────────────────────

export const fetcher = <T>(url: string): Promise<T> => request<T>(url);

// ═══════════════════════════════════════════════════════════════════════
// Social Knowledge Graph API (v3)
// ═══════════════════════════════════════════════════════════════════════

import type {
  GraphSnapshot,
  GraphStats,
  CommentData,
  CommentStats,
  CommentAuthor as CommentAuthorType,
  EntityData,
  ThreadData,
  DebateCluster,
  GraphEvent,
} from './types';

// ── Graph ───────────────────────────────────────────────

export async function getGraphSnapshot(
  nodeTypes?: string,
  limit = 500,
  centerId?: string,
  centerType?: string,
): Promise<GraphSnapshot> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (nodeTypes) params.set('node_types', nodeTypes);
  if (centerId) params.set('center_id', centerId);
  if (centerType) params.set('center_type', centerType);
  return request(`/graph/snapshot?${params}`);
}

export async function getGraphStats(): Promise<GraphStats> {
  return request('/graph/stats');
}

export async function getGraphHealth(): Promise<{ status: string; neo4j: string }> {
  return request('/graph/health');
}

export async function getThread(commentId: string): Promise<ThreadData> {
  return request(`/graph/thread/${commentId}`);
}

export async function getThreadAnalysis(commentId: string): Promise<Record<string, unknown>> {
  return request(`/graph/thread/${commentId}/analysis`);
}

export async function getDebates(videoId: string, minDepth = 3): Promise<DebateCluster[]> {
  return request(`/graph/debates/${videoId}?min_depth=${minDepth}`);
}

export async function getLongestChains(videoId: string): Promise<Array<Record<string, unknown>>> {
  return request(`/graph/chains/${videoId}`);
}

export async function getEntityNetwork(
  entityName: string,
  depth = 2,
): Promise<Record<string, unknown>> {
  return request(`/graph/entities/${encodeURIComponent(entityName)}/network?depth=${depth}`);
}

export async function getUserInteractionLoops(): Promise<Array<Record<string, unknown>>> {
  return request('/graph/users/loops');
}

// ── Comments ────────────────────────────────────────────

export async function getVideoComments(
  videoId: string,
  page = 1,
  pageSize = 50,
  sort = 'likes',
): Promise<CommentData[]> {
  const params = new URLSearchParams({
    page: String(page),
    page_size: String(pageSize),
    sort,
  });
  return request(`/comments/${videoId}?${params}`);
}

export async function getCommentStats(): Promise<CommentStats> {
  return request('/comments/stats/summary');
}

export async function getTopAuthors(limit = 20): Promise<CommentAuthorType[]> {
  return request(`/comments/authors/top?limit=${limit}`);
}

export async function getTopEntities(limit = 30): Promise<EntityData[]> {
  return request(`/comments/entities/top?limit=${limit}`);
}

export async function triggerCommentIngestion(
  videoId: string,
  maxComments = 200,
): Promise<{ video_id: string; status: string }> {
  return request('/comments/ingest', {
    method: 'POST',
    body: JSON.stringify({
      video_id: videoId,
      max_comments: maxComments,
      include_replies: true,
      max_reply_depth: 20,
    }),
  });
}

// ── WebSocket ───────────────────────────────────────────

const WS_BASE = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000/api/v1';

export function createGraphWebSocket(
  onEvent: (event: GraphEvent) => void,
  onError?: (err: Event) => void,
  replaySince?: number,
): WebSocket {
  const params = new URLSearchParams();
  if (replaySince) params.set('replay_since', String(replaySince));
  const url = `${WS_BASE}/ws/graph${params.toString() ? '?' + params : ''}`;

  const ws = new WebSocket(url);

  ws.onmessage = (msg) => {
    try {
      const event: GraphEvent = JSON.parse(msg.data);
      if (event.event_type !== 'HEARTBEAT') {
        onEvent(event);
      }
    } catch {
      // Ignore malformed messages
    }
  };

  ws.onerror = (err) => {
    console.error('Graph WS error:', err);
    onError?.(err);
  };

  // Auto-reconnect
  ws.onclose = () => {
    setTimeout(() => {
      const newWs = createGraphWebSocket(onEvent, onError, replaySince);
      Object.assign(ws, newWs);
    }, 3000);
  };

  return ws;
}

export async function getWebSocketStats(): Promise<Record<string, unknown>> {
  return request('/ws/stats');
}

// ── Audio Intelligence ─────────────────────────────────

export async function getAudioSegments(
  videoId: string,
  page = 1,
  pageSize = 50,
  sourceFilter?: string,
): Promise<import('./types').AudioSegmentData[]> {
  const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
  if (sourceFilter) params.set('source_filter', sourceFilter);
  return request(`/audio/${videoId}?${params}`);
}

export async function getAudioSummary(
  videoId: string,
): Promise<import('./types').AudioAnalysisSummary> {
  return request(`/audio/${videoId}/summary`);
}

export async function searchByAudioEvent(
  event: string,
  minConfidence = 0.3,
  limit = 50,
): Promise<Array<Record<string, unknown>>> {
  const params = new URLSearchParams({
    event,
    min_confidence: String(minConfidence),
    limit: String(limit),
  });
  return request(`/audio/events/search?${params}`);
}

export async function getAudioStats(): Promise<import('./types').AudioStats> {
  return request('/audio/stats/overview');
}

// ═══════════════════════════════════════════════════════════════════════
// Calibrated Intelligence API (v4)
// ═══════════════════════════════════════════════════════════════════════

import type {
  CalibrationStatus,
  CalibratedScore,
  AlignmentSummary,
  ChangePointResult,
} from './types';

// ── Calibration ─────────────────────────────────────────

export async function getCalibrationStatus(): Promise<CalibrationStatus> {
  return request('/v4/calibration/status');
}

export async function triggerCalibrationFit(): Promise<{
  status: string;
  targets_fitted: number;
  total_targets: number;
}> {
  return request('/v4/calibration/fit', { method: 'POST' });
}

export async function testCalibration(
  target: string,
  rawScore: number,
): Promise<CalibratedScore> {
  return request(`/v4/calibration/test?target=${encodeURIComponent(target)}&raw_score=${rawScore}`);
}

// ── Alignment ───────────────────────────────────────────

export async function getAlignment(videoId: string): Promise<AlignmentSummary> {
  return request(`/v4/alignment/${videoId}`);
}

// ── Change Points ───────────────────────────────────────

export async function getChangePoints(
  videoId: string,
  minMagnitude = 0,
): Promise<ChangePointResult> {
  return request(`/v4/change-points/${videoId}?min_magnitude=${minMagnitude}`);
}

export async function searchByTransition(
  transitionType: string,
  limit = 50,
): Promise<Array<{ video_id: string; timestamp: number; magnitude: number; detail: string }>> {
  return request(`/v4/change-points/search/transition?transition_type=${encodeURIComponent(transitionType)}&limit=${limit}`);
}

// ═══════════════════════════════════════════════════════════════════════
// Legal API
// ═══════════════════════════════════════════════════════════════════════

export interface PrivacyPolicyMeta {
  version: string;
  effective_date: string;
  last_updated: string;
  contact_email: string;
  removal_email: string;
  sections: Array<{ number: number; title: string; anchor: string }>;
  youtube_tos_url: string;
  google_privacy_url: string;
  google_revoke_url: string;
}

export async function getPrivacyPolicyMeta(): Promise<PrivacyPolicyMeta> {
  return request('/legal/privacy');
}

export async function getPrivacyPolicyVersion(): Promise<{ version: string; effective_date: string }> {
  return request('/legal/privacy/version');
}

// ═══════════════════════════════════════════════════════════════════════
// Demo Mode API
// ═══════════════════════════════════════════════════════════════════════

import type { DemoStats, DemoSnapshot, QueueStatus, QueueJob, QueueEvent } from './types';

export async function getDemoSnapshot(
  nodeTypes?: string,
  limit = 5000,
): Promise<DemoSnapshot> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (nodeTypes) params.set('node_types', nodeTypes);
  return request(`/demo/snapshot?${params}`);
}

export async function getDemoStats(): Promise<DemoStats> {
  return request('/demo/stats');
}

export async function createDemoNode(
  nodeType: string,
  data?: Record<string, unknown>,
): Promise<{ id: string; label: string; node_type: string; data: Record<string, unknown>; edges_created: number }> {
  return request('/demo/nodes', {
    method: 'POST',
    body: JSON.stringify({ node_type: nodeType, data: data || {} }),
  });
}

export async function listDemoNodes(
  nodeType: string,
  page = 1,
  pageSize = 50,
): Promise<{ node_type: string; total: number; items: Record<string, unknown>[] }> {
  return request(`/demo/nodes/${nodeType}?page=${page}&page_size=${pageSize}`);
}

export async function resetDemo(): Promise<{ status: string; stats: Record<string, number> }> {
  return request('/demo/reset', { method: 'POST' });
}

export async function getDemoStatus(): Promise<{ demo_active: boolean; generated: boolean }> {
  return request('/demo/status');
}

// ═══════════════════════════════════════════════════════════════════════
// Priority Queue API
// ═══════════════════════════════════════════════════════════════════════

export async function enqueueUrl(
  url: string,
  priority: 'normal' | 'immediate' = 'normal',
  jobType?: string,
): Promise<{ job_id: string; url: string; job_type: string; priority: string; status: string; queue_position: number | null }> {
  return request('/queue/enqueue', {
    method: 'POST',
    body: JSON.stringify({ url, priority, job_type: jobType }),
  });
}

export async function getQueueStatus(): Promise<QueueStatus> {
  return request('/queue/status');
}

export async function getJobStatus(jobId: string): Promise<QueueJob> {
  return request(`/queue/job/${jobId}`);
}

export async function cancelJob(jobId: string): Promise<{ status: string; job: QueueJob }> {
  return request(`/queue/cancel/${jobId}`, { method: 'POST' });
}

export function createQueueWebSocket(
  onEvent: (event: QueueEvent) => void,
  onError?: (err: Event) => void,
): WebSocket {
  const url = `${WS_BASE}/queue/ws/queue`;
  const ws = new WebSocket(url);

  ws.onmessage = (msg) => {
    try {
      const event: QueueEvent = JSON.parse(msg.data);
      onEvent(event);
    } catch {
      // ignore
    }
  };

  ws.onerror = (err) => {
    console.error('Queue WS error:', err);
    onError?.(err);
  };

  ws.onclose = () => {
    setTimeout(() => {
      createQueueWebSocket(onEvent, onError);
    }, 3000);
  };

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════
// v4.2: Signal & Recrawl APIs
// ═══════════════════════════════════════════════════════════════════════

export async function getSignalStats(): Promise<{ signals: Record<string, number>; total: number }> {
  const res = await fetch(`${API_BASE}/signals/stats`);
  return res.json();
}

export async function getSignalsForVideo(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/signals/video/${videoId}`);
  return res.json();
}

export async function getSignalsForChannel(channelId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/signals/channel/${channelId}`);
  return res.json();
}

export async function getTemporalVisualSignals(videoId?: string): Promise<any> {
  const params = videoId ? `?video_id=${videoId}` : '';
  const res = await fetch(`${API_BASE}/signals/temporal-visual${params}`);
  return res.json();
}

export async function getAudioMicroSignals(videoId?: string): Promise<any> {
  const params = videoId ? `?video_id=${videoId}` : '';
  const res = await fetch(`${API_BASE}/signals/audio-micro${params}`);
  return res.json();
}

export async function getBehavioralSignals(videoId?: string, channelId?: string): Promise<any> {
  const params = new URLSearchParams();
  if (videoId) params.set('video_id', videoId);
  if (channelId) params.set('channel_id', channelId);
  const res = await fetch(`${API_BASE}/signals/behavioral?${params}`);
  return res.json();
}

export async function getCommentArchaeology(videoId?: string): Promise<any> {
  const params = videoId ? `?video_id=${videoId}` : '';
  const res = await fetch(`${API_BASE}/signals/comment-archaeology${params}`);
  return res.json();
}

export async function getCrossVideoForensics(videoId?: string, channelId?: string): Promise<any> {
  const params = new URLSearchParams();
  if (videoId) params.set('video_id', videoId);
  if (channelId) params.set('channel_id', channelId);
  const res = await fetch(`${API_BASE}/signals/cross-video?${params}`);
  return res.json();
}

export async function getLinguisticSignals(videoId?: string): Promise<any> {
  const params = videoId ? `?video_id=${videoId}` : '';
  const res = await fetch(`${API_BASE}/signals/linguistic${params}`);
  return res.json();
}

export async function getGraphRelationalSignals(channelId?: string, authorId?: string, entityId?: string): Promise<any> {
  const params = new URLSearchParams();
  if (channelId) params.set('channel_id', channelId);
  if (authorId) params.set('author_id', authorId);
  if (entityId) params.set('entity_id', entityId);
  const res = await fetch(`${API_BASE}/signals/graph-relational?${params}`);
  return res.json();
}

// Recrawl APIs
export async function getStaleVideos(maxAgeHours: number = 168): Promise<{ stale_videos: any[]; count: number }> {
  const res = await fetch(`${API_BASE}/recrawl/stale/videos?max_age_hours=${maxAgeHours}`);
  return res.json();
}

export async function getStaleChannels(maxAgeHours: number = 336): Promise<{ stale_channels: any[]; count: number }> {
  const res = await fetch(`${API_BASE}/recrawl/stale/channels?max_age_hours=${maxAgeHours}`);
  return res.json();
}

export async function getRecrawlHistory(videoId?: string): Promise<{ events: any[]; count: number }> {
  const params = videoId ? `?video_id=${videoId}` : '';
  const res = await fetch(`${API_BASE}/recrawl/history${params}`);
  return res.json();
}

export async function getRecrawlStats(): Promise<any> {
  const res = await fetch(`${API_BASE}/recrawl/stats`);
  return res.json();
}

// ═══════════════════════════════════════════════════════════════════════
// Intelligence API (v5.0)
// ═══════════════════════════════════════════════════════════════════════

export async function getIntelligenceFlags(): Promise<{ flags: Record<string, boolean> }> {
  const res = await fetch(`${API_BASE}/intelligence/flags`);
  return res.json();
}

export async function setIntelligenceFlags(flags: Record<string, boolean>): Promise<{ flags: Record<string, boolean> }> {
  const res = await fetch(`${API_BASE}/intelligence/flags`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(flags),
  });
  return res.json();
}

export async function getTemporalIntelligence(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/temporal/${videoId}`);
  return res.json();
}

export async function getStyleFingerprint(entityId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/style/${entityId}`);
  return res.json();
}

export async function getAuthenticity(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/authenticity/${videoId}`);
  return res.json();
}

export async function getSocialDynamics(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/social/${videoId}`);
  return res.json();
}

export async function getSemanticIntent(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/intent/${videoId}`);
  return res.json();
}

export async function getCreatorEvolution(channelId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/evolution/${channelId}`);
  return res.json();
}

export async function getGraphIntelligence(entityId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/graph/${entityId}`);
  return res.json();
}

export async function getMetaQuality(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/quality/${videoId}`);
  return res.json();
}

export async function getFullIntelligence(videoId: string): Promise<any> {
  const res = await fetch(`${API_BASE}/intelligence/full/${videoId}`);
  return res.json();
}
