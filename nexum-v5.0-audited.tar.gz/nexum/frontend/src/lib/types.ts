// Nexum Frontend Types — aligned with backend Pydantic schemas

export interface SearchResult {
  video_id: string;
  video_title: string;
  channel_name: string | null;
  video_url: string;
  thumbnail_url: string | null;
  timestamp: number;
  end_timestamp: number | null;
  transcript_snippet: string | null;
  visual_tags: string[];
  ocr_text: string | null;
  confidence_score: number;
  modality_scores: ModalityScores;
  explanation: string;
  video_url_with_timecode: string;
  view_count: number | null;
}

export interface ModalityScores {
  text_semantic: number;
  visual_similarity: number;
  ocr_match: number;
  keyword_match: number;
  temporal_coherence: number;
  emotion_context: number;
  comment_semantic: number;
  comment_timestamp_boost: number;
  agreement_cluster: number;
  entity_overlap: number;
  user_cluster_confidence: number;
  audio_event_match: number;
  audio_attribute_match: number;
  alignment_quality: number;
  change_point_proximity: number;
}

export interface SearchResponse {
  query: string;
  total_results: number;
  page: number;
  page_size: number;
  results: SearchResult[];
  query_decomposition: QueryDecomposition | null;
  latency_ms: number;
}

export interface QueryDecomposition {
  objects: string[];
  actions: string[];
  numbers: string[];
  time_era: string | null;
  emotion: string | null;
  context: string | null;
}

export interface QueryAnalysis {
  objects: string[];
  actions: string[];
  numbers: string[];
  emotion: string[];
  context: string[];
}

export interface Video {
  id: string;
  platform: string;
  platform_id: string;
  title: string;
  description: string | null;
  url: string;
  thumbnail_url: string | null;
  duration_seconds: number | null;
  view_count: number | null;
  like_count: number | null;
  comment_count: number | null;
  tags: string[] | null;
  categories: string[] | null;
  live_status: string | null;
  status: string;
  language: string | null;
  channel_name: string | null;
  segment_count: number;
  frame_count: number;
  created_at: string;
  chapters?: Array<{ title: string; start_time: number; end_time?: number }>;
  captions_info?: Record<string, string[]>;
  segments?: Segment[];
  frames?: Frame[];
  subtitles?: SubtitleTrack[];
  streams?: StreamInfo[];
}

export interface Channel {
  id: string;
  platform: string;
  name: string;
  url: string;
  priority_tier: number;
}

export interface Segment {
  id: string;
  start_time: number;
  end_time: number;
  text: string;
  confidence: number;
  speaker_label: string | null;
}

export interface Frame {
  id: string;
  timestamp: number;
  visual_tags: Array<{ label: string; confidence: number; category: string }> | null;
  ocr_text: string | null;
  ocr_confidence: number | null;
  scene_label: string | null;
  is_scene_change: boolean;
}

export interface SearchFilters {
  min_duration?: number;
  max_duration?: number;
  min_views?: number;
  channels?: string[];
  language?: string;
  min_confidence?: number;
  modality?: 'all' | 'transcript' | 'visual' | 'ocr';
}

export interface AdminStats {
  total_videos: number;
  indexed_videos: number;
  queued_videos: number;
  failed_videos: number;
  total_segments: number;
  total_frames: number;
  total_feedback: number;
  upvote_ratio: number;
  avg_search_latency_ms: number;
  worker_count: number;
  queue_depth: number;
  storage_used_gb: number;
  // Graph stats
  total_comments: number;
  total_entities: number;
  total_comment_authors: number;
  total_topics: number;
  total_playlists: number;
  total_community_posts: number;
  graph_edges: number;
  // Audio stats
  total_audio_segments: number;
  total_change_points: number;
  total_alignment_warnings: number;
  avg_alignment_score: number;
  calibration_version: string;
}

export interface FusionWeights {
  weight_text_semantic: number;
  weight_visual_similarity: number;
  weight_ocr_match: number;
  weight_keyword_match: number;
  weight_temporal_coherence: number;
  weight_emotion_context: number;
  weight_comment_semantic: number;
  weight_comment_timestamp_boost: number;
  weight_agreement_cluster: number;
  weight_entity_overlap: number;
  weight_user_cluster_confidence: number;
  weight_audio_event_match: number;
  weight_audio_attribute_match: number;
  weight_alignment_quality: number;
  weight_change_point_proximity: number;
}

export interface FeedbackPayload {
  video_id: string;
  segment_id?: string;
  query_text: string;
  feedback_type: 'upvote' | 'downvote' | 'timestamp_correction' | 'mismatch_report';
  suggested_timestamp?: number;
  comment?: string;
}

export interface EvaluationMetric {
  id: string | number;
  metric_name: string;
  metric_value: number;
  model_version: string | null;
  measured_at: string;
}

export interface VectorStats {
  [collection: string]: {
    points_count: number;
    vectors_count: number;
    status: string;
  };
}

// ═══════════════════════════════════════════════════════════════════════
// Social Knowledge Graph Types (v3)
// ═══════════════════════════════════════════════════════════════════════

// ── Graph Visualization ─────────────────────────────────────────────────

export interface GraphNode {
  id: string;
  label: string;
  node_type: 'Video' | 'Comment' | 'CommentAuthor' | 'Entity' | 'Topic' | 'Channel' | 'Playlist' | 'Segment';
  data?: Record<string, unknown>;
}

export interface GraphEdge {
  source: string;
  target: string;
  edge_type: string;
  weight: number;
  data?: Record<string, unknown>;
}

export interface GraphSnapshot {
  nodes: GraphNode[];
  edges: GraphEdge[];
  total_nodes: number;
  total_edges: number;
  sampled: boolean;
}

export interface GraphStats {
  video_count: number;
  comment_count: number;
  commentauthor_count: number;
  entity_count: number;
  topic_count: number;
  channel_count: number;
  total_edges: number;
}

// ── Graph Events (WebSocket) ────────────────────────────────────────────

export type GraphEventType =
  | 'VIDEO_ADDED'
  | 'COMMENT_ADDED'
  | 'USER_CREATED'
  | 'ENTITY_DISCOVERED'
  | 'CHANNEL_LINKED'
  | 'COMMENT_LINKED'
  | 'USER_CONNECTED'
  | 'ENTITY_CO_OCCURRENCE'
  | 'THREAD_EXPANDED'
  | 'HEARTBEAT'
  | 'STATS_UPDATE';

export interface GraphEvent {
  event_type: GraphEventType;
  timestamp: number;
  node_type?: string;
  node_id?: string;
  edge_type?: string;
  source_id?: string;
  target_id?: string;
  data?: Record<string, unknown>;
}

// ── Comments ────────────────────────────────────────────────────────────

export interface CommentData {
  id: string;
  platform_comment_id: string;
  video_id: string;
  author_display_name: string | null;
  parent_comment_id: string | null;
  root_thread_id: string | null;
  depth_level: number;
  child_count: number;
  text: string;
  like_count: number;
  reply_count: number;
  language: string | null;
  sentiment_score: number | null;
  sentiment_label: string | null;
  toxicity_score: number | null;
  topic_labels: string[] | null;
  entities: string[] | null;
  extracted_timestamps: string[] | null;
  status: string;
  timestamp_posted: string | null;
}

export interface CommentAuthor {
  id: string;
  display_name: string;
  platform: string;
  comment_count: number;
  first_seen_at: string | null;
  last_seen_at: string | null;
  sentiment_distribution: Record<string, number> | null;
}

export interface CommentStats {
  total_comments: number;
  processed: number;
  pending: number;
  spam_filtered: number;
  toxic_filtered: number;
  total_authors: number;
  total_entities: number;
  avg_thread_depth: number;
  max_thread_depth: number;
  spam_rate: number;
}

// ── Entities ────────────────────────────────────────────────────────────

export interface EntityData {
  id: string;
  canonical_name: string;
  entity_type: string;
  mention_count: number;
  aliases: string[] | null;
  first_seen_at: string | null;
}

// ── Thread Analysis ─────────────────────────────────────────────────────

export interface ThreadData {
  root_id: string;
  comments: Array<{
    id: string;
    text: string;
    depth: number;
    sentiment: number | null;
    likes: number;
    posted: string | null;
    author: string | null;
    author_id: string | null;
  }>;
  total_comments: number;
  total_depth: number;
}

export interface DebateCluster {
  root_id: string;
  root_text: string;
  reply_count: number;
  avg_sentiment: number;
  debate_score: number;
  max_depth: number;
}

// ── WebSocket Stats ─────────────────────────────────────────────────────

export interface WebSocketStats {
  total_events_emitted: number;
  active_connections: number;
  buffer_size: number;
  buffer_capacity: number;
}

// ── Node Visual Config ──────────────────────────────────────────────────

export const NODE_COLORS: Record<string, string> = {
  Video: '#d4a843',
  Comment: '#6b7280',
  CommentAuthor: '#3b82f6',
  Entity: '#10b981',
  Topic: '#8b5cf6',
  Channel: '#ef4444',
  Playlist: '#f59e0b',
  Segment: '#06b6d4',
};

export const NODE_SHAPES: Record<string, string> = {
  Video: 'rectangle',
  Comment: 'ellipse',
  CommentAuthor: 'ellipse',
  Entity: 'hexagon',
  Topic: 'diamond',
  Channel: 'diamond',
  Playlist: 'rectangle',
  Segment: 'ellipse',
};

// ═══════════════════════════════════════════════════════════════════════
// Audio Intelligence Types (v3.1)
// ═══════════════════════════════════════════════════════════════════════

export interface AudioEvent {
  label: string;
  confidence: number;
  category: string;
}

export interface ManipulationScores {
  speed_anomaly: number;
  pitch_shift: number;
  compression: number;
  reverb_echo: number;
  robotic_autotune: number;
  time_stretch: number;
  overall_manipulation: number;
}

export interface AudioSegmentData {
  id: string;
  video_id: string;
  start_time: number;
  end_time: number;
  music_probability: number;
  speech_probability: number;
  dominant_source: string | null;
  source_tags: AudioEvent[] | null;
  event_tags: AudioEvent[] | null;
  manipulation_scores: ManipulationScores | null;
  overall_manipulation: number;
  bpm: number | null;
  musical_key: string | null;
  loudness_lufs: number | null;
  dynamic_range_db: number | null;
  spectral_centroid: number | null;
  harmonic_ratio: number | null;
}

export interface AudioAnalysisSummary {
  video_id: string;
  duration_seconds: number;
  total_windows: number;
  global_bpm: number | null;
  global_key: string | null;
  dominant_source: string;
  total_music_seconds: number;
  total_speech_seconds: number;
  total_silence_seconds: number;
  manipulation_summary: ManipulationScores | null;
}

export interface AudioStats {
  total_audio_segments: number;
  videos_with_audio_analysis: number;
  avg_music_ratio: number;
  avg_speech_ratio: number;
  manipulation_flagged_count: number;
}

// ═══════════════════════════════════════════════════════════════════════
// Calibrated Intelligence Types (v4)
// ═══════════════════════════════════════════════════════════════════════

// Legacy aliases — consolidated into base types above
export type ModalityScoresV4 = ModalityScores;
export type FusionWeightsV4 = FusionWeights;

// ── Confidence Calibration ──────────────────────────────────────────────

export interface CalibratedScore {
  raw_score: number;
  calibrated_probability: number;
  band: number;
  band_label: string;
  band_color: string;
  model_name: string;
  calibration_version: string;
}

export interface CalibrationStatus {
  version: string;
  targets: Record<string, {
    is_fitted: boolean;
    method: string;
    sample_count: number;
    last_fitted: string | null;
  }>;
}

export const CONFIDENCE_BANDS: { min: number; max: number; label: string; color: string }[] = [
  { min: 0, max: 0.25, label: 'Weak', color: '#94a3b8' },
  { min: 0.25, max: 0.5, label: 'Low', color: '#fbbf24' },
  { min: 0.5, max: 0.75, label: 'Moderate', color: '#3b82f6' },
  { min: 0.75, max: 0.9, label: 'Strong', color: '#10b981' },
  { min: 0.9, max: 1.0, label: 'Very Strong', color: '#059669' },
];

export function getConfidenceBand(score: number) {
  return CONFIDENCE_BANDS.find(b => score >= b.min && score < b.max) ?? CONFIDENCE_BANDS[CONFIDENCE_BANDS.length - 1];
}

// ── Audio-Transcript Alignment ──────────────────────────────────────────

export interface AlignmentSignal {
  name: string;
  score: number;
  detail: string;
}

export interface AlignmentSegment {
  start_time: number;
  end_time: number;
  alignment_score: number;
  quality_level: 'good' | 'acceptable' | 'poor' | 'mismatch';
  signals: AlignmentSignal[];
  warnings: string[];
}

export interface AlignmentSummary {
  video_id: string;
  overall_score: number;
  overall_quality: string;
  total_warnings: number;
  mismatch_regions: [number, number][];
  segments: AlignmentSegment[];
}

export const ALIGNMENT_COLORS: Record<string, string> = {
  good: '#10b981',
  acceptable: '#3b82f6',
  poor: '#f59e0b',
  mismatch: '#ef4444',
};

// ── Acoustic Change Points ──────────────────────────────────────────────

export interface ChangePoint {
  timestamp: number;
  magnitude: number;
  transition_type: string;
  detail: string;
  from_state: string;
  to_state: string;
}

export interface ChangePointResult {
  video_id: string;
  total_change_points: number;
  total_duration: number;
  num_scenes: number;
  dominant_transitions: string[];
  change_points: ChangePoint[];
}

export const TRANSITION_ICONS: Record<string, string> = {
  silence_to_music: '🎵',
  music_to_silence: '🔇',
  silence_to_speech: '🗣️',
  speech_to_silence: '🔇',
  music_to_speech: '🗣️',
  speech_to_music: '🎵',
  energy_spike: '⚡',
  energy_drop: '📉',
  event_onset: '🔔',
  harmonic_shift: '🎹',
  tempo_change: '🥁',
};

// ── System Metrics V4 ───────────────────────────────────────────────────

export interface SystemMetricsV4 extends AdminStats {
  total_change_points: number;
  total_alignment_warnings: number;
  avg_alignment_score: number;
  calibration_version: string;
}


// ── New Data Types (v4.1) ──────────────────────────────────

// ── Priority Queue Types ──────────────────────────────────

export type JobStatus = 'pending' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';
export type JobPriority = 'normal' | 'immediate';

export interface QueueJob {
  id: string;
  url: string;
  job_type: string;
  priority: JobPriority;
  status: JobStatus;
  progress: number;
  message: string;
  created_at: number;
  started_at: number | null;
  completed_at: number | null;
  error: string | null;
  result: Record<string, unknown> | null;
  interrupted_by: string | null;
  resume_count: number;
}

export interface QueueStatus {
  is_processing: boolean;
  current_job: QueueJob | null;
  priority_stack: QueueJob[];
  normal_queue: QueueJob[];
  paused_jobs: QueueJob[];
  completed_recent: QueueJob[];
  stats: {
    total_enqueued: number;
    pending_normal: number;
    pending_priority: number;
    paused: number;
    completed: number;
    failed: number;
  };
}

export interface QueueEvent {
  type: 'job_enqueued' | 'job_started' | 'job_progress' | 'job_paused' | 'job_resumed' | 'job_completed' | 'job_failed' | 'job_cancelled' | 'initial_state' | 'pong';
  job?: QueueJob;
  data?: QueueStatus;
}

export const JOB_STATUS_COLORS: Record<JobStatus, string> = {
  pending: '#94a3b8',
  running: '#3b82f6',
  paused: '#f59e0b',
  completed: '#10b981',
  failed: '#ef4444',
  cancelled: '#6b7280',
};

// ── Demo Mode Types ──────────────────────────────────────

export interface DemoStats {
  node_counts: Record<string, number>;
  total_nodes: number;
  total_edges: number;
  edge_type_distribution: Record<string, number>;
  demo_mode: boolean;
  signal_stats?: Record<string, number>;
}

export interface DemoSnapshot extends GraphSnapshot {
  stats: Record<string, number>;
  signal_stats?: Record<string, number>;
  demo_mode: boolean;
}

// v4.2: Signal types
export interface SignalStats {
  signals: Record<string, number>;
  total: number;
}

export interface RecrawlEvent {
  id: string;
  video_id: string;
  trigger: string;
  fields_changed: string[];
  delta_json: Record<string, [any, any]>;
  comments_added: number;
  comments_deleted: number;
  description_changed: boolean;
  title_changed: boolean;
  duration_ms?: number;
  created_at: string;
  updated_at: string;
}

export interface RecrawlStats {
  total_recrawls: number;
  by_trigger: Record<string, number>;
  fields_changed_frequency: Record<string, number>;
  avg_comments_added: number;
  avg_comments_deleted: number;
  title_changes: number;
  description_changes: number;
}

export interface StaleVideo {
  video_id: string;
  platform_id: string;
  title: string;
  last_crawled_at: string | null;
  updated_at: string | null;
  hours_stale: number;
  priority_score: number;
}

export const SIGNAL_CATEGORIES = [
  { key: 'temporal_visual', label: 'Temporal-Visual', icon: '👁', color: 'blue' },
  { key: 'audio_micro', label: 'Audio Micro', icon: '🎙', color: 'purple' },
  { key: 'behavioral', label: 'Behavioral', icon: '📊', color: 'amber' },
  { key: 'comment_archaeology', label: 'Comment Archaeology', icon: '🏺', color: 'orange' },
  { key: 'cross_video', label: 'Cross-Video Forensics', icon: '🔍', color: 'red' },
  { key: 'linguistic', label: 'Linguistic', icon: '🗣', color: 'green' },
  { key: 'graph_relational', label: 'Graph-Relational', icon: '🕸', color: 'cyan' },
] as const;

export interface Playlist {
  id: string;
  platform_playlist_id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  video_count: number;
  url: string;
}

export interface PlaylistItem {
  platform_video_id: string;
  position: number;
  video_id?: string;
}

export interface SubtitleTrack {
  id: string;
  language: string;
  language_name?: string;
  is_auto_generated: boolean;
  format: string;
  cue_count: number;
}

export interface StreamInfo {
  stream_type: string;
  codec?: string;
  bitrate?: number;
  resolution?: string;
  fps?: number;
  sample_rate?: number;
  channels?: number;
  container_format?: string;
  file_size_bytes?: number;
}

export interface CommunityPost {
  id: string;
  platform_post_id: string;
  text?: string;
  post_type: string;
  like_count: number;
  comment_count: number;
  posted_at?: string;
}

export interface ChannelDetail {
  id: string;
  platform: string;
  platform_id: string;
  name: string;
  url: string;
  custom_url?: string;
  description?: string;
  country?: string;
  subscriber_count?: number;
  total_videos?: number;
  banner_url?: string;
  video_count: number;
  playlist_count: number;
}

// ═══════════════════════════════════════════════════════════════════════
// Intelligence Layer Types (v5.0)
// ═══════════════════════════════════════════════════════════════════════

export interface ConfidenceBand {
  value: number;
  lower: number;
  upper: number;
  method: string;
}

export interface TemporalCurveData {
  type: string;
  sample_count: number;
  mean: number;
  max: number;
  values: number[];
}

export interface TemporalIntelligence {
  video_id: string;
  layer: 'temporal_behavior';
  speech_rate_curve: TemporalCurveData;
  energy_curve: TemporalCurveData;
  music_density_curve: TemporalCurveData;
  silence: {
    total_seconds: number;
    ratio: number;
    gap_count: number;
    dramatic_pauses: number;
  };
  derived: {
    excitement_ramp: number;
    attention_decay: number;
    highlights: [number, number][];
    info_density_per_min: number[];
    pacing_quality: number;
    confidence: number;
  };
}

export interface StyleFingerprint {
  entity_id: string;
  layer: 'style_fingerprint';
  visual: {
    motion_smoothness: number;
    cut_freq: number;
    clutter: number;
    text_density: number;
  };
  audio: {
    loudness_mean: number;
    mic_quality: number;
    normalization: string;
    noise_type: string;
  };
  linguistic: {
    vocab_entropy: number;
    formality: number;
    hedging: number;
    slang: number;
    filler_rate: number;
    ttr: number;
  };
  style_vector: {
    dim: number;
    confidence: number;
    vector: number[];
  };
}

export interface AuthenticityReport {
  video_id: string;
  layer: 'authenticity';
  overall_integrity: number;
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  cross_modal_consistency: number;
  video: {
    frame_interpolation: ConfidenceBand;
    cgi_probability: ConfidenceBand;
    compression_artifacts: ConfidenceBand;
    lip_sync_mismatch: ConfidenceBand;
    deepfake_probability: ConfidenceBand;
    overall: number;
    flags: string[];
  };
  audio: {
    formant_drift: ConfidenceBand;
    synthetic_speech: ConfidenceBand;
    over_denoising: ConfidenceBand;
    time_stretch: ConfidenceBand;
    voice_cloning: ConfidenceBand;
    overall: number;
    flags: string[];
  };
  confidence: number;
}

export interface SocialDynamics {
  video_id: string;
  layer: 'social_dynamics';
  debate_chains: Array<{
    root: string;
    participants: number;
    turns: number;
    escalation: number;
    resolution: string;
    topics: string[];
  }>;
  community: {
    polarization: number;
    meme_velocity: number;
    narrative_divergence: number;
    toxicity_ratio: number;
    constructive_ratio: number;
    participants: number;
    avg_thread_depth: number;
    reciprocity: number;
  };
  confidence: number;
}

export interface SemanticIntent {
  video_id: string;
  layer: 'semantic_intent';
  intent_scores: Record<string, number>;
  primary_intent: string;
  emotional_arc: {
    type: string;
    points: [number, number][];
  };
  persuasion: {
    style: string;
    intensity: number;
  };
  certainty_ratio: number;
  bias_framing: number;
  rhetorical_question_density: number;
  cta_count: number;
  confidence: number;
}

export interface CreatorEvolution {
  channel_id: string;
  layer: 'cross_video_evolution';
  video_count: number;
  time_range: [string, string];
  drifts: {
    intro_length: number;
    speech_speed: number;
    vocabulary_growth: number;
    sponsor_density: number;
    editing_complexity: number;
  };
  production_value_curve: number[];
  phases: Array<{ start_idx: number; end_idx: number; label: string; avg_production_score: number }>;
  confidence: number;
}

export interface GraphIntelligenceResult {
  entity_id: string;
  layer: 'graph_intelligence';
  entity_type: string;
  influence_centrality: number;
  betweenness_centrality: number;
  is_bridge_node: boolean;
  reciprocity_imbalance: number;
  confidence: number;
}

export interface MetaQuality {
  video_id: string;
  layer: 'meta_quality';
  transcript_reliability: number;
  visual_clarity: number;
  audio_cleanliness: number;
  editing_professionalism: number;
  redundancy: number;
  information_density: number;
  overall_quality: number;
  data_completeness: number;
  confidence: number;
}

export interface IntelligenceFeatureFlags {
  temporal_behavior: boolean;
  style_fingerprint: boolean;
  authenticity: boolean;
  social_dynamics: boolean;
  semantic_intent: boolean;
  cross_video_evolution: boolean;
  graph_intelligence: boolean;
  meta_quality: boolean;
}

export type IntelligenceLayer =
  | TemporalIntelligence
  | StyleFingerprint
  | AuthenticityReport
  | SocialDynamics
  | SemanticIntent
  | CreatorEvolution
  | GraphIntelligenceResult
  | MetaQuality;

// Three.js Engine Types
export interface GraphEngine3DStats {
  fps: number;
  quality: 'ultra-low' | 'low' | 'medium' | 'high';
  nodes: number;
  edges: number;
  layoutActive: boolean;
}
