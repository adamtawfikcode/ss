"""v4.2: deep signals + recrawl tracking + updated_at everywhere

Revision ID: v4_2_signals
Revises: v4_1_fixes
Create Date: 2026-02-12
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "v4_2_signals"
down_revision = "v4_1_fixes"
branch_labels = None
depends_on = None


def upgrade():
    # ── Add updated_at to all tables missing it ──────────────────────

    for table in [
        "playlist_items", "community_posts", "subtitles", "chapters",
        "stream_info", "segments", "frames", "audio_segments",
        "acoustic_change_points", "transcript_alignments", "users",
        "feedback", "model_versions", "evaluation_metrics", "crawl_logs",
        "comment_authors", "comments", "entities", "entity_mentions",
        "topics", "topic_assignments",
    ]:
        try:
            op.add_column(table, sa.Column(
                "updated_at", sa.DateTime(timezone=True),
                server_default=sa.func.now(), nullable=True,
            ))
        except Exception:
            pass  # Column may already exist

    # ── Add last_crawled_at to videos (if missing) ───────────────────

    try:
        op.add_column("videos", sa.Column(
            "last_crawled_at", sa.DateTime(timezone=True), nullable=True,
        ))
    except Exception:
        pass

    # ── Recrawl Events ───────────────────────────────────────────────

    op.create_table(
        "recrawl_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("trigger", sa.String(64), nullable=False),
        sa.Column("fields_changed", postgresql.JSON, nullable=True),
        sa.Column("delta_json", postgresql.JSON, nullable=True),
        sa.Column("comments_added", sa.Integer, default=0),
        sa.Column("comments_deleted", sa.Integer, default=0),
        sa.Column("description_changed", sa.Boolean, default=False),
        sa.Column("title_changed", sa.Boolean, default=False),
        sa.Column("duration_ms", sa.Integer, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_recrawl_video", "recrawl_events", ["video_id"])
    op.create_index("ix_recrawl_trigger", "recrawl_events", ["trigger"])

    # ── Temporal-Visual ──────────────────────────────────────────────

    op.create_table(
        "cursor_heatmaps",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("start_time", sa.Float),
        sa.Column("end_time", sa.Float),
        sa.Column("grid_cells", postgresql.JSON, nullable=True),
        sa.Column("hotspot_x", sa.Float, nullable=True),
        sa.Column("hotspot_y", sa.Float, nullable=True),
        sa.Column("total_distance_px", sa.Float, nullable=True),
        sa.Column("avg_velocity", sa.Float, nullable=True),
        sa.Column("idle_ratio", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_cursor_video", "cursor_heatmaps", ["video_id"])

    op.create_table(
        "text_edit_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("timestamp", sa.Float),
        sa.Column("action", sa.String(32)),
        sa.Column("text_before", sa.Text, nullable=True),
        sa.Column("text_after", sa.Text, nullable=True),
        sa.Column("keystroke_count", sa.Integer, nullable=True),
        sa.Column("time_to_correction_ms", sa.Integer, nullable=True),
        sa.Column("is_syntax_error_fix", sa.Boolean, default=False),
        sa.Column("is_logic_error_fix", sa.Boolean, default=False),
        sa.Column("programming_language", sa.String(32), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_textedit_video", "text_edit_events", ["video_id"])

    op.create_table(
        "face_camera_ratios",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("start_time", sa.Float),
        sa.Column("end_time", sa.Float),
        sa.Column("face_visible_ratio", sa.Float),
        sa.Column("face_count", sa.Integer, default=0),
        sa.Column("face_area_ratio", sa.Float, nullable=True),
        sa.Column("is_facecam_overlay", sa.Boolean, default=False),
        sa.Column("background_changed", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_facecam_video", "face_camera_ratios", ["video_id"])

    op.create_table(
        "background_changes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("video_id_before", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("video_id_after", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("similarity_score", sa.Float),
        sa.Column("change_type", sa.String(64)),
        sa.Column("embedding_distance", sa.Float, nullable=True),
        sa.Column("detected_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_bgchange_channel", "background_changes", ["channel_id"])

    # ── Audio Micro-Signals ──────────────────────────────────────────

    op.create_table(
        "breathing_patterns",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("timestamp", sa.Float),
        sa.Column("breath_type", sa.String(32)),
        sa.Column("duration_ms", sa.Integer),
        sa.Column("intensity", sa.Float),
        sa.Column("context", sa.String(64), nullable=True),
        sa.Column("preceding_speech_tempo", sa.Float, nullable=True),
        sa.Column("following_speech_tempo", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_breath_video", "breathing_patterns", ["video_id"])

    op.create_table(
        "ambient_audio_bleeds",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("start_time", sa.Float),
        sa.Column("end_time", sa.Float),
        sa.Column("bleed_type", sa.String(64)),
        sa.Column("event_count", sa.Integer, default=1),
        sa.Column("confidence", sa.Float, default=0.5),
        sa.Column("implies_live_input", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_ambient_video", "ambient_audio_bleeds", ["video_id"])

    op.create_table(
        "room_acoustic_fingerprints",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("rt60_ms", sa.Float, nullable=True),
        sa.Column("early_decay_time_ms", sa.Float, nullable=True),
        sa.Column("clarity_c50", sa.Float, nullable=True),
        sa.Column("spectral_fingerprint", postgresql.JSON, nullable=True),
        sa.Column("room_size_estimate", sa.String(32), nullable=True),
        sa.Column("noise_floor_db", sa.Float, nullable=True),
        sa.Column("matches_previous", sa.Boolean, nullable=True),
        sa.Column("cluster_id", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_roomfp_video", "room_acoustic_fingerprints", ["video_id"])

    op.create_table(
        "laughter_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("timestamp", sa.Float),
        sa.Column("duration_ms", sa.Integer),
        sa.Column("authenticity_score", sa.Float),
        sa.Column("spectral_decay_rate", sa.Float, nullable=True),
        sa.Column("pitch_variability", sa.Float, nullable=True),
        sa.Column("is_audience", sa.Boolean, default=False),
        sa.Column("trigger_context", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_laugh_video", "laughter_events", ["video_id"])

    # ── Behavioral Metadata ──────────────────────────────────────────

    op.create_table(
        "upload_patterns",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("upload_hour_utc", sa.Integer),
        sa.Column("upload_day_of_week", sa.Integer),
        sa.Column("days_since_last_upload", sa.Integer, nullable=True),
        sa.Column("hour_drift_from_mean", sa.Float, nullable=True),
        sa.Column("is_anomalous_time", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_uploadpat_channel", "upload_patterns", ["channel_id"])

    op.create_table(
        "title_edit_history",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("field_name", sa.String(32)),
        sa.Column("old_value", sa.Text, nullable=True),
        sa.Column("new_value", sa.Text, nullable=True),
        sa.Column("detected_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("hours_after_upload", sa.Float, nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_titleedit_video", "title_edit_history", ["video_id"])

    op.create_table(
        "thumbnail_analyses",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id"), nullable=True),
        sa.Column("dominant_colors", postgresql.JSON, nullable=True),
        sa.Column("has_face", sa.Boolean, default=False),
        sa.Column("has_text_overlay", sa.Boolean, default=False),
        sa.Column("text_content", sa.String(256), nullable=True),
        sa.Column("clickbait_score", sa.Float, nullable=True),
        sa.Column("palette_distance_from_channel_mean", sa.Float, nullable=True),
        sa.Column("brightness", sa.Float, nullable=True),
        sa.Column("saturation", sa.Float, nullable=True),
        sa.Column("contrast", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_thumb_video", "thumbnail_analyses", ["video_id"])

    op.create_table(
        "description_link_health",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("url", sa.String(2048)),
        sa.Column("domain", sa.String(256), nullable=True),
        sa.Column("http_status", sa.Integer, nullable=True),
        sa.Column("is_alive", sa.Boolean, default=True),
        sa.Column("is_affiliate", sa.Boolean, default=False),
        sa.Column("is_self_reference", sa.Boolean, default=False),
        sa.Column("last_checked_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("first_dead_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_linkhealth_video", "description_link_health", ["video_id"])

    # ── Comment Archaeology ──────────────────────────────────────────

    op.create_table(
        "pinned_comment_history",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("comment_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("comments.id", ondelete="SET NULL"), nullable=True),
        sa.Column("pinned_text", sa.Text, nullable=True),
        sa.Column("pinned_by_creator", sa.Boolean, default=True),
        sa.Column("detected_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("unpinned_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_pinned_video", "pinned_comment_history", ["video_id"])

    op.create_table(
        "comment_sentiment_drift",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("window_label", sa.String(32)),
        sa.Column("avg_sentiment", sa.Float),
        sa.Column("comment_count", sa.Integer),
        sa.Column("positive_ratio", sa.Float),
        sa.Column("negative_ratio", sa.Float),
        sa.Column("toxicity_avg", sa.Float, nullable=True),
        sa.Column("language_distribution", postgresql.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_sentdrift_video", "comment_sentiment_drift", ["video_id"])

    op.create_table(
        "deleted_comment_shadows",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("platform_comment_id", sa.String(256)),
        sa.Column("orphaned_reply_count", sa.Integer, default=0),
        sa.Column("last_known_text", sa.Text, nullable=True),
        sa.Column("last_known_author", sa.String(256), nullable=True),
        sa.Column("detected_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("probable_reason", sa.String(64), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_shadow_video", "deleted_comment_shadows", ["video_id"])

    # ── Cross-Video Forensics ────────────────────────────────────────

    op.create_table(
        "broll_reuse",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("matched_video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("timestamp_source", sa.Float),
        sa.Column("timestamp_match", sa.Float),
        sa.Column("duration_seconds", sa.Float),
        sa.Column("similarity_score", sa.Float),
        sa.Column("is_stock_footage", sa.Boolean, default=False),
        sa.Column("fingerprint_hash", sa.String(128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_broll_video", "broll_reuse", ["video_id"])

    op.create_table(
        "sponsor_segments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("start_time", sa.Float),
        sa.Column("end_time", sa.Float),
        sa.Column("sponsor_name", sa.String(256), nullable=True),
        sa.Column("segment_type", sa.String(32)),
        sa.Column("confidence", sa.Float, default=0.5),
        sa.Column("position_ratio", sa.Float),
        sa.Column("duration_seconds", sa.Float),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_sponsor_video", "sponsor_segments", ["video_id"])

    op.create_table(
        "intro_outro_evolutions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("has_intro", sa.Boolean, default=False),
        sa.Column("intro_duration_s", sa.Float, nullable=True),
        sa.Column("intro_fingerprint", sa.String(128), nullable=True),
        sa.Column("has_outro", sa.Boolean, default=False),
        sa.Column("outro_duration_s", sa.Float, nullable=True),
        sa.Column("outro_fingerprint", sa.String(128), nullable=True),
        sa.Column("silence_before_ask_ms", sa.Integer, nullable=True),
        sa.Column("ask_type", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_introoutro_channel", "intro_outro_evolutions", ["channel_id"])

    # ── Linguistic ───────────────────────────────────────────────────

    op.create_table(
        "linguistic_profiles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("code_switch_count", sa.Integer, default=0),
        sa.Column("code_switch_pairs", postgresql.JSON, nullable=True),
        sa.Column("primary_language", sa.String(16), nullable=True),
        sa.Column("secondary_language", sa.String(16), nullable=True),
        sa.Column("language_ratio", postgresql.JSON, nullable=True),
        sa.Column("filler_word_count", sa.Integer, default=0),
        sa.Column("filler_word_rate", sa.Float, nullable=True),
        sa.Column("filler_clusters", postgresql.JSON, nullable=True),
        sa.Column("hedging_phrases_count", sa.Integer, default=0),
        sa.Column("hedging_rate", sa.Float, nullable=True),
        sa.Column("hedging_by_topic", postgresql.JSON, nullable=True),
        sa.Column("unique_word_count", sa.Integer, default=0),
        sa.Column("vocabulary_richness", sa.Float, nullable=True),
        sa.Column("zipf_deviation", sa.Float, nullable=True),
        sa.Column("rare_word_rate", sa.Float, nullable=True),
        sa.Column("avg_sentence_length", sa.Float, nullable=True),
        sa.Column("speaking_rate_wpm", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_lingprof_video", "linguistic_profiles", ["video_id"])

    # ── Graph-Relational ─────────────────────────────────────────────

    op.create_table(
        "commenter_migrations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("comment_authors.id", ondelete="CASCADE")),
        sa.Column("from_channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("to_channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("first_seen_from", sa.DateTime(timezone=True)),
        sa.Column("last_seen_from", sa.DateTime(timezone=True)),
        sa.Column("first_seen_to", sa.DateTime(timezone=True)),
        sa.Column("migration_confidence", sa.Float),
        sa.Column("overlap_period_days", sa.Integer, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_migration_author", "commenter_migrations", ["author_id"])
    op.create_index("ix_migration_channels", "commenter_migrations", ["from_channel_id", "to_channel_id"])

    op.create_table(
        "entity_propagations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("entity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("entities.id", ondelete="CASCADE")),
        sa.Column("origin_channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("origin_video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("origin_timestamp", sa.DateTime(timezone=True)),
        sa.Column("propagation_chain", postgresql.JSON, nullable=True),
        sa.Column("total_adopters", sa.Integer, default=0),
        sa.Column("avg_adoption_lag_hours", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_entprop_entity", "entity_propagations", ["entity_id"])
    op.create_index("ix_entprop_origin_channel", "entity_propagations", ["origin_channel_id"])

    op.create_table(
        "parasocial_indices",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("comment_authors.id", ondelete="CASCADE")),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("author_comments_on_channel", sa.Integer, default=0),
        sa.Column("creator_replies_to_author", sa.Integer, default=0),
        sa.Column("reciprocity_ratio", sa.Float, default=0.0),
        sa.Column("first_interaction", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_interaction", sa.DateTime(timezone=True), nullable=True),
        sa.Column("engagement_tier", sa.String(32), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_parasocial_author", "parasocial_indices", ["author_id"])
    op.create_index("ix_parasocial_channel", "parasocial_indices", ["channel_id"])

    op.create_table(
        "topic_gestations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("entity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("entities.id", ondelete="CASCADE")),
        sa.Column("first_comment_mention_at", sa.DateTime(timezone=True)),
        sa.Column("first_video_mention_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("gestation_days", sa.Integer, nullable=True),
        sa.Column("comment_mention_count_before_video", sa.Integer, default=0),
        sa.Column("audience_requested", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_topicgest_channel", "topic_gestations", ["channel_id"])
    op.create_index("ix_topicgest_entity", "topic_gestations", ["entity_id"])


def downgrade():
    tables = [
        "topic_gestations", "parasocial_indices", "entity_propagations",
        "commenter_migrations", "linguistic_profiles", "intro_outro_evolutions",
        "sponsor_segments", "broll_reuse", "deleted_comment_shadows",
        "comment_sentiment_drift", "pinned_comment_history",
        "description_link_health", "thumbnail_analyses", "title_edit_history",
        "upload_patterns", "laughter_events", "room_acoustic_fingerprints",
        "ambient_audio_bleeds", "breathing_patterns", "background_changes",
        "face_camera_ratios", "text_edit_events", "cursor_heatmaps",
        "recrawl_events",
    ]
    for t in tables:
        op.drop_table(t)
