"""v4.1: Metadata expansion — Subtitles, StreamInfo, Chapters, Playlists,
CommunityPosts, extended Video columns.

Revision ID: v4_1_metadata_expansion
Revises: v4_0_calibrated_intelligence
Create Date: 2026-02-12
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "v4_1_metadata_expansion"
down_revision = "v4_0_calibrated_intelligence"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── New Video columns ────────────────────────────────────────────────
    op.add_column("videos", sa.Column("tags", postgresql.ARRAY(sa.String), nullable=True))
    op.add_column("videos", sa.Column("categories", postgresql.ARRAY(sa.String), nullable=True))
    op.add_column("videos", sa.Column("live_status", sa.String(32), nullable=True))
    op.add_column("videos", sa.Column("chapters_json", postgresql.JSON, nullable=True))
    op.add_column("videos", sa.Column("captions_info", postgresql.JSON, nullable=True))
    op.add_column("videos", sa.Column("like_count", sa.Integer, nullable=True))
    op.add_column("videos", sa.Column("dislike_count", sa.Integer, nullable=True))
    op.add_column("videos", sa.Column("comment_count", sa.Integer, nullable=True))
    op.add_column("videos", sa.Column("age_limit", sa.Integer, nullable=True))
    op.add_column("videos", sa.Column("is_short", sa.Boolean, server_default="false"))
    op.add_column("videos", sa.Column("has_captions", sa.Boolean, server_default="false"))
    op.add_column("videos", sa.Column("caption_languages", postgresql.ARRAY(sa.String), nullable=True))
    op.add_column("videos", sa.Column("has_auto_captions", sa.Boolean, server_default="false"))
    op.add_column("videos", sa.Column("auto_caption_languages", postgresql.ARRAY(sa.String), nullable=True))

    # ── New Channel columns ──────────────────────────────────────────────
    op.add_column("channels", sa.Column("custom_url", sa.String(256), nullable=True))
    op.add_column("channels", sa.Column("description", sa.Text, nullable=True))
    op.add_column("channels", sa.Column("country", sa.String(8), nullable=True))
    op.add_column("channels", sa.Column("language", sa.String(16), nullable=True))
    op.add_column("channels", sa.Column("subscriber_count", sa.Integer, nullable=True))
    op.add_column("channels", sa.Column("total_videos", sa.Integer, nullable=True))
    op.add_column("channels", sa.Column("banner_url", sa.String(1024), nullable=True))

    # ── Subtitles table ──────────────────────────────────────────────────
    op.create_table(
        "subtitles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("language", sa.String(16), nullable=False),
        sa.Column("language_name", sa.String(64), nullable=True),
        sa.Column("is_auto_generated", sa.Boolean, server_default="false"),
        sa.Column("format", sa.String(16), server_default="srt"),
        sa.Column("content", sa.Text, nullable=True),
        sa.Column("cue_count", sa.Integer, server_default="0"),
        sa.Column("metadata_json", postgresql.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_subtitles_video_lang", "subtitles", ["video_id", "language"])

    # ── Chapters table ───────────────────────────────────────────────────
    op.create_table(
        "chapters",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(512), nullable=False),
        sa.Column("start_time", sa.Float, nullable=False),
        sa.Column("end_time", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_chapters_video", "chapters", ["video_id"])

    # ── StreamInfo table ─────────────────────────────────────────────────
    op.create_table(
        "stream_info",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("stream_type", sa.String(16), nullable=False),
        sa.Column("codec", sa.String(32), nullable=True),
        sa.Column("bitrate", sa.Integer, nullable=True),
        sa.Column("resolution", sa.String(32), nullable=True),
        sa.Column("fps", sa.Float, nullable=True),
        sa.Column("sample_rate", sa.Integer, nullable=True),
        sa.Column("channels", sa.Integer, nullable=True),
        sa.Column("container_format", sa.String(32), nullable=True),
        sa.Column("file_size_bytes", sa.Integer, nullable=True),
        sa.Column("duration_seconds", sa.Float, nullable=True),
        sa.Column("metadata_json", postgresql.JSON, nullable=True),
    )
    op.create_index("ix_si_video", "stream_info", ["video_id"])

    # ── Playlists table ──────────────────────────────────────────────────
    op.create_table(
        "playlists",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("platform_playlist_id", sa.String(256), unique=True, nullable=False),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("channels.id"), nullable=True),
        sa.Column("title", sa.String(512), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("thumbnail_url", sa.String(1024), nullable=True),
        sa.Column("video_count", sa.Integer, server_default="0"),
        sa.Column("visibility", sa.String(32), server_default="public"),
        sa.Column("url", sa.String(1024), nullable=False),
        sa.Column("metadata_json", postgresql.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_playlists_channel", "playlists", ["channel_id"])
    op.create_index("ix_playlists_platform_pid", "playlists", ["platform_playlist_id"], unique=True)

    # ── PlaylistItems table ──────────────────────────────────────────────
    op.create_table(
        "playlist_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("playlist_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("playlists.id", ondelete="CASCADE"), nullable=False),
        sa.Column("video_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("videos.id", ondelete="SET NULL"), nullable=True),
        sa.Column("platform_video_id", sa.String(128), nullable=False),
        sa.Column("position", sa.Integer, server_default="0"),
        sa.Column("added_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_pi_playlist_pos", "playlist_items", ["playlist_id", "position"])

    # ── CommunityPosts table ─────────────────────────────────────────────
    op.create_table(
        "community_posts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("platform_post_id", sa.String(256), unique=True, nullable=False),
        sa.Column("channel_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("channels.id", ondelete="CASCADE"), nullable=False),
        sa.Column("text", sa.Text, nullable=True),
        sa.Column("post_type", sa.String(32), server_default="text"),
        sa.Column("image_urls", postgresql.JSON, nullable=True),
        sa.Column("poll_json", postgresql.JSON, nullable=True),
        sa.Column("like_count", sa.Integer, server_default="0"),
        sa.Column("comment_count", sa.Integer, server_default="0"),
        sa.Column("posted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata_json", postgresql.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_cp_channel", "community_posts", ["channel_id"])
    op.create_index("ix_cp_posted_at", "community_posts", ["posted_at"])


def downgrade() -> None:
    op.drop_table("community_posts")
    op.drop_table("playlist_items")
    op.drop_table("playlists")
    op.drop_table("stream_info")
    op.drop_table("chapters")
    op.drop_table("subtitles")

    for col in ("custom_url", "description", "country", "language",
                "subscriber_count", "total_videos", "banner_url"):
        op.drop_column("channels", col)

    for col in ("tags", "categories", "live_status", "chapters_json",
                "captions_info", "like_count", "dislike_count", "comment_count",
                "age_limit", "is_short", "has_captions", "caption_languages",
                "has_auto_captions", "auto_caption_languages"):
        op.drop_column("videos", col)
