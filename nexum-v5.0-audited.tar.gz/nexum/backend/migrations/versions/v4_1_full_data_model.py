"""v4.1: Complete data model — Playlist, PlaylistItem, CommunityPost, Subtitle, StreamInfo + Video/Channel expansion.

Revision ID: v4_1_full_data
Revises: v4_0_calibrated_intelligence
"""
revision = "v4_1_full_data"
down_revision = "v4_0_calibrated_intelligence"

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID, JSON, ARRAY


def upgrade():
    # ── Expand Channel ─────────────────────────────────────────────
    op.add_column("channels", sa.Column("custom_url", sa.String(256), nullable=True))
    op.add_column("channels", sa.Column("description", sa.Text(), nullable=True))
    op.add_column("channels", sa.Column("country", sa.String(8), nullable=True))
    op.add_column("channels", sa.Column("subscriber_count", sa.Integer(), nullable=True))
    op.add_column("channels", sa.Column("total_videos", sa.Integer(), nullable=True))
    op.add_column("channels", sa.Column("banner_url", sa.String(1024), nullable=True))

    # ── Expand Video ───────────────────────────────────────────────
    op.add_column("videos", sa.Column("tags", ARRAY(sa.String()), nullable=True))
    op.add_column("videos", sa.Column("categories", ARRAY(sa.String()), nullable=True))
    op.add_column("videos", sa.Column("live_status", sa.String(16), nullable=True))
    op.add_column("videos", sa.Column("chapters_json", JSON(), nullable=True))
    op.add_column("videos", sa.Column("captions_info", JSON(), nullable=True))
    op.add_column("videos", sa.Column("comment_count", sa.Integer(), nullable=True))

    # ── Playlists ──────────────────────────────────────────────────
    op.create_table(
        "playlists",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("platform_playlist_id", sa.String(256), unique=True, index=True),
        sa.Column("channel_id", UUID(as_uuid=True), sa.ForeignKey("channels.id"), nullable=True),
        sa.Column("title", sa.String(512), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("thumbnail_url", sa.String(1024), nullable=True),
        sa.Column("video_count", sa.Integer(), default=0),
        sa.Column("visibility", sa.String(32), default="public"),
        sa.Column("url", sa.String(1024), nullable=False),
        sa.Column("metadata_json", JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_playlists_channel", "playlists", ["channel_id"])

    op.create_table(
        "playlist_items",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("playlist_id", UUID(as_uuid=True), sa.ForeignKey("playlists.id", ondelete="CASCADE")),
        sa.Column("video_id", UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="SET NULL"), nullable=True),
        sa.Column("platform_video_id", sa.String(128), nullable=False),
        sa.Column("position", sa.Integer(), default=0),
        sa.Column("added_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_pi_playlist_pos", "playlist_items", ["playlist_id", "position"])

    # ── Community Posts ────────────────────────────────────────────
    op.create_table(
        "community_posts",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("platform_post_id", sa.String(256), unique=True, index=True),
        sa.Column("channel_id", UUID(as_uuid=True), sa.ForeignKey("channels.id", ondelete="CASCADE")),
        sa.Column("text", sa.Text(), nullable=True),
        sa.Column("post_type", sa.String(32), default="text"),
        sa.Column("image_urls", JSON(), nullable=True),
        sa.Column("poll_json", JSON(), nullable=True),
        sa.Column("like_count", sa.Integer(), default=0),
        sa.Column("comment_count", sa.Integer(), default=0),
        sa.Column("posted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata_json", JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_cp_channel", "community_posts", ["channel_id"])
    op.create_index("ix_cp_posted_at", "community_posts", ["posted_at"])

    # ── Subtitles ──────────────────────────────────────────────────
    op.create_table(
        "subtitles",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("language", sa.String(16), nullable=False),
        sa.Column("language_name", sa.String(64), nullable=True),
        sa.Column("is_auto_generated", sa.Boolean(), default=False),
        sa.Column("format", sa.String(16), default="srt"),
        sa.Column("content", sa.Text(), nullable=True),
        sa.Column("cue_count", sa.Integer(), default=0),
        sa.Column("metadata_json", JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_subtitles_video_lang", "subtitles", ["video_id", "language"])

    # ── Stream Info ────────────────────────────────────────────────
    op.create_table(
        "stream_info",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE")),
        sa.Column("stream_type", sa.String(16), nullable=False),
        sa.Column("codec", sa.String(32), nullable=True),
        sa.Column("bitrate", sa.Integer(), nullable=True),
        sa.Column("resolution", sa.String(32), nullable=True),
        sa.Column("fps", sa.Float(), nullable=True),
        sa.Column("sample_rate", sa.Integer(), nullable=True),
        sa.Column("channels", sa.Integer(), nullable=True),
        sa.Column("container_format", sa.String(32), nullable=True),
        sa.Column("file_size_bytes", sa.Integer(), nullable=True),
        sa.Column("duration_seconds", sa.Float(), nullable=True),
        sa.Column("metadata_json", JSON(), nullable=True),
    )
    op.create_index("ix_si_video", "stream_info", ["video_id"])

    # ── Add created_at to change points and alignments ─────────────
    op.add_column("acoustic_change_points", sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()))
    op.add_column("transcript_alignments", sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()))


def downgrade():
    op.drop_table("stream_info")
    op.drop_table("subtitles")
    op.drop_table("community_posts")
    op.drop_table("playlist_items")
    op.drop_table("playlists")
    op.drop_column("videos", "comment_count")
    op.drop_column("videos", "captions_info")
    op.drop_column("videos", "chapters_json")
    op.drop_column("videos", "live_status")
    op.drop_column("videos", "categories")
    op.drop_column("videos", "tags")
    op.drop_column("channels", "banner_url")
    op.drop_column("channels", "total_videos")
    op.drop_column("channels", "subscriber_count")
    op.drop_column("channels", "country")
    op.drop_column("channels", "description")
    op.drop_column("channels", "custom_url")
    op.drop_column("acoustic_change_points", "created_at")
    op.drop_column("transcript_alignments", "created_at")
