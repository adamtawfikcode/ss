"""v4.0: Add AcousticChangePoint and TranscriptAlignment tables, extend AudioSegment.

Revision ID: v4_0_calibrated_intelligence
Revises: (auto-detect previous)
Create Date: 2026-02-11
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = "v4_0_calibrated_intelligence"
down_revision = None  # Set to actual previous revision
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── AcousticChangePoint ──────────────────────────────────────────────
    op.create_table(
        "acoustic_change_points",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("timestamp", sa.Float, nullable=False),
        sa.Column("magnitude", sa.Float, nullable=False),
        sa.Column("transition_type", sa.String(50), nullable=False),
        sa.Column("detail", sa.Text, nullable=True),
        sa.Column("from_state", sa.String(50), nullable=True),
        sa.Column("to_state", sa.String(50), nullable=True),
        sa.Column("spectral_distance", sa.Float, nullable=True),
        sa.Column("energy_ratio", sa.Float, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_acp_video_ts", "acoustic_change_points", ["video_id", "timestamp"])
    op.create_index("ix_acp_magnitude", "acoustic_change_points", ["magnitude"])
    op.create_index("ix_acp_transition", "acoustic_change_points", ["transition_type"])

    # ── TranscriptAlignment ──────────────────────────────────────────────
    op.create_table(
        "transcript_alignments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("video_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("videos.id", ondelete="CASCADE"), nullable=False),
        sa.Column("segment_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("segments.id", ondelete="SET NULL"), nullable=True),
        sa.Column("start_time", sa.Float, nullable=False),
        sa.Column("end_time", sa.Float, nullable=False),
        sa.Column("alignment_score", sa.Float, nullable=False),
        sa.Column("quality_level", sa.String(20), nullable=False),
        sa.Column("signals_json", postgresql.JSONB, nullable=True),
        sa.Column("warnings_json", postgresql.JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_ta_video_ts", "transcript_alignments", ["video_id", "start_time"])
    op.create_index("ix_ta_quality", "transcript_alignments", ["quality_level"])

    # ── Extend AudioSegment for calibration ──────────────────────────────
    op.add_column("audio_segments", sa.Column("calibrated_manipulation", postgresql.JSONB, nullable=True))
    op.add_column("audio_segments", sa.Column("calibration_version", sa.String(20), nullable=True))


def downgrade() -> None:
    op.drop_column("audio_segments", "calibration_version")
    op.drop_column("audio_segments", "calibrated_manipulation")
    op.drop_index("ix_ta_quality", table_name="transcript_alignments")
    op.drop_index("ix_ta_video_ts", table_name="transcript_alignments")
    op.drop_table("transcript_alignments")
    op.drop_index("ix_acp_transition", table_name="acoustic_change_points")
    op.drop_index("ix_acp_magnitude", table_name="acoustic_change_points")
    op.drop_index("ix_acp_video_ts", table_name="acoustic_change_points")
    op.drop_table("acoustic_change_points")
